import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-header',
  imports: [RouterLink, CommonModule],
  standalone: true,
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header implements OnInit {

  userName: string | null = null;
  userRole: string | null = null;

  constructor(private router: Router) {}

  ngOnInit() {
    this.loadUserData();

    // update header after navigation (login ke baad)
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.loadUserData();
      }
    });
  }

  loadUserData() {
    this.userName = localStorage.getItem('userName');
    this.userRole = localStorage.getItem('userRole');
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  isAdmin(): boolean {
    return this.userRole === 'admin';
  }

  goToAdmin() {
    this.router.navigate(['/admin']);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
