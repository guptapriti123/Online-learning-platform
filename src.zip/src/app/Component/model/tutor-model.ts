export interface Tutor {
  id?: number;
  name: string;
  expertise: string;
  image: string;
  description?: string;
}