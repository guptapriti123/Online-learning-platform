import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth-service';
import { CommonModule } from '@angular/common';  // ← Ye add karo

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [RouterLink, FormsModule, CommonModule],  // ← CommonModule yaha add karo
  templateUrl: './register.html',
  styleUrls: ['./register.css'],
})
export class Register {
  name: string = '';
  email: string = '';
  password: string = '';
  errorMsg: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  register() {
  if (!this.name || !this.email || !this.password) {
    this.errorMsg = 'Please fill all fields';
    return;
  }

  this.authService.register(this.name, this.email, this.password).subscribe({
    next: (response) => {
      console.log('Register response:', response); // Debug
      
      // Fix: response.name directly
      this.authService.saveToken(response.token, response.name);
      localStorage.setItem('userEmail', response.email); // ← Add
      localStorage.setItem('userId', response.id);
      this.router.navigate(['/login']); // Ya '/home' bhi kar sakte ho
    },
    error: (err) => {
      console.log('Register error:', err);
      
      if (err.error && typeof err.error === 'string') {
        this.errorMsg = err.error;
      } else if (err.error && err.error.message) {
        this.errorMsg = err.error.message;
      } else {
        this.errorMsg = 'Registration failed. Please try again.';
      }
    }
  });
}
}