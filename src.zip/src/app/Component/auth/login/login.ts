import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth-service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterLink, CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class Login {
  email: string = '';
  password: string = '';
  errorMsg: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  // login.component.ts
login() {
  if (!this.email || !this.password) {
    this.errorMsg = 'Email and password are required';
    return;
  }

  this.authService.login(this.email, this.password).subscribe({
    next: (response) => {
      if (response.status) {
        localStorage.setItem('token', response.token);
        localStorage.setItem('userName', response.name);
        localStorage.setItem('userEmail', response.email);
        localStorage.setItem('userId', response.id);
        
        // ✅ Backend se role mila toh use karo
        if (response.role) {
          localStorage.setItem('userRole', response.role);
          
          if (response.role === 'admin') {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/home']);
          }
        } else {
          // Fallback: Email se check karo
          const adminEmails = ['admin@gmail.com'];
          if (adminEmails.includes(response.email.toLowerCase())) {
            localStorage.setItem('userRole', 'admin');
            this.router.navigate(['/admin']);
          } else {
            localStorage.setItem('userRole', 'user');
            this.router.navigate(['/home']);
          }
        }
      }
    },
    error: (err) => {
      this.errorMsg = err.error?.message || 'Invalid credentials';
    }
  });
}
}