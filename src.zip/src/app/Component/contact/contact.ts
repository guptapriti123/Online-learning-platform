import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface ContactForm {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './contact.html',
  styleUrl: './contact.css',
})
export class Contact implements OnInit {
  contactForm: ContactForm = {
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  };

  isLoading: boolean = false;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Pre-fill user info if logged in
    this.loadUserInfo();
  }

  loadUserInfo(): void {
    const userName = localStorage.getItem('userName');
    const userEmail = localStorage.getItem('userEmail');
    
    if (userName) {
      this.contactForm.name = userName;
    }
    if (userEmail) {
      this.contactForm.email = userEmail;
    }
  }

  submitForm(): void {
    // Validation
    if (!this.contactForm.name || !this.contactForm.email || 
        !this.contactForm.subject || !this.contactForm.message) {
      this.showError('Please fill in all required fields');
      return;
    }

    // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(this.contactForm.email)) {
      this.showError('Please enter a valid email address');
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    // Simulate form submission (replace with actual API call)
    setTimeout(() => {
      console.log('Contact form submitted:', this.contactForm);
      
      // Show success message
      this.showSuccess('Thank you for contacting us! We will get back to you soon.');
      
      // Reset form
      this.resetForm();
      
      this.isLoading = false;
    }, 1500);
  }

  resetForm(): void {
    this.contactForm = {
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    };
    
    // Reload user info
    this.loadUserInfo();
  }

  showError(message: string): void {
    this.errorMessage = message;
    setTimeout(() => {
      this.errorMessage = '';
    }, 5000);
  }

  showSuccess(message: string): void {
    this.successMessage = message;
    setTimeout(() => {
      this.successMessage = '';
    }, 5000);
  }

  goBack(): void {
    this.router.navigate(['/home']);
  }
}