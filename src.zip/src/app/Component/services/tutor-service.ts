import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Tutor } from '../model/tutor-model';

@Injectable({
  providedIn: 'root'
})
export class TutorService {
  private apiUrl = 'http://localhost:8080/api/tutors';
  private tutorsSubject = new BehaviorSubject<Tutor[]>([]);
  tutors$ = this.tutorsSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadTutors();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Load all tutors
  loadTutors(): void {
    this.http.get<any>(this.apiUrl).subscribe({
      next: (response) => {
        if (response.status) {
          this.tutorsSubject.next(response.data);
        }
      },
      error: (error) => console.error('Error loading tutors:', error)
    });
  }

  // Get all tutors
  getTutors(): Observable<Tutor[]> {
    return this.tutors$;
  }

  // Add tutor (Admin only)
  addTutor(tutor: Tutor): Observable<any> {
    return this.http.post<any>(this.apiUrl, tutor, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap(() => this.loadTutors())
    );
  }

  // Update tutor (Admin only)
  updateTutor(id: number, tutor: Tutor): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, tutor, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap(() => this.loadTutors())
    );
  }

  // Delete tutor (Admin only)
  deleteTutor(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap(() => this.loadTutors())
    );
  }
}