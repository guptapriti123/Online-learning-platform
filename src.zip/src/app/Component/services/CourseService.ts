import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { Course } from '../model/course.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  private apiUrl = 'http://localhost:8080/api/courses';
  private coursesSubject = new BehaviorSubject<Course[]>([]);
  courses$ = this.coursesSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadCourses();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  // Load all courses
  loadCourses(): void {
    this.http.get<any>(this.apiUrl).subscribe({
      next: (response) => {
        console.log('Load courses response:', response);
        if (response.status) {
          this.coursesSubject.next(response.data);
        }
      },
      error: (error) => {
        console.error('Error loading courses:', error);
      }
    });
  }

  // Get all courses
  getCourses(): Observable<Course[]> {
    return this.courses$;
  }

  // Get single course
  getCourseById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  // Add course (Admin only)
  addCourse(course: Course): Observable<any> {
    console.log('Service: Adding course', course);
    
    // Create course object without id (backend will generate it)
    const courseData = {
      title: course.title,
      description: course.description,
      instructor: course.instructor || '',
      duration: course.duration || ''
    };

    console.log('Service: Sending data', courseData);

    return this.http.post<any>(this.apiUrl, courseData, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap((response) => {
        console.log('Service: Add course response', response);
        // Reload courses after successful addition
        this.loadCourses();
      }),
      catchError((error) => {
        console.error('Service: Add course error', error);
        throw error;
      })
    );
  }

  // Update course (Admin only)
  updateCourse(id: number, course: Course): Observable<any> {
    console.log('Service: Updating course', id, course);
    
    const courseData = {
      title: course.title,
      description: course.description,
      instructor: course.instructor || '',
      duration: course.duration || ''
    };

    return this.http.put<any>(`${this.apiUrl}/${id}`, courseData, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap((response) => {
        console.log('Service: Update course response', response);
        this.loadCourses();
      }),
      catchError((error) => {
        console.error('Service: Update course error', error);
        throw error;
      })
    );
  }

  // Delete course (Admin only)
  deleteCourse(id: number): Observable<any> {
    console.log('Service: Deleting course', id);
    
    return this.http.delete<any>(`${this.apiUrl}/${id}`, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap((response) => {
        console.log('Service: Delete course response', response);
        this.loadCourses();
      }),
      catchError((error) => {
        console.error('Service: Delete course error', error);
        throw error;
      })
    );
  }
}