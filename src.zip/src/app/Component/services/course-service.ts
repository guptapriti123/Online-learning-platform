import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Course } from '../model/course.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  private apiUrl = 'http://localhost:8080/api/courses';
  private coursesSubject = new BehaviorSubject<Course[]>([]);
  courses$ = this.coursesSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadCourses();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Load all courses
  loadCourses(): void {
    this.http.get<any>(this.apiUrl).subscribe({
      next: (response) => {
        if (response.status) {
          this.coursesSubject.next(response.data);
        }
      },
      error: (error) => console.error('Error loading courses:', error)
    });
  }

  // Get all courses
  getCourses(): Observable<Course[]> {
    return this.courses$;
  }

  // Get single course
  getCourseById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  // Add course (Admin only)
  addCourse(course: Course): Observable<any> {
    return this.http.post<any>(this.apiUrl, course, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap(() => this.loadCourses())
    );
  }

  // Update course (Admin only)
  updateCourse(id: number, course: Course): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, course, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap(() => this.loadCourses())
    );
  }

  // Delete course (Admin only)
  deleteCourse(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`, { 
      headers: this.getAuthHeaders() 
    }).pipe(
      tap(() => this.loadCourses())
    );
  }
}