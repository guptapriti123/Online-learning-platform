import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const userGuard: CanActivateFn = () => {

  const router = inject(Router);

  const token = localStorage.getItem('token');

  // user must be logged in
  if (token) {
    return true;
  }

  // not logged in
  alert('Please login to continue');
  router.navigate(['/login']);
  return false;
};
