import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { CanActivateFn } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('token');
  const userName = localStorage.getItem('userName');

  if (token && userName) {
    // User is logged in
    return true;
  } else {
    // User is not logged in, redirect to login
    router.navigate(['/login']);
    return false;
  }
};