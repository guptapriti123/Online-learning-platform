import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Exportcomponent } from './exportcomponent';

describe('Exportcomponent', () => {
  let component: Exportcomponent;
  let fixture: ComponentFixture<Exportcomponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Exportcomponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Exportcomponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
