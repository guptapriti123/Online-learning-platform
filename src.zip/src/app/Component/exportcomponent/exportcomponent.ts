import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TutorService } from '../services/tutor-service';
import { Tutor } from '../model/tutor-model';


@Component({
  selector: 'app-exportcomponent',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './exportcomponent.html',
  styleUrl: './exportcomponent.css',
})
export class Exportcomponent implements OnInit {
  tutors: Tutor[] = [];
  isLoading: boolean = true;

  constructor(private tutorService: TutorService) {}

  ngOnInit(): void {
    this.loadTutors();
  }

  loadTutors(): void {
    this.tutorService.getTutors().subscribe({
      next: (tutors) => {
        this.tutors = tutors;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading tutors:', error);
        this.isLoading = false;
      }
    });
  }

  goBack(): void {
    window.history.back();
  }
}