import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CourseService } from '../../services/course-service';
import { Course } from '../../model/course.model';

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './course-detail.html',
  styleUrl: './course-detail.css',
})
export class CourseDetail implements OnInit {
  course: Course | null = null;
  isLoading: boolean = true;
  errorMessage: string = '';
  courseId: number = 0;

  constructor(
  private courseService: CourseService,
  private route: ActivatedRoute,
  private router: Router
) {}


  ngOnInit(): void {
    // Get course ID from URL
    this.courseId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadCourseDetail();
  }

  loadCourseDetail(): void {
    this.courseService.getCourseById(this.courseId).subscribe({
      next: (response) => {
        console.log('Course detail response:', response);
        if (response.status) {
          this.course = response.data;
        } else {
          this.errorMessage = 'Course not found';
        }
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading course:', error);
        this.errorMessage = 'Failed to load course details';
        this.isLoading = false;
      }
    });
  }
  

}