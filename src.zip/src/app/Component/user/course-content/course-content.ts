import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

interface CourseModule {
  id: number;
  title: string;
  duration: string;
  completed: boolean;
  description?: string;
  description2?: string;
}

interface Course {
  id: string;
  title: string;
  description: string;
  description2?: string;
  instructor: string;
  lastUpdated: string;
  duration: string;
  level: string;
  progress: number;
}

@Component({
  selector: 'app-course-content',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './course-content.html',
  styleUrls: ['./course-content.css'],
})
export class CourseContent implements OnInit {
  courseId: string | null = null;
  currentTab: string = 'overview';

  // ✅ FIXED: Added missing property
  selectedModuleId: number | null = null;
  expandedModuleId: number | null = null;

  // All available courses data - Extended to 18 courses
  allCourses: { [key: string]: Course } = {
    '21': {
      id: '21',
      title: 'HTML Tutorial - Complete Web Development Guide',
      description: 'HTML (HyperText Markup Language) is the core language used to structure and display content on the web, defining elements like text, images, links, and page layout so browsers can render websites properly.',
      instructor: 'Dr. Sarah Johnson',
      lastUpdated: '24 Jan, 2026',
      duration: '8 hours',
      level: 'Beginner',
      progress: 45
    },
    '1': {
      id: '1',
      title: 'Complete Angular Development',
      description: 'Master Angular from basics to advanced concepts including components, services, routing, and state management. Build production-ready applications with best practices and modern Angular features.',
      instructor: 'John Doe',
      lastUpdated: '28 Jan, 2026',
      duration: '24 hours',
      level: 'Intermediate',
      progress: 0
    },
    '2': {
      id: '2',
      title: 'React JS Fundamentals',
      description: 'Learn React from scratch including hooks, context API, Redux, and modern React patterns. Create dynamic single-page applications with reusable components and efficient state management.',
      instructor: 'Jummy Sharma',
      lastUpdated: '30 Jan, 2026',
      duration: '18 hours',
      level: 'Beginner',
      progress: 0
    },
    '3': {
      id: '3',
      title: 'Full Stack Web Development',
      description: 'Complete MERN stack course covering MongoDB, Express.js, React, and Node.js. Build and deploy full-stack applications.',
      instructor: 'Amit Patel',
      lastUpdated: '25 Jan, 2026',
      duration: '6 months',
      level: 'Advanced',
      progress: 0
    },
    '4': {
      id: '4',
      title: 'Python for Data Science',
      description: 'Comprehensive Python course covering NumPy, Pandas, Matplotlib, and machine learning basics. Analyze real-world datasets.',
      instructor: 'Dr. Sneha Reddy',
      lastUpdated: '26 Jan, 2026',
      duration: '4 months',
      level: 'Intermediate',
      progress: 0
    },
    '5': {
      id: '5',
      title: 'Java Programming Masterclass',
      description: 'Complete Java course from basics to advanced OOP concepts, collections, multithreading, and Spring Boot framework.',
      instructor: 'Emily Davis',
      lastUpdated: '27 Jan, 2026',
      duration: '5 months',
      level: 'Intermediate',
      progress: 0
    },
    '6': {
      id: '6',
      title: 'Digital Marketing Essentials',
      description: 'Learn SEO, social media marketing, content marketing, email campaigns, and Google Analytics. Boost your online presence.',
      instructor: 'Neha Gupta',
      lastUpdated: '28 Jan, 2026',
      duration: '2 months',
      level: 'Beginner',
      progress: 0
    },
    '7': {
      id: '7',
      title: 'UI/UX Design Bootcamp',
      description: 'Master Figma, Adobe XD, user research, wireframing, prototyping, and design thinking. Create beautiful user interfaces.',
      instructor: 'Priti Khattar',
      lastUpdated: '29 Jan, 2026',
      duration: '3 months',
      level: 'Beginner',
      progress: 0
    },
    '8': {
      id: '8',
      title: 'Machine Learning with Python',
      description: 'Deep dive into ML algorithms, neural networks, TensorFlow, and scikit-learn. Build predictive models and AI applications.',
      instructor: 'Dr. Ravi Krishnan',
      lastUpdated: '30 Jan, 2026',
      duration: '5 months',
      level: 'Advanced',
      progress: 0
    },
    '9': {
      id: '9',
      title: 'Cloud Computing with AWS',
      description: 'Learn AWS services including EC2, S3, Lambda, RDS, and CloudFormation. Deploy scalable cloud applications.',
      instructor: 'Suresh Iyer',
      lastUpdated: '31 Jan, 2026',
      duration: '4 months',
      level: 'Intermediate',
      progress: 0
    },
    '10': {
      id: '10',
      title: 'Mobile App Development',
      description: 'Build native mobile apps using React Native and Flutter. Create cross-platform applications for iOS and Android.',
      instructor: 'Kavita Joshi',
      lastUpdated: '01 Feb, 2026',
      duration: '4 months',
      level: 'Intermediate',
      progress: 0
    },
    '11': {
      id: '11',
      title: 'Cybersecurity Fundamentals',
      description: 'Learn ethical hacking, network security, cryptography, and security best practices. Protect systems from cyber threats.',
      instructor: 'Anil Verma',
      lastUpdated: '02 Feb, 2026',
      duration: '3 months',
      level: 'Intermediate',
      progress: 0
    },
    '12': {
      id: '12',
      title: 'Blockchain Development',
      description: 'Master blockchain technology, smart contracts, Solidity, Ethereum, and decentralized applications (DApps).',
      instructor: 'Meera Nair',
      lastUpdated: '03 Feb, 2026',
      duration: '4 months',
      level: 'Advanced',
      progress: 0
    },
    '13': {
      id: '13',
      title: 'DevOps Engineering',
      description: 'Learn Docker, Kubernetes, Jenkins, CI/CD pipelines, and infrastructure as code. Automate deployment processes.',
      instructor: 'Sanjay Kumar',
      lastUpdated: '04 Feb, 2026',
      duration: '3 months',
      level: 'Advanced',
      progress: 0
    },
    '14': {
      id: '14',
      title: 'SQL and Database Management',
      description: 'Master SQL queries, database design, normalization, indexing, and optimization. Work with MySQL and PostgreSQL.',
      instructor: 'Meenakshi Shah',
      lastUpdated: '05 Feb, 2026',
      duration: '2 months',
      level: 'Beginner',
      progress: 0
    },
    '15': {
      id: '15',
      title: 'Business Analytics',
      description: 'Learn data analysis, Excel, Tableau, Power BI, and business intelligence. Make data-driven business decisions.',
      instructor: 'Deepali Malhotra',
      lastUpdated: '06 Feb, 2026',
      duration: '3 months',
      level: 'Intermediate',
      progress: 0
    },
    '16': {
      id: '16',
      title: 'Node.js Backend Development',
      description: 'Build scalable backend APIs with Node.js, Express, MongoDB, authentication, and RESTful services.',
      instructor: 'Karthik Reddy',
      lastUpdated: '07 Feb, 2026',
      duration: '3 months',
      level: 'Intermediate',
      progress: 0
    },
    '17': {
      id: '17',
      title: 'Flutter Mobile Development',
      description: 'Create beautiful cross-platform mobile apps with Flutter and Dart. Build for iOS and Android simultaneously.',
      instructor: 'Pooja Agarwal',
      lastUpdated: '08 Feb, 2026',
      duration: '4 months',
      level: 'Intermediate',
      progress: 0
    },
    '18': {
      id: '18',
      title: 'Artificial Intelligence Basics',
      description: 'Introduction to AI concepts, neural networks, deep learning, and practical AI applications in real-world scenarios.',
      instructor: 'Dr. Sunil Kapoor',
      lastUpdated: '09 Feb, 2026',
      duration: '5 months',
      level: 'Advanced',
      progress: 0
    },
    '19': {
      id: '19',
      title: 'Photography Masterclass',
      description: 'Learn professional photography techniques, composition, lighting, editing with Lightroom and Photoshop.',
      instructor: 'Vivek Sharma',
      lastUpdated: '10 Feb, 2026',
      duration: '2 months',
      level: 'Beginner',
      progress: 0
    },
    '20': {
      id: '20',
      title: 'Content Writing & Copywriting',
      description: 'Master the art of writing compelling content for blogs, websites, social media, and marketing campaigns.',
      instructor: 'Anjali Mishra',
      lastUpdated: '11 Feb, 2026',
      duration: '6 weeks',
      level: 'Beginner',
      progress: 0
    }
  };

  // Current selected course
  course: Course = this.allCourses['1'];

  // Course modules
  modules: CourseModule[] = [];

  // All modules data with descriptions - Extended to all courses
  allModules: { [key: string]: CourseModule[] } = {
    '21': [
      {
        id: 1,
        title: 'Introduction to HTML',
        duration: '45 min',
        completed: false,
        description: 'HTML (HyperText Markup Language) is the standard language for creating web pages. It uses tags to structure content and define elements like headings, paragraphs, links, images, and more. In this module, you will learn the basics of HTML syntax, how to create your first web page, and understand the role of HTML in web development.',
        description2: 'HTML is the backbone of every website, providing the structure and content that browsers render. It works in conjunction with CSS for styling and JavaScript for interactivity. Learning HTML is essential for anyone interested in web development, as it forms the foundation upon which all web applications are built.'
      },
      {
        id: 2,
        title: 'HTML Basics',
        duration: '1 hour',
        completed: false,
        description: 'HTML uses tags to define elements on a web page. In this module, you will learn about common HTML tags such as headings (h1-h6), paragraphs (p), links (a), images (img), and how to structure your HTML document with the doctype, html, head, and body tags.',
        description2: 'Understanding the basic structure of an HTML document is crucial for creating well-formed web pages. You will also learn about attributes that can be added to HTML tags to provide additional information or functionality, such as href for links and src for images.'
      },
      {
        id: 3,
        title: 'Structure & Elements',
        duration: '1.5 hours',
        completed: false,
        description: 'Structure your web pages with divs, spans, and semantic elements. Learn about block-level vs inline elements, nesting rules, and how to create a well-organized HTML document.',
        description2: 'Properly structuring your HTML is important for both readability and accessibility. Semantic elements like header, nav, article, section, and footer help define the different parts of a web page, making it easier for search engines and assistive technologies to understand the content.'
      },
      {
        id: 4,
        title: 'Lists and Tables',
        duration: '1 hour',
        completed: false,
        description: 'List items with ordered (ol) and unordered (ul) lists, and create tables with the table tag. Learn about table rows (tr), headers (th), and data cells (td) to display tabular data effectively.',
        description2: 'Lists and tables are essential for organizing content on a web page. Lists are great for grouping related items, while tables are ideal for displaying structured data. Understanding how to use these elements correctly will enhance the usability and presentation of your web pages.'
      },
      {
        id: 5,
        title: 'Forms & Input Elements',
        duration: '2 hours',
        completed: false,
        description: 'Build interactive forms with various input types, labels, buttons, textareas, and select dropdowns. Understand form validation and submission.',
        description2: 'Forms are a critical part of web applications, allowing users to input and submit data. In this module, you will learn how to create various form elements, understand their attributes, and implement basic form validation techniques.'
      },
      {
        id: 6,
        title: 'Semantic HTML',
        duration: '1 hour',
        completed: false,
        description: 'Semantic HTML uses meaningful tags to structure content, improving accessibility and SEO. Learn about semantic elements like header, nav, article, section, and footer.',
        description2: 'Using semantic HTML not only enhances the accessibility of your web pages but also helps search engines understand the content better. This module will teach you how to use semantic tags effectively to create well-structured and accessible web pages.'
      },
      {
        id: 7,
        title: 'Multimedia Elements',
        duration: '45 min',
        completed: false,
        description: 'Embed images, videos, and audio in your web pages. Learn about the picture element, video controls, and multimedia optimization.',
        description2: 'Multimedia elements are essential for creating engaging web pages. In this module, you will learn how to properly embed and optimize images, videos, and audio files to enhance user experience while maintaining performance.'
      },
      {
        id: 8,
        title: 'Best Practices & Projects',
        duration: '1.5 hours',
        completed: false,
        description: 'Apply HTML best practices, learn about accessibility, and build complete projects including a portfolio page and a landing page.',
        description2: 'In this final module, you will apply all the HTML best practices you have learned throughout the course. You will also learn about accessibility considerations and build two complete projects: a portfolio page and a landing page. These projects will demonstrate your ability to create well-structured, accessible, and visually appealing web pages.'
      },
    ],
    '1': [
      {
        id: 1,
        title: 'Angular Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Angular, a powerful front-end framework developed by Google, has revolutionized the way modern web applications are built. For newcomers to web development, Angular can seem to be a great choice due to its features, concepts, and terminologies. In this article, we\'ll see more about the journey of Angular by providing a beginner-friendly introduction to its key concepts. By the end, you\'ll have a solid understanding of Angular\'s core principles, setting the stage for your exploration and mastery of this powerful framework.',
        description2: 'Angular is a comprehensive framework for building dynamic and responsive web applications. It provides a structured approach to development, making it easier to manage complex applications. Angular\'s component-based architecture allows developers to create reusable UI elements, while its powerful data binding and dependency injection features streamline the development process. With Angular, you can build everything from simple single-page applications to large-scale enterprise solutions.'
      },
      {
        id: 2,
        title: 'Components & Templates',
        duration: '3 hours',
        completed: false,
        description: 'Components are the fundamental building blocks of Angular applications. A component controls a patch of the screen called a view. Each component in Angular encapsulates a part of the user interface, along with the logic that controls the behaviour of that interface. Components are reusable, self-contained units that can be composed together to build complex UIs. A component in Angular is defined by three key parts: Template: Defines the HTML view for the component. Class: Contains the data and the logic that powers the template. Metadata: Provides additional information to Angular about how the component should be processed and used.',
        description2: 'Templates in Angular are HTML files that define the structure and layout of the user interface. They can include Angular-specific syntax for data binding, directives, and event handling. The template is associated with a component class, which provides the data and logic that the template uses to render the view. Angular\'s powerful templating system allows developers to create dynamic and interactive user interfaces with ease.'
      },
      {
        id: 3,
        title: 'Services & Dependency Injection',
        duration: '2.5 hours',
        completed: false,
        description: 'Services in Angular are used to share data and logic across different components. They are typically used for tasks such as fetching data from APIs, managing state, or implementing business logic. Dependency Injection (DI) is a design pattern that allows a class to receive its dependencies from an external source rather than creating them itself. In Angular, DI is built-in and allows you to inject services into components or other services, making it easier to manage dependencies and promote code reusability.',
        description2: 'By using services and dependency injection, you can keep your components lean and focused on the user interface, while the services handle the data and logic. This separation of concerns leads to more maintainable and testable code.'
      },
      {
        id: 4,
        title: 'Routing & Navigation',
        duration: '2 hours',
        completed: false,
        description: 'Implement client-side routing, route parameters, child routes, route guards, and lazy loading for better application performance.',
        description2: 'Routing in Angular allows you to navigate between different views in your application. It enables you to create single-page applications with multiple views that are dynamically loaded based on the URL. Route guards help control access to specific routes, and lazy loading improves application performance by loading modules only when needed.'
      },
      {
        id: 5,
        title: 'Forms & Validation',
        duration: '3 hours',
        completed: false,
        description: 'Build template-driven and reactive forms, implement custom validators, handle form submission, and manage form state effectively.',
        description2: 'In Angular, forms are a critical part of user interaction. Template-driven forms are simpler to set up and are good for basic use cases, while reactive forms offer more control and are better suited for complex applications. Custom validators allow you to enforce specific business rules, and managing form state effectively ensures a smooth user experience.'
      },
      {
        id: 6,
        title: 'HTTP & API Integration',
        duration: '2.5 hours',
        completed: false,
        description: 'Handle HTTP requests and responses, work with RESTful APIs, manage error handling, and implement interceptors for authentication and logging.',
        description2: 'In Angular, the HttpClient module is used to make HTTP requests to a server. It provides a simple API for sending requests and handling responses. You can handle errors gracefully, implement interceptors for cross-cutting concerns like authentication, and work with RESTful APIs by following standard conventions.'
      },
      {
        id: 7,
        title: 'State Management',
        duration: '3 hours',
        completed: false,
        description: 'Manage application state with NgRx, understand actions, reducers, selectors, and effects for handling side effects in Angular applications.',
        description2: 'State management is crucial for maintaining the consistency of data across your application. NgRx is a popular state management library for Angular that implements the Redux pattern. It helps you manage complex state in a predictable way, making it easier to debug and test your application.'
      },
      {
        id: 8,
        title: 'Testing & Deployment',
        duration: '2 hours',
        completed: false,
        description: 'Write unit tests with Jasmine and Karma, perform e2e testing, optimize builds, and deploy Angular applications to production.',
        description2: 'Testing is a critical part of any Angular application. Unit tests help ensure individual components and services work as expected. End-to-end tests verify the application behaves correctly from the user\'s perspective. Optimizing builds improves performance, and deploying to production involves setting up the correct environment and configurations.'
      },
    ],
    '2': [
      {
        id: 1,
        title: 'React Basics & JSX',
        duration: '2 hours',
        completed: false,
        description: 'React is a popular JavaScript library for building user interfaces, developed by Facebook. It allows developers to create reusable UI components and manage the state of their applications efficiently. JSX (JavaScript XML) is a syntax extension for JavaScript that looks similar to HTML and is used in React to describe the UI structure. In this module, you will learn the fundamentals of React, including how to create components, use JSX to define the UI, and understand the virtual DOM.',
        description2: 'React\'s component-based architecture allows you to break down your UI into smaller, reusable pieces. JSX makes it easier to write and understand the structure of your components. By learning React basics and JSX, you will be well-equipped to start building dynamic and interactive web applications.'
      },
      {
        id: 2,
        title: 'Components & Props',
        duration: '2.5 hours',
        completed: false,
        description: 'Components are the building blocks of React applications. They can be functional or class-based and are responsible for rendering the UI and managing their own state. Props (short for properties) are a way to pass data from parent components to child components. In this module, you will learn how to create and use components, pass data with props, and understand the unidirectional data flow in React.',
        description2: 'By mastering components and props, you can create modular and reusable UI elements. This allows for better organization of your code and makes it easier to maintain and scale your applications.'
      },
      {
        id: 3,
        title: 'State & Lifecycle',
        duration: '2 hours',
        completed: false,
        description: 'State is a built-in object that allows components to create and manage their own data. Lifecycle methods are special methods in class components that allow you to run code at specific points in a component\'s life, such as when it mounts, updates, or unmounts. In this module, you will learn how to use state to manage data within components and how to utilize lifecycle methods to control component behavior.',
        description2: 'Understanding state and lifecycle is crucial for building dynamic applications. State allows your components to respond to user input and changes in data, while lifecycle methods give you control over how your components behave at different stages of their existence.'
      },
      {
        id: 4,
        title: 'Hooks (useState, useEffect)',
        duration: '3 hours',
        completed: false,
        description: 'Hooks are functions that let you use state and other React features without writing a class. The useState hook allows you to add state to functional components, while the useEffect hook lets you perform side effects in your components, such as fetching data or subscribing to events. In this module, you will learn how to use these hooks to manage state and side effects in your React applications.',
        description2: 'UseState and useEffect are the most commonly used hooks in React. They enable you to write functional components that can manage state and perform side effects, making your code cleaner and more concise. By mastering hooks, you can take full advantage of React\'s capabilities and build powerful applications with less boilerplate code.'
      },
      {
        id: 5,
        title: 'Context API',
        duration: '2 hours',
        completed: false,
        description: 'Context API is a React feature that allows you to share state across the entire component tree without having to pass props down manually at every level. It is useful for managing global state, such as user authentication or theme settings. In this module, you will learn how to create and use context to manage global state in your React applications.',
        description2: 'The Context API provides a way to pass data through the component tree without having to pass props down manually at every level. This is especially useful for global data that many components need to access, such as user information or application settings. By using context, you can simplify your component structure and avoid prop drilling.'
      },
      {
        id: 6,
        title: 'Redux Fundamentals',
        duration: '3 hours',
        completed: false,
        description: 'Redux is a predictable state container for JavaScript applications. It helps you manage the state of your application in a single, centralized store. In this module, you will learn the core concepts of Redux, including actions, reducers, and the store. You will also learn how to integrate Redux with React to manage complex application state.',
        description2: 'Redux provides a structured way to manage state in your applications. By centralizing your state in a single store, you can easily track changes and debug your application. Redux also promotes a unidirectional data flow, making it easier to understand how data changes over time. Integrating Redux with React allows you to build scalable applications with complex state management needs.'
      },
      {
        id: 7,
        title: 'Routing with React Router',
        duration: '2 hours',
        completed: false,
        description: 'React Router is a popular library for handling routing in React applications. It allows you to create single-page applications with multiple views that are dynamically loaded based on the URL. In this module, you will learn how to set up React Router, define routes, and navigate between different views in your application.',
        description2: 'Routing is an essential part of any web application, and React Router provides a powerful and flexible solution for managing navigation in your React applications. By learning how to use React Router, you can create dynamic and responsive user interfaces that provide a seamless user experience.'
      },
      {
        id: 8,
        title: 'Final Project',
        duration: '3 hours',
        completed: false,
        description: 'Build a complete React application combining all concepts learned: components, hooks, routing, state management, and API integration.',
        description2: 'In this final project, you will apply all the concepts you have learned throughout the course to build a complete React application. This project will involve creating components, managing state with hooks, implementing routing with React Router, and integrating with an API to fetch and display data. By completing this project, you will have a solid understanding of how to build real-world applications with React.'
      },
    ],
    '3': [
      {
        id: 1,
        title: 'Introduction to MERN Stack',
        duration: '2 hours',
        completed: false,
        description: 'MERN stack is a popular web development stack that consists of MongoDB, Express.js, React, and Node.js. It allows developers to build full-stack applications using JavaScript for both the frontend and backend. In this module, you will learn the basics of each technology in the MERN stack and how they work together to create powerful web applications.',
        description2: 'The MERN stack provides a comprehensive solution for building modern web applications. MongoDB is a NoSQL database that allows for flexible data storage, Express.js is a web application framework for Node.js that simplifies backend development, React is a frontend library for building user interfaces, and Node.js is a runtime environment that allows you to run JavaScript on the server. By learning the MERN stack, you can build full-stack applications with ease and efficiency.'
      },
      {
        id: 2,
        title: 'MongoDB Fundamentals',
        duration: '4 hours',
        completed: false,
        description: 'MongoDB is a NoSQL database that stores data in flexible, JSON-like documents. In this module, you will learn how to set up MongoDB, create databases and collections, perform CRUD operations, and use Mongoose for object data modeling.',
        description2: 'MongoDB is designed for scalability and flexibility, making it a great choice for modern web applications. By learning MongoDB fundamentals, you will be able to manage your application\'s data effectively and efficiently, allowing you to build powerful and responsive applications.'
      },
      {
        id: 3,
        title: 'Express.js Basics',
        duration: '3 hours',
        completed: false,
        description: 'Express.js is a web application framework for Node.js that simplifies backend development. In this module, you will learn how to set up an Express server, define routes, handle requests and responses, and implement middleware for tasks like authentication and error handling.',
        description2: 'Express.js is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications. By mastering Express.js, you will be able to build scalable and maintainable backend applications with ease.'
      },
      {
        id: 4,
        title: 'React Frontend Development',
        duration: '6 hours',
        completed: false,
        description: 'React is a powerful frontend library for building user interfaces. In this module, you will learn how to create React components, manage state with hooks, implement routing with React Router, and integrate with the backend API.',
        description2: 'React allows you to build dynamic and responsive user interfaces with ease. By learning React frontend development, you will be able to create engaging and interactive web applications that provide a seamless user experience.'
      },
      {
        id: 5,
        title: 'Node.js Backend',
        duration: '5 hours',
        completed: false,
        description: 'Node.js is a runtime environment that allows you to run JavaScript on the server. In this module, you will learn how to set up a Node.js server, handle routing and middleware with Express.js, and connect to MongoDB for data storage.',
        description2: 'Node.js is built on Chrome\'s V8 JavaScript engine and provides an event-driven, non-blocking I/O model that makes it lightweight and efficient. By mastering Node.js backend development, you will be able to build fast and scalable server-side applications that can handle a large number of concurrent connections.'
      },
      {
        id: 6,
        title: 'REST API Development',
        duration: '4 hours',
        completed: false,
        description: 'Rest APIs (Representational State Transfer) are a common way to structure backend services. In this module, you will learn how to design and implement RESTful APIs with Express.js, handle different HTTP methods, and manage API endpoints effectively.',
        description2: 'REST APIs allow you to create a standardized way for clients to interact with your backend services. By learning how to develop REST APIs, you will be able to build flexible and scalable applications that can easily integrate with various frontend frameworks and third-party services.'
      },
      {
        id: 7,
        title: 'Authentication & Security',
        duration: '3 hours',
        completed: false,
        description: 'Authentication is a critical aspect of any web application. In this module, you will learn how to implement user authentication with JWT (JSON Web Tokens), manage user sessions, and secure your application against common vulnerabilities.',
        description2: 'By implementing robust authentication and security measures, you can protect your application and its users from unauthorized access and potential threats. This module will cover best practices for securing your MERN stack applications and ensuring the safety of user data.'
      },
      {
        id: 8,
        title: 'Deployment & Production',
        duration: '2 hours',
        completed: false,
        description: 'Deploy your MERN stack application to production using services like Heroku, AWS, or DigitalOcean. Learn about environment variables, build optimization, and best practices for deploying web applications.',
        description2: 'Deploying your application to production is the final step in the development process. By learning how to deploy your MERN stack application, you can make it accessible to users around the world and ensure that it runs smoothly in a production environment.'
      }
    ],
    '4': [
      {
        id: 1,
        title: 'Python Basics',
        duration: '3 hours',
        completed: false,
        description: 'Python is a versatile and powerful programming language that is widely used in data science, machine learning, web development, and more. In this module, you will learn the fundamentals of Python programming, including syntax, variables, data types, control structures, and functions. This foundational knowledge will set the stage for your journey into data science with Python.',
        description2: 'Python\'s simplicity and readability make it an excellent choice for beginners. By mastering Python basics, you will be able to write clean and efficient code, which is essential for data analysis and machine learning tasks. This module will provide you with the necessary skills to start working with Python and prepare you for more advanced topics in data science.'
      },
      {
        id: 2,
        title: 'NumPy Arrays',
        duration: '2 hours',
        completed: false,
        description: 'Master NumPy for numerical computing, array operations, mathematical functions, broadcasting, and vectorization.',
        description2: 'NumPy is a fundamental library for scientific computing in Python. It provides support for large, multi-dimensional arrays and matrices, along with a collection of mathematical functions to operate on these arrays. By learning NumPy, you will be able to perform complex numerical computations efficiently, which is essential for data analysis and machine learning tasks.'
      },
      {
        id: 3,
        title: 'Pandas DataFrames',
        duration: '4 hours',
        completed: false,
        description: 'Work with Pandas for data manipulation, data cleaning, filtering, grouping, merging datasets, and time series analysis.',
        description2: 'Pandas is a powerful data manipulation library in Python that provides data structures and functions for working with structured data. By mastering Pandas, you will be able to efficiently manipulate and analyze large datasets, which is a crucial skill in data science and machine learning.'
      },
      {
        id: 4,
        title: 'Data Visualization',
        duration: '3 hours',
        completed: false,
        description: 'Create visualizations with Matplotlib and Seaborn, plot charts, graphs, customize plots, and tell stories with data.',
        description2: 'Data visualization is a critical skill in data science that helps communicate insights effectively. Matplotlib and Seaborn are two popular Python libraries for creating visualizations. By mastering these tools, you will be able to create clear, informative, and visually appealing plots that help tell compelling stories with your data.'
      },
      {
        id: 5,
        title: 'Statistics for Data Science',
        duration: '3 hours',
        completed: false,
        description: 'Statistics is the backbone of data science. In this module, you will learn about descriptive statistics, probability distributions, hypothesis testing, and regression analysis. These concepts are essential for understanding data and making informed decisions based on your analysis.',
        description2: 'By mastering statistics for data science, you will be able to analyze data effectively, draw meaningful conclusions, and make data-driven decisions. This module will provide you with the necessary statistical knowledge to excel in your data science journey.'
      },
      {
        id: 6,
        title: 'Machine Learning Basics',
        duration: '4 hours',
        completed: false,
        description: 'Machine learning is a subset of artificial intelligence that allows computers to learn from data and make predictions or decisions without being explicitly programmed. In this module, you will learn the basics of machine learning, including supervised and unsupervised learning, common algorithms, and how to implement machine learning models using Python.',
        description2: 'By understanding machine learning basics, you will be able to build predictive models and gain insights from data. This module will cover essential machine learning concepts and provide you with the skills to start building your own machine learning models.'
      },
      {
        id: 7,
        title: 'Scikit-learn',
        duration: '3 hours',
        completed: false,
        description: 'Build machine learning models with Scikit-learn, preprocessing, feature engineering, model selection, and hyperparameter tuning.',
        description2: 'Scikit-learn is a powerful Python library for machine learning. In this module, you will learn how to use Scikit-learn to build and evaluate machine learning models, preprocess data, engineer features, and tune hyperparameters for optimal performance.'
      },
      {
        id: 8,
        title: 'Real-world Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply data science skills to real-world projects including exploratory data analysis, predictive modeling, and insights generation.',
        description2: 'In this final module, you will apply all the data science skills you have learned to real-world projects. You will work on end-to-end projects that involve data cleaning, exploratory data analysis, building predictive models, and generating actionable insights from data.'
      }
    ],
    '5': [
      {
        id: 1,
        title: 'Java Fundamentals',
        duration: '3 hours',
        completed: false,
        description: 'Java is a powerful, object-oriented programming language that is widely used in enterprise applications, web development, and mobile development. This module covers Java fundamentals including syntax, variables, data types, operators, and control structures.',
        description2: 'By mastering Java fundamentals, you will have a solid foundation in programming concepts and be well-prepared to explore more advanced topics in Java development.'
      },
      {
        id: 2,
        title: 'Object-Oriented Programming',
        duration: '4 hours',
        completed: false,
        description: 'Object-oriented programming (OOP) is a programming paradigm that uses objects and classes to structure code. In this module, you will learn the core principles of object-oriented programming in Java. You will understand how to design and implement classes and objects, work with inheritance and polymorphism, and apply encapsulation and abstraction to build robust and maintainable Java applications.',
        description2: 'Encapsulation allows you to hide the internal state of an object and only expose a public interface, while abstraction helps you focus on essential features without getting bogged down in implementation details. Inheritance enables you to create new classes based on existing ones, promoting code reuse and a hierarchical class structure. Polymorphism allows you to use a single interface to represent different underlying data types, making your code more flexible and extensible. Compile time polymorphism (method overloading) and runtime polymorphism (method overriding) are key concepts that enable you to write dynamic and adaptable code in Java. By mastering these OOP principles, you will be able to design and implement complex Java applications with ease.'
      },
      {
        id: 3,
        title: 'Collections Framework',
        duration: '3 hours',
        completed: false,
        description: 'The Java Collections Framework provides a set of classes and interfaces for working with groups of objects. In this module, you will learn about the different types of collections in Java, including lists, sets, maps, and queues. You will understand how to use these collections effectively to store and manipulate data in your Java applications.',
        description2: 'The Collections Framework provides a powerful and flexible way to work with groups of objects in Java. Collections main interfaces include List, Set, Map, and Queue, each with its own characteristics and use cases. Lists allow for ordered collections that can contain duplicates, while Sets are unordered collections that do not allow duplicates. Maps store key-value pairs and provide efficient lookups based on keys. Queues are used for holding elements prior to processing and typically follow a first-in-first-out (FIFO) order. Deque is a double-ended queue that allows insertion and removal of elements from both ends. By mastering the Collections Framework, you will be able to choose the right data structures for your applications and manipulate data efficiently.'
      },
      {
        id: 4,
        title: 'Exception Handling',
        duration: '2 hours',
        completed: false,
        description: 'Exception handling is a crucial aspect of Java programming that allows you to manage and respond to runtime errors gracefully. In this module, you will learn how to use try-catch blocks to handle exceptions, create custom exceptions, and understand the exception hierarchy in Java.',
        description2: 'Types of exceptions in Java include checked exceptions, which must be declared in a method\'s throws clause and handled by the caller, and unchecked exceptions, which are subclasses of RuntimeException and do not require explicit handling. By mastering exception handling, you can ensure that your Java applications are robust and can handle unexpected situations without crashing.try-catch blocks allow you to catch and handle exceptions that may occur during the execution of your code, while custom exceptions enable you to create your own exception types that are specific to your application\'s needs. Understanding the exception hierarchy in Java will help you effectively manage errors and maintain the stability of your applications.'
      },
      {
        id: 5,
        title: 'Multithreading',
        duration: '3 hours',
        completed: false,
        description: 'Multithreading is a powerful feature of Java that allows you to run multiple threads of execution concurrently. In this module, you will learn how to create and manage threads in Java, understand thread synchronization, and work with thread communication.',
        description2: 'Multithreading can improve the performance of your Java applications by allowing multiple tasks to run simultaneously. You will learn how to create threads using the Thread class and the Runnable interface, manage thread lifecycle, and synchronize threads to prevent race conditions. Thread communication techniques such as wait(), notify(), and notifyAll() will also be covered to help you coordinate the execution of multiple threads effectively.'
      },
      {
        id: 6,
        title: 'File I/O Operations',
        duration: '2 hours',
        completed: false,
        description: 'Read and write files, work with streams, serialization, and handle file system operations.',
        description2: 'File I/O operations in Java allow you to read from and write to files on the file system. You will learn how to work with streams, including input and output streams, and how to serialize objects to and from files. This knowledge is essential for handling data persistence in Java applications. Types of streams include byte streams for handling binary data and character streams for handling text data. By mastering file I/O operations, you can effectively manage data storage and retrieval in your Java applications. InputStream and OutputStream are the base classes for byte streams, while Reader and Writer are the base classes for character streams. Serialization allows you to convert an object into a byte stream for storage or transmission, and deserialization allows you to reconstruct the object from the byte stream. By understanding these concepts, you can efficiently handle file operations in your Java applications.'
      },
      {
        id: 7,
        title: 'Spring Boot Framework',
        duration: '5 hours',
        completed: false,
        description: 'Spring Boot is a popular framework for building Java applications, particularly web applications and microservices. In this module, you will learn how to use Spring Boot to create stand-alone, production-grade applications with ease. You will understand how to set up a Spring Boot project, work with Spring MVC for building web applications, and create RESTful services that expose data and functionality over HTTP. Spring Boot simplifies the development process by providing a wide range of features and auto-configuration options, allowing you to focus on writing business logic rather than dealing with complex configurations. It is widely used in enterprise development for its ease of configuration and rapid application development capabilities.',
        description2: 'Spring Boot simplifies the creation of stand-alone, production-grade Spring-based applications. You will learn how to use dependency injection to manage object creation and lifecycle, implement Spring MVC for building web applications, and create RESTful services that expose data and functionality over HTTP. This framework is widely used in enterprise development for its ease of configuration and rapid application development capabilities. Rest APIs are a key part of Spring Boot applications, enabling communication between different services and clients.'
      },
      {
        id: 8,
        title: 'Building Applications',
        duration: '4 hours',
        completed: false,
        description: 'Build complete Java applications integrating all concepts learned: OOP, collections, exception handling, multithreading, file I/O, and Spring Boot.',
        description2: 'In this module, you will learn how to integrate all the concepts you have learned so far to build complete Java applications. You will work with backend services, database integration, and other essential components to create robust and scalable applications. This hands-on experience will help you apply your knowledge in real-world scenarios and prepare you for professional development tasks. By the end of this module, you will have the skills and confidence to build complex Java applications that can handle a variety of use cases and requirements. Complete Java applications often involve integrating multiple technologies and frameworks, such as Spring Boot for backend development, databases for data storage, and various libraries for additional functionality. By mastering the skills covered in this module, you will be well-equipped to tackle real-world Java development projects with confidence and expertise.'
      }
    ],
    '6': [
      {
        id: 1,
        title: 'Digital Marketing Introduction',
        duration: '1 hour',
        completed: false,
        description: 'Digital marketing encompasses all marketing efforts that use electronic devices or the internet. Businesses leverage digital channels such as search engines, social media, email, and websites to connect with current and prospective customers. This module introduces you to the fundamentals of digital marketing and its importance in today\'s business landscape.',
        description2: 'You will learn about different digital marketing channels including SEO, SEM, social media marketing, content marketing, email marketing, and affiliate marketing. Understanding the digital marketing ecosystem will help you create effective strategies to reach your target audience and achieve your business goals. Digital marketing provides measurable results and allows for real-time adjustments to campaigns.'
      },
      {
        id: 2,
        title: 'SEO Fundamentals',
        duration: '3 hours',
        completed: false,
        description: 'Search Engine Optimization (SEO) is the practice of increasing the quantity and quality of traffic to your website through organic search engine results. In this module, you will learn about on-page SEO, off-page SEO, technical SEO, and local SEO strategies.',
        description2: 'On-page SEO involves optimizing individual web pages to rank higher and earn more relevant traffic, including content quality, keyword research, meta tags, and internal linking. Off-page SEO focuses on building your website\'s reputation and authority through backlinks and social signals. Technical SEO ensures that search engines can crawl and index your site effectively. You will also learn about keyword research tools, Google Search Console, and how to track your SEO performance over time.'
      },
      {
        id: 3,
        title: 'Social Media Marketing',
        duration: '2 hours',
        completed: false,
        description: 'Social media marketing involves creating and sharing content on social media networks to achieve your marketing and branding goals. This module covers strategies for major platforms including Facebook, Instagram, Twitter, LinkedIn, and TikTok.',
        description2: 'You will learn how to create engaging content, build a community, run paid advertising campaigns, and measure social media ROI. Understanding audience demographics and platform algorithms will help you maximize your reach and engagement. Social media marketing is essential for brand awareness, customer engagement, and driving website traffic.'
      },
      {
        id: 4,
        title: 'Content Marketing',
        duration: '2 hours',
        completed: false,
        description: 'Content marketing is a strategic marketing approach focused on creating and distributing valuable, relevant content to attract and retain a clearly defined audience. This module teaches you how to develop content strategies, create compelling content, and distribute it effectively.',
        description2: 'You will learn about different types of content including blog posts, videos, infographics, podcasts, and ebooks. Understanding your audience\'s needs and creating content that addresses their pain points is crucial for success. Content marketing helps establish thought leadership, build trust, and drive profitable customer action.'
      },
      {
        id: 5,
        title: 'Email Campaigns',
        duration: '2 hours',
        completed: false,
        description: 'Email marketing remains one of the most effective digital marketing channels. In this module, you will learn how to build email lists, create compelling email campaigns, segment your audience, and automate email sequences.',
        description2: 'You will understand email design best practices, A/B testing strategies, and how to measure email marketing performance through metrics like open rates, click-through rates, and conversion rates. Email marketing platforms like Mailchimp, Constant Contact, and SendGrid will be explored. Personalization and automation are key to successful email marketing campaigns.'
      },
      {
        id: 6,
        title: 'Google Analytics',
        duration: '2 hours',
        completed: false,
        description: 'Google Analytics is a powerful web analytics service that tracks and reports website traffic. This module teaches you how to set up Google Analytics, understand key metrics, create custom reports, and use data to make informed marketing decisions.',
        description2: 'You will learn about acquisition reports, behavior reports, conversion tracking, and goal setting. Understanding user behavior on your website helps you optimize the user experience and improve conversion rates. Google Analytics 4 (GA4) introduces new features including enhanced measurement, predictive metrics, and cross-platform tracking.'
      },
      {
        id: 7,
        title: 'Paid Advertising',
        duration: '3 hours',
        completed: false,
        description: 'Paid advertising includes Google Ads, Facebook Ads, Instagram Ads, and other PPC (Pay-Per-Click) platforms. This module covers campaign setup, audience targeting, ad creation, budget management, and performance optimization.',
        description2: 'You will learn about different ad formats, bidding strategies, remarketing campaigns, and conversion tracking. Understanding how to calculate ROI and optimize campaigns based on performance data is essential. Paid advertising provides immediate visibility and allows for precise targeting of your ideal customers.'
      },
      {
        id: 8,
        title: 'Campaign Strategy',
        duration: '2 hours',
        completed: false,
        description: 'Developing an integrated digital marketing campaign strategy involves coordinating multiple channels to achieve specific business objectives. This module teaches you how to set SMART goals, identify target audiences, allocate budgets, and measure campaign success.',
        description2: 'You will learn about customer journey mapping, multi-channel attribution, and how to create cohesive campaigns that deliver consistent messaging across all touchpoints. A well-planned campaign strategy ensures that all marketing efforts work together to maximize impact and ROI.'
      }
    ],
    '7': [
      {
        id: 1,
        title: 'Design Principles',
        duration: '2 hours',
        completed: false,
        description: 'Fundamental design principles form the foundation of effective UI/UX design. This module covers key concepts including balance, contrast, hierarchy, alignment, proximity, repetition, and whitespace. Understanding these principles will help you create visually appealing and functional designs.',
        description2: 'You will learn how to apply Gestalt principles to create intuitive interfaces, use color theory effectively, and understand typography basics. Good design is invisible—it facilitates user tasks without drawing attention to itself. These principles apply across all design disciplines and are essential for creating professional-quality work.'
      },
      {
        id: 2,
        title: 'Figma Basics',
        duration: '3 hours',
        completed: false,
        description: 'Figma is a collaborative interface design tool that has become the industry standard for UI/UX design. This module teaches you how to navigate Figma\'s interface, use frames and layers, create components, and leverage auto-layout for responsive designs.',
        description2: 'You will learn about Figma\'s collaborative features including real-time editing, commenting, and design handoff. Understanding constraints, variants, and prototyping in Figma will enable you to create complex, interactive designs. Figma\'s cloud-based nature makes it accessible from anywhere and facilitates seamless team collaboration.'
      },
      {
        id: 3,
        title: 'User Research',
        duration: '2 hours',
        completed: false,
        description: 'User research is essential for understanding your target audience\'s needs, behaviors, and pain points. This module covers various research methods including user interviews, surveys, usability testing, and analytics analysis.',
        description2: 'You will learn how to create user personas, develop empathy maps, and conduct competitive analysis. Understanding qualitative and quantitative research methods will help you make data-driven design decisions. User research ensures that your designs solve real problems and meet actual user needs rather than assumptions.'
      },
      {
        id: 4,
        title: 'Wireframing',
        duration: '3 hours',
        completed: false,
        description: 'Wireframing is the process of creating low-fidelity sketches of your interface before diving into high-fidelity designs. This module teaches you how to create effective wireframes that communicate layout, structure, and functionality without getting bogged down in visual details.',
        description2: 'You will learn about different wireframing techniques including paper sketching, digital wireframes, and annotated wireframes. Understanding information architecture and user flows will help you create logical, user-friendly layouts. Wireframing saves time by allowing you to iterate quickly and get stakeholder feedback early in the design process.'
      },
      {
        id: 5,
        title: 'Prototyping',
        duration: '3 hours',
        completed: false,
        description: 'Prototyping brings your designs to life by creating interactive simulations of your product. This module covers low-fidelity and high-fidelity prototyping techniques, including click-through prototypes, animated transitions, and micro-interactions.',
        description2: 'You will learn how to use Figma\'s prototyping features to create realistic user experiences for testing and presentation. Understanding different levels of prototype fidelity and when to use each will help you validate ideas efficiently. Prototypes are invaluable for user testing, stakeholder presentations, and developer handoff.'
      },
      {
        id: 6,
        title: 'Design Systems',
        duration: '2 hours',
        completed: false,
        description: 'A design system is a collection of reusable components, guidelines, and standards that ensure consistency across products. This module teaches you how to create and maintain design systems, including component libraries, color palettes, typography scales, and spacing systems.',
        description2: 'You will learn about atomic design methodology, component variants, and documentation best practices. Design systems improve efficiency, maintain brand consistency, and facilitate collaboration between designers and developers. Major companies like Google (Material Design) and Apple (Human Interface Guidelines) have established comprehensive design systems that set industry standards.'
      },
      {
        id: 7,
        title: 'Usability Testing',
        duration: '2 hours',
        completed: false,
        description: 'Usability testing involves evaluating your design by testing it with real users. This module covers how to plan and conduct usability tests, recruit participants, create test scripts, and analyze results to improve your designs.',
        description2: 'You will learn about different testing methods including moderated and unmoderated testing, A/B testing, and remote testing. Understanding how to synthesize feedback and prioritize improvements is crucial for iterative design. Usability testing helps identify issues before launch, saving time and resources while ensuring a better user experience.'
      },
      {
        id: 8,
        title: 'Portfolio Projects',
        duration: '4 hours',
        completed: false,
        description: 'Building a strong portfolio is essential for showcasing your UI/UX design skills to potential employers or clients. This module guides you through creating portfolio-worthy projects that demonstrate your design process, problem-solving abilities, and final outcomes.',
        description2: 'You will learn how to document your design process through case studies, present your work effectively, and build an online portfolio website. Understanding what employers look for in portfolios and how to stand out in a competitive market will help you launch your UI/UX career. Quality over quantity—focus on 3-5 well-documented projects that show depth and range.'
      }
    ],
    '8': [
      {
        id: 1,
        title: 'ML Introduction',
        duration: '2 hours',
        completed: false,
        description: 'Machine Learning is a subset of artificial intelligence that enables computers to learn from data without being explicitly programmed. This module introduces fundamental concepts including supervised learning, unsupervised learning, reinforcement learning, and the machine learning workflow.',
        description2: 'You will learn about the difference between traditional programming and machine learning, understand when to use ML, and explore real-world applications across industries. The module covers data preparation, feature engineering, model selection, training, and evaluation. Understanding these fundamentals is crucial before diving into specific algorithms and techniques.'
      },
      {
        id: 2,
        title: 'Supervised Learning',
        duration: '4 hours',
        completed: false,
        description: 'Supervised learning involves training models on labeled data to make predictions. This comprehensive module covers classification and regression algorithms including linear regression, logistic regression, decision trees, random forests, and support vector machines.',
        description2: 'You will learn how to prepare datasets, split data into training and testing sets, handle categorical variables, and evaluate model performance using metrics like accuracy, precision, recall, F1-score, and R-squared. Understanding bias-variance tradeoff and overfitting prevention techniques is essential. Practical applications include spam detection, price prediction, and customer churn prediction.'
      },
      {
        id: 3,
        title: 'Unsupervised Learning',
        duration: '3 hours',
        completed: false,
        description: 'Unsupervised learning deals with unlabeled data to discover hidden patterns and structures. This module covers clustering algorithms like K-means and hierarchical clustering, dimensionality reduction techniques like PCA, and anomaly detection methods.',
        description2: 'You will learn how to determine optimal cluster numbers, interpret clustering results, and apply dimensionality reduction for visualization and feature engineering. Unsupervised learning is particularly useful for customer segmentation, recommendation systems, and exploratory data analysis when labeled data is unavailable.'
      },
      {
        id: 4,
        title: 'Neural Networks',
        duration: '4 hours',
        completed: false,
        description: 'Neural networks are the foundation of deep learning, inspired by biological neural networks in the human brain. This module covers perceptrons, multi-layer perceptrons, activation functions, backpropagation, and optimization algorithms.',
        description2: 'You will learn how to build neural networks from scratch and using frameworks, understand gradient descent optimization, handle vanishing/exploding gradients, and apply regularization techniques. Neural networks excel at complex pattern recognition tasks and form the basis for advanced architectures used in computer vision and natural language processing.'
      },
      {
        id: 5,
        title: 'Deep Learning',
        duration: '5 hours',
        completed: false,
        description: 'Deep learning uses neural networks with multiple hidden layers to learn hierarchical representations of data. This module covers Convolutional Neural Networks (CNNs) for computer vision, Recurrent Neural Networks (RNNs) for sequential data, and transfer learning techniques.',
        description2: 'You will learn about popular architectures like ResNet, VGG, and LSTM, understand how to handle image data, and apply pre-trained models for various tasks. Deep learning has revolutionized fields like computer vision, natural language processing, and speech recognition, achieving human-level performance on many tasks.'
      },
      {
        id: 6,
        title: 'TensorFlow',
        duration: '4 hours',
        completed: false,
        description: 'TensorFlow is Google\'s open-source machine learning framework widely used for building and deploying ML models. This module teaches you TensorFlow basics, Keras API for building neural networks, model training, and deployment strategies.',
        description2: 'You will learn about TensorFlow datasets, data pipelines, model checkpointing, and TensorBoard for visualization. Understanding how to save and load models, convert models for deployment, and optimize inference performance is crucial for production applications. TensorFlow supports deployment across various platforms including mobile, web, and edge devices.'
      },
      {
        id: 7,
        title: 'Model Optimization',
        duration: '3 hours',
        completed: false,
        description: 'Model optimization involves improving model performance through hyperparameter tuning, feature engineering, and architecture optimization. This module covers grid search, random search, Bayesian optimization, and AutoML approaches.',
        description2: 'You will learn about cross-validation techniques, learning curves analysis, and how to prevent overfitting through regularization, dropout, and early stopping. Understanding model compression techniques like pruning and quantization is important for deploying models on resource-constrained devices. Systematic optimization can significantly improve model accuracy and efficiency.'
      },
      {
        id: 8,
        title: 'ML Projects',
        duration: '5 hours',
        completed: false,
        description: 'Apply all learned concepts to build end-to-end machine learning projects. This module guides you through project selection, problem formulation, data collection and preparation, model development, evaluation, and deployment.',
        description2: 'You will work on diverse projects including image classification, sentiment analysis, recommendation systems, and predictive modeling. Learning to document your work, create presentations, and explain technical concepts to non-technical audiences is emphasized. Building a portfolio of ML projects demonstrates practical skills to potential employers.'
      }
    ],
    '9': [
      {
        id: 1,
        title: 'Cloud Computing Overview',
        duration: '1 hour',
        completed: false,
        description: 'Cloud computing provides on-demand access to computing resources over the internet. This module introduces you to cloud service models (IaaS, PaaS, SaaS), deployment models (public, private, hybrid), and key benefits of cloud computing.',
        description2: 'Cloud computing enables scalability, flexibility, and cost-efficiency for businesses. You will learn about major cloud providers like AWS, Azure, and Google Cloud, and understand how to choose the right cloud services for different use cases. Cloud computing is essential for modern application development and deployment.'
      },
      {
        id: 2,
        title: 'AWS Fundamentals',
        duration: '3 hours',
        completed: false,
        description: 'Amazon Web Services (AWS) is the leading cloud platform offering a wide range of services. This module covers AWS core services including EC2 for compute, S3 for storage, RDS for databases, and Lambda for serverless computing.',
        description2: 'You will learn how to set up an AWS account, navigate the AWS Management Console, and use the AWS CLI for resource management. Understanding AWS pricing models, security best practices, and how to architect applications on AWS is crucial for leveraging the full potential of the platform.'
      },
      {
        id: 3,
        title: 'Azure Fundamentals',
        duration: '3 hours',
        completed: false,
        description: 'Microsoft Azure is a comprehensive cloud platform with a wide range of services. This module covers Azure core services including Virtual Machines, Blob Storage, Azure SQL Database, and Azure Functions for serverless computing.',
        description2: 'You will learn how to set up an Azure account, navigate the Azure Portal, and use Azure CLI for resource management. Understanding Azure pricing models, security best practices, and how to architect applications on Azure is essential for maximizing the benefits of the platform.'
      },
      {
        id: 4,
        title: 'Google Cloud Fundamentals',
        duration: '3 hours',
        completed: false,
        description: 'Google Cloud Platform (GCP) offers a range of cloud services for compute, storage, databases, and machine learning. This module covers GCP core services including Compute Engine, Cloud Storage, Cloud SQL, and Cloud Functions.',
        description2: 'You will learn how to set up a GCP account, navigate the Google Cloud Console, and use gcloud CLI for resource management. Understanding GCP pricing models, security best practices, and how to architect applications on GCP is crucial for leveraging the platform effectively.'
      },
      {
        id: 5,
        title: 'Cloud Security',
        duration: '2 hours',
        completed: false,
        description: 'Cloud security involves protecting data, applications, and infrastructure in the cloud. This module covers identity and access management (IAM), encryption, network security, and compliance considerations for cloud environments.',
        description2: 'You will learn about best practices for securing cloud resources, implementing least privilege access, and using security tools provided by cloud providers. Understanding shared responsibility models and how to mitigate common security risks is essential for maintaining a secure cloud environment.'
      },
      {
        id: 6,
        title: 'Cloud Architecture',
        duration: '3 hours',
        completed: false,
        description: 'Cloud architecture involves designing and building applications that leverage cloud services effectively. This module covers architectural patterns, microservices, serverless architecture, and best practices for scalability and reliability in the cloud.',
        description2: 'You will learn how to design cloud-native applications, use managed services, and implement best practices for performance optimization and cost management. Understanding how to architect applications for the cloud is crucial for building scalable and resilient systems.'
      },
      {
        id: 7,
        title: 'DevOps in the Cloud',
        duration: '3 hours',
        completed: false,
        description: 'DevOps practices are essential for continuous integration and continuous deployment (CI/CD) in the cloud. This module covers DevOps tools and practices for automating build, test, and deployment processes in cloud environments.',
        description2: 'You will learn about CI/CD pipelines, infrastructure as code (IaC), and monitoring and logging in the cloud. Understanding how to implement DevOps practices in the cloud is crucial for accelerating development cycles and improving application reliability.'
      },
      {
        id: 8,
        title: 'Cloud Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply all learned concepts to build end-to-end cloud projects. This module guides you through project selection, architecture design, implementation, and deployment in the cloud.',
        description2: 'You will work on diverse projects including web applications, serverless APIs, and data processing pipelines. Learning to document your work, create presentations, and explain technical concepts to non-technical audiences is emphasized. Building a portfolio of cloud projects demonstrates practical skills to potential employers.'
      }
    ],
    '10': [
      {
        id: 1,
        title: 'Mobile Development Overview',
        duration: '2 hours',
        completed: false,
        description: 'An overview of mobile development concepts, including native vs. cross-platform development, mobile UI/UX principles, and popular frameworks like React Native and Flutter.',
        description2: 'Mobile development involves creating applications for mobile devices such as smartphones and tablets. This module introduces you to the different approaches to mobile development, including native development for specific platforms (iOS and Android) and cross-platform development that allows you to build applications for multiple platforms from a single codebase. You will also learn about mobile UI/UX design principles to create engaging and user-friendly interfaces, as well as an introduction to popular mobile development frameworks like React Native and Flutter that enable efficient cross-platform development.'
      },
      {
        id: 2,
        title: 'Learn Kotlin for Android',
        duration: '3 hours',
        completed: false,
        description: 'Kotlin is the preferred language for Android development. This module covers Kotlin syntax, features, and how to use it for building Android applications.',
        description2: 'You will learn about Kotlin\'s concise syntax, null safety features, and interoperability with Java. Understanding how to use Kotlin for Android development will enable you to create modern, efficient, and maintainable applications.'
      },
      {
        id: 3,
        title: 'Learn Swift for iOS',
        duration: '3 hours',
        completed: false,
        description: 'Swift is the programming language for iOS development. This module covers Swift syntax, features, and how to use it for building iOS applications.',
        description2: 'You will learn about Swift\'s powerful features, including optionals, closures, and protocol-oriented programming. Understanding how to use Swift for iOS development will enable you to create high-quality applications for the Apple ecosystem.'
      },
      {
        id: 4,
        title: 'Cross-Platform Development',
        duration: '4 hours',
        completed: false,
        description: 'Cross-platform development allows you to build applications that run on multiple platforms from a single codebase. This module covers popular frameworks like React Native and Flutter, and how to choose the right one for your project.',
        description2: 'You will learn about the advantages and trade-offs of cross-platform development, how to set up development environments, and best practices for building performant and native-like applications using these frameworks.'
      },
      {
        id: 5,
        title: 'Mobile App Deployment',
        duration: '2 hours',
        completed: false,
        description: 'Mobile app deployment involves submitting your app to app stores and managing updates. This module covers the app store submission process, version control strategies, and how to handle app updates and bug fixes in production environments.',
        description2: 'Mobile app deployment requires understanding the guidelines and requirements of app stores, as well as strategies for maintaining and updating your app post-launch. You will learn how to navigate the submission process, manage user feedback, and implement continuous improvement practices for your mobile applications.'
      },
      {
        id: 6,
        title: 'Learn Flutter for Cross-Platform',
        duration: '5 hours',
        completed: false,
        description: 'Flutter is a powerful framework for building cross-platform mobile applications. This module covers Flutter basics, widgets, state management, and how to build responsive UIs.',
        description2: 'Widgets are the building blocks of Flutter applications, and understanding how to use them effectively is crucial for creating engaging user interfaces. You will learn about different types of widgets, layout techniques, and state management solutions to build high-quality cross-platform apps with Flutter. state management is a critical aspect of Flutter development, and you will explore various approaches including Provider, Bloc, and Riverpod to manage application state efficiently. Responsive UI design is essential for creating applications that look great on different screen sizes and orientations, and you will learn how to implement responsive design principles in Flutter to ensure a seamless user experience across all devices.'
      },
      {
        id: 7,
        title: 'React Native for Cross-Platform',
        duration: '5 hours',
        completed: false,
        description: 'React Native is a popular framework for building cross-platform mobile applications using JavaScript and React. This module covers React Native basics, components, state management, and how to build responsive UIs.',
        description2: 'React Native allows you to build mobile applications using JavaScript and React, enabling code reuse across platforms. React Native components are the building blocks of your application, and understanding how to use them effectively is crucial for creating engaging user interfaces. Layout techniques in React Native involve using Flexbox for responsive design, and you will learn how to create layouts that adapt to different screen sizes and orientations. State management is a critical aspect of React Native development, and you will explore various approaches including Redux, MobX, and the Context API to manage application state efficiently. Responsive UI design is essential for creating applications that look great on different devices, and you will learn how to implement responsive design principles in React Native to ensure a seamless user experience across all platforms.'
      },
      {
        id: 8,
        title: 'Mobile Projects',
        duration: '5 hours',
        completed: false,
        description: 'Apply all learned concepts to build end-to-end mobile projects. This module guides you through project selection, architecture design, implementation, and deployment in mobile platforms.',
        description2: 'Mobile projects provide an opportunity to apply all the concepts you have learned throughout the course. You will work on diverse projects including social media apps, e-commerce platforms, and productivity tools. Learning to document your work, create presentations, and explain technical concepts to non-technical audiences is emphasized. Building a portfolio of mobile projects demonstrates practical skills to potential employers and helps you stand out in the competitive mobile development job market. Mobile development is a rapidly evolving field, and having a strong portfolio of projects can showcase your ability to adapt to new technologies and trends in the industry. You can choose projects that align with your interests and career goals, whether it\'s building a game, a utility app, or a social networking platform. The key is to demonstrate your ability to design, develop, and deploy high-quality mobile applications that provide value to users. Mobile projects also allow you to explore different aspects of mobile development, such as user interface design, performance optimization, and integration with backend services. By working on real-world projects, you can gain practical experience and build confidence in your mobile development skills, making you more attractive to potential employers or clients in the mobile app development industry.'
      }
    ],
    '11': [
      {
        id: 1,
        title: 'Cybersecurity Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Cybersecurity is the practice of protecting systems, networks, and data from digital attacks. This module introduces fundamental cybersecurity concepts including threat types, attack vectors, and basic defense strategies.',
        description2: 'You will learn about common cyber threats such as malware, phishing, and ransomware, as well as basic security principles like confidentiality, integrity, and availability. Understanding the cybersecurity landscape is essential for protecting yourself and your organization from cyber attacks.'
      },
    ],
    '12': [
      {
        id: 1,
        title: 'Blockchain Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Blockchain is a decentralized ledger technology that enables secure and transparent transactions. This module introduces you to blockchain concepts including distributed ledgers, consensus mechanisms, and smart contracts. Mechanisms such as Proof of Work and Proof of Stake ensure the integrity of the blockchain, while smart contracts enable automated and trustless transactions. Understanding these fundamentals is crucial for exploring the potential applications of blockchain technology across various industries.',
        description2: 'ledgers are the backbone of blockchain technology, providing a secure and transparent way to record transactions. You will learn about different consensus mechanisms such as Proof of Work and Proof of Stake, and how they ensure the integrity of the blockchain. Smart contracts are self-executing contracts with the terms directly written into code, enabling automated and trustless transactions. Understanding these fundamentals is crucial for exploring the potential applications of blockchain technology across various industries. Smart contracts enable the creation of decentralized applications (DApps) that can operate without intermediaries, opening up new possibilities for innovation in finance, supply chain management, and more.'
      },
      {
        id: 2,
        title: 'DApp Development',
        duration: '3 hours',
        completed: false,
        description: 'Decentralized applications (DApps) are applications that run on a blockchain network. This module covers the development of DApps using frameworks like Ethereum and Hyperledger, including smart contract development with Solidity. Ethereum is a popular blockchain platform for building DApps, and Solidity is the primary programming language for writing smart contracts on Ethereum. You will learn how to set up a development environment, write and deploy smart contracts, and build user interfaces that interact with the blockchain. Understanding the principles of decentralized application development is essential for leveraging the unique capabilities of blockchain technology. Hyperledger is another blockchain framework that focuses on enterprise use cases, providing tools and libraries for building permissioned blockchain networks. You will explore the differences between public and private blockchains, and how to choose the right platform for your DApp development projects.',
        description2: 'smart contract development with Solidity is a key aspect of DApp development. You will learn how to write smart contracts that define the logic and rules of your decentralized application, and how to deploy them to the blockchain. Building user interfaces that interact with the blockchain involves using libraries like Web3.js or Ethers.js to connect your frontend application to the smart contracts deployed on the blockchain. Understanding the principles of decentralized application development is essential for leveraging the unique capabilities of blockchain technology. Hyperledger is another blockchain framework that focuses on enterprise use cases, providing tools and libraries for building permissioned blockchain networks. You will explore the differences between public and private blockchains, and how to choose the right platform for your DApp development projects.'
      },
      {
        id: 3,
        title: 'Blockchain Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply all learned concepts to build end-to-end blockchain projects. This module guides you through project selection, architecture design, implementation, and deployment on blockchain platforms. Architecture design involves planning the structure of your blockchain application, including how smart contracts will interact with each other and with the user interface. Implementation involves writing smart contracts, developing the frontend, and integrating with the blockchain network. Deployment includes testing your application on testnets before launching it on the mainnet. By working on real-world projects, you can gain practical experience and build confidence in your blockchain development skills, making you more attractive to potential employers or clients in the blockchain industry. Deploying your blockchain projects on platforms like Ethereum or Hyperledger allows you to demonstrate your ability to build decentralized applications that leverage the unique features of blockchain technology. You will learn how to navigate the deployment process, manage gas fees, and ensure that your application is secure and efficient. Building a portfolio of blockchain projects can showcase your practical skills and help you stand out in the competitive blockchain job market.',
        description2: 'Projects selection is a crucial step in applying your blockchain knowledge to real-world scenarios. You will work on diverse projects such as decentralized finance (DeFi) applications, supply chain tracking systems, and digital identity solutions. Learning to document your work, create presentations, and explain technical concepts to non-technical audiences is emphasized. Building a portfolio of blockchain projects demonstrates practical skills to potential employers and helps you stand out in the competitive blockchain job market. Blockchain technology is rapidly evolving, and having a strong portfolio of projects can showcase your ability to adapt to new technologies and trends in the industry. You can choose projects that align with your interests and career goals, whether it\'s building a decentralized exchange, a voting system, or a tokenized asset platform. The key is to demonstrate your ability to design, develop, and deploy high-quality blockchain applications that provide value to users. Implementing best practices for security, scalability, and user experience in your blockchain projects will further enhance your portfolio and make you a more attractive candidate for blockchain development roles.'
      },
      {
        id: 4,
        title: 'Advanced Blockchain Concepts',
        duration: '3 hours',
        completed: false,
        description: 'Explore advanced blockchain concepts such as layer 2 solutions, interoperability, and decentralized finance (DeFi). Layer 2 solutions like rollups and sidechains aim to improve scalability and reduce transaction costs on blockchain networks. Interoperability refers to the ability of different blockchain networks to communicate and interact with each other, enabling cross-chain applications and asset transfers. Decentralized finance (DeFi) is a rapidly growing sector that leverages blockchain technology to create financial services without intermediaries, including lending platforms, decentralized exchanges, and stablecoins. Understanding these advanced concepts is essential for staying at the forefront of blockchain innovation and exploring new opportunities in the industry.',
        description2: 'Layer 2 solutions like rollups and sidechains aim to improve scalability and reduce transaction costs on blockchain networks. You will learn about different types of layer 2 solutions, how they work, and their advantages and trade-offs. Interoperability refers to the ability of different blockchain networks to communicate and interact with each other, enabling cross-chain applications and asset transfers. You will explore interoperability protocols and tools that facilitate communication between blockchains. Decentralized finance (DeFi) is a rapidly growing sector that leverages blockchain technology to create financial services without intermediaries, including lending platforms, decentralized exchanges, and stablecoins. Understanding these advanced concepts is essential for staying at the forefront of blockchain innovation and exploring new opportunities in the industry.'
      },
      {
        id: 5,
        title: 'Blockchain Security',
        duration: '3 hours',
        completed: false,
        description: 'Blockchain security involves protecting blockchain networks and applications from vulnerabilities and attacks. This module covers common security risks in blockchain development, best practices for secure smart contract development, and strategies for mitigating security threats.',
        description2: 'Blockchain networks and applications can be vulnerable to various security risks, including smart contract vulnerabilities, 51% attacks, and phishing scams. You will learn about common security risks in blockchain development and how to identify and mitigate them. Best practices for secure smart contract development include using established libraries, conducting thorough testing, and following secure coding guidelines. Strategies for mitigating security threats involve implementing multi-signature wallets, using hardware security modules (HSMs), and staying informed about the latest security developments in the blockchain industry. Ensuring the security of your blockchain applications is crucial for protecting user assets and maintaining trust in your projects.'
      },
      {
        id: 6,
        title: 'Future of Blockchain',
        duration: '2 hours',
        completed: false,
        description: 'Explore the future of blockchain technology, including emerging trends, potential applications, and challenges. Emerging trends in blockchain include the rise of non-fungible tokens (NFTs), the growth of decentralized autonomous organizations (DAOs), and the integration of blockchain with other technologies like artificial intelligence and the Internet of Things (IoT). Potential applications of blockchain span various industries, including finance, supply chain management, healthcare, and digital identity. Challenges facing the future of blockchain include scalability issues, regulatory uncertainty, and environmental concerns related to energy consumption. Understanding these trends, applications, and challenges is essential for staying informed about the future direction of blockchain technology and identifying opportunities for innovation.',
        description2: 'Emerging trends in blockchain include the rise of non-fungible tokens (NFTs), the growth of decentralized autonomous organizations (DAOs), and the integration of blockchain with other technologies like artificial intelligence and the Internet of Things (IoT). You will explore these trends and their implications for the future of blockchain technology. Potential applications of blockchain span various industries, including finance, supply chain management, healthcare, and digital identity. You will learn about innovative use cases for blockchain technology and how it can transform traditional industries. Challenges facing the future of blockchain include scalability issues, regulatory uncertainty, and environmental concerns related to energy consumption. Understanding these challenges is crucial for navigating the evolving landscape of blockchain technology and identifying opportunities for innovation. Artificial intelligence and the Internet of Things (IoT) are two technologies that are increasingly being integrated with blockchain to create new possibilities for decentralized applications. You will explore how AI can enhance blockchain applications through improved data analysis and decision-making, while IoT can benefit from blockchain\'s secure and transparent data management capabilities. The future of blockchain technology is promising, with ongoing advancements and innovations that have the potential to reshape industries and create new opportunities for developers and businesses alike.'
      },
      {
        id: 7,
        title: 'Blockchain Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply all learned concepts to build end-to-end blockchain projects. This module guides you through project selection, architecture design, implementation, and deployment on blockchain platforms.',
        description2: 'Projects selection is a crucial step in applying your blockchain knowledge to real-world scenarios. You will work on diverse projects such as decentralized finance (DeFi) applications, supply chain tracking systems, and digital identity solutions. Learning to document your work, create presentations, and explain technical concepts to non-technical audiences is emphasized. Building a portfolio of blockchain projects demonstrates practical skills to potential employers and helps you stand out in the competitive blockchain job market. Blockchain technology is rapidly evolving, and having a strong portfolio of projects can showcase your ability to adapt to new technologies and trends in the industry. You can choose projects that align with your interests and career goals, whether it\'s building a decentralized exchange, a voting system, or a tokenized asset platform. The key is to demonstrate your ability to design, develop, and deploy high-quality blockchain applications that provide value to users. Implementing best practices for security, scalability, and user experience in your blockchain projects will further enhance your portfolio and make you a more attractive candidate for blockchain development roles.'
      },
      {
        id: 8,
        title: 'Blockchain Importance',
        duration: '4 hours',
        completed: false,
        description: 'Understand why blockchain technology is important and how it is transforming industries. This module explores the core principles of blockchain, its benefits, and its potential impact on various sectors.',
        description2: 'Blockchain technology is important because it provides a secure, transparent, and decentralized way to record and verify transactions. It eliminates the need for intermediaries, reduces costs, and increases efficiency in various industries. Understanding the importance of blockchain helps you appreciate its potential applications in finance, supply chain management, healthcare, and more. You will learn about key concepts such as immutability, consensus mechanisms, and smart contracts that make blockchain technology so powerful. Recognizing the transformative potential of blockchain is essential for anyone looking to work in or invest in this rapidly growing field.'
      }
    ],
    '13': [
      {
        id: 1,
        title: 'DevOps Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'DevOps is a set of practices that combines software development (Dev) and IT operations (Ops) to shorten the development lifecycle and provide continuous delivery with high software quality. This module introduces you to DevOps principles, culture, and the importance of collaboration between development and operations teams. DevOps principles include continuous integration, continuous delivery, infrastructure as code, and monitoring and logging. Understanding these principles is essential for implementing efficient software delivery processes and improving overall product quality. Embracing a DevOps culture fosters a mindset of shared responsibility and continuous improvement, which is crucial for the success of modern software development projects.',
        description2: 'Importances of DevOps include faster time to market, improved collaboration, increased efficiency, and higher quality software. By adopting DevOps practices, organizations can accelerate their development cycles, reduce the risk of errors, and deliver better products to customers. Development teams and operations teams work together to automate processes, improve communication, and ensure that software is delivered reliably and efficiently. DevOps is essential for organizations looking to stay competitive in today\'s fast-paced technology landscape.'
      },
      {
        id: 2,
        title: 'Version Control with Git',
        duration: '3 hours',
        completed: false,
        description: 'Git is a distributed version control system that tracks changes in source code during software development. This module covers Git basics, branching strategies, merging, and collaboration workflows. Git Basics include initializing repositories, committing changes, and managing branches. Branching strategies such as Git Flow and GitHub Flow help teams manage their development process effectively. Merging involves combining changes from different branches, and understanding how to resolve conflicts is crucial for maintaining code integrity. Collaboration workflows include using pull requests, code reviews, and integrating with platforms like GitHub and GitLab. Mastering Git is essential for effective collaboration in development teams and maintaining a clear history of code changes.',
        description2: 'colleboration branching strategies such as Git Flow and GitHub Flow help teams manage their development process effectively. Merging involves combining changes from different branches, and understanding how to resolve conflicts is crucial for maintaining code integrity. Collaboration workflows include using pull requests, code reviews, and integrating with platforms like GitHub and GitLab. Mastering Git is essential for effective collaboration in development teams and maintaining a clear history of code changes.'
      },
      {
        id: 3,
        title: 'CI/CD Pipelines',
        duration: '4 hours',
        completed: false,
        description: 'Continuous Integration (CI) is the practice of automatically integrating code changes into a shared repository, while Continuous Delivery (CD) is the practice of automatically deploying code changes to production. This module covers CI/CD concepts, tools like Jenkins and GitHub Actions, and how to implement CI/CD pipelines for automated testing and deployment. CD (Continuous Delivery) is the practice of automatically deploying code changes to production. This module covers CI/CD concepts, tools like Jenkins and GitHub Actions, and how to implement CI/CD pipelines for automated testing and deployment. Both CI and CD are essential for accelerating development cycles, improving software quality, and ensuring that code changes are delivered to customers efficiently. CI/CD pipelines include stages such as build, test, and deploy, which automate the software delivery process and help teams catch issues early, reduce manual errors, and accelerate the release of new features and updates to customers. Implementing CI/CD pipelines is crucial for organizations looking to improve their software development processes and deliver high-quality products in a timely manner.',
        description2: 'pipeline stages include build, test, and deploy. Automate the software delivery process, ensuring that code changes are tested and deployed efficiently. Implementing CI/CD pipelines helps teams catch issues early, reduce manual errors, and accelerate the release of new features and updates to customers. CI/CD is essential for organizations looking to improve their software development processes and deliver high-quality products in a timely manner. By automating the build, test, and deployment stages, teams can focus on writing code and delivering value to customers rather than managing manual processes. CI/CD pipelines also enable teams to implement best practices such as automated testing, code quality checks, and continuous monitoring, which are crucial for maintaining the reliability and performance of applications in production environments.'
      },
      {
        id: 4,
        title: 'Infrastructure as Code',
        duration: '3 hours',
        completed: false,
        description: 'Infrastructure as Code (IaC) is the process of managing and provisioning computing infrastructure through machine-readable definition files. This module covers IaC tools like Terraform and Ansible. Terraform is an open-source IaC tool that allows you to define and provision infrastructure using a declarative configuration language. Ansible is an open-source automation tool that can be used for configuration management, application deployment, and task automation. Both tools enable you to manage infrastructure in a consistent and repeatable way, reducing the risk of manual errors and improving efficiency. Understanding how to use IaC tools is essential for modern DevOps practices and helps teams manage complex infrastructure environments effectively. Infrastructure as Code (IaC) enables consistent and repeatable infrastructure deployment across environments. By defining infrastructure in code, teams can version control their infrastructure changes, collaborate more effectively, and automate provisioning processes. This leads to faster deployment times, improved reliability, and better scalability of applications. Implementing IaC is crucial for organizations looking to adopt DevOps practices and manage their infrastructure efficiently in cloud environments.',
        description2: 'Version control infrastructure changes allows teams to track changes, collaborate effectively, and roll back to previous configurations if needed. By defining infrastructure in code, teams can automate provisioning processes, reduce manual errors, and improve the reliability and scalability of applications. Implementing IaC is crucial for organizations looking to adopt DevOps practices and manage their infrastructure efficiently in cloud environments. IaC tools like Terraform and Ansible provide powerful features for managing infrastructure, including support for multiple cloud providers, modular configurations, and integration with CI/CD pipelines. By mastering IaC, you can streamline your infrastructure management processes and ensure that your applications are deployed consistently and reliably across different environments. Understanding how to use IaC tools is essential for modern DevOps practices and helps teams manage complex infrastructure environments effectively. Infrastructure as Code (IaC) enables consistent and repeatable infrastructure deployment across environments. By defining infrastructure in code, teams can version control their infrastructure changes, collaborate more effectively, and automate provisioning processes. This leads to faster deployment times, improved reliability, and better scalability of applications. Implementing IaC is crucial for organizations looking to adopt DevOps practices and manage their infrastructure efficiently in cloud environments. IaC tools like Terraform and Ansible provide powerful features for managing infrastructure, including support for multiple cloud providers, modular configurations, and integration with CI/CD pipelines. By mastering IaC, you can streamline your infrastructure management processes and ensure that your applications are deployed consistently and reliably across different environments.'
      },
      {
        id: 5,
        title: 'Containerization with Docker',
        duration: '4 hours',
        completed: false,
        description: 'Docker is a platform for developing, shipping, and running applications in containers. This module covers Docker fundamentals, creating Dockerfiles, managing containers, and orchestration with Docker Compose. Docker allows you to package applications and their dependencies into a standardized unit called a container, which can run consistently across different environments. You will learn how to create Dockerfiles to define your application\'s environment, manage containers using Docker CLI, and orchestrate multi-container applications with Docker Compose. Understanding containerization is essential for modern DevOps practices and helps teams achieve consistent application deployment, scalability, and efficient resource utilization. Docker enables consistent application deployment across different environments and simplifies scaling. By using containers, teams can ensure that their applications run the same way in development, testing, and production environments, reducing the risk of environment-related issues. Docker also allows for efficient resource utilization by running multiple containers on the same host, and it simplifies scaling applications by allowing you to easily add or remove containers as needed. Mastering Docker is crucial for anyone looking to work in DevOps or modern software development practices. Working with Docker will give you the skills to create, manage, and deploy containerized applications, which are essential for building scalable and reliable software in today\'s technology landscape. Modern software development practices often involve using containers to ensure consistency across different environments and to simplify the deployment process. Docker is a widely used platform for containerization, and understanding how to use it effectively is essential for modern DevOps practices. By learning Docker fundamentals, creating Dockerfiles, managing containers, and orchestrating with Docker Compose, you can streamline your application deployment process and improve the scalability and reliability of your applications.',
        description2: 'Container benefits include consistent application deployment across different environments and simplified scaling. By using containers, teams can ensure that their applications run the same way in development, testing, and production environments, reducing the risk of environment-related issues. Docker also allows for efficient resource utilization by running multiple containers on the same host, and it simplifies scaling applications by allowing you to easily add or remove containers as needed. Mastering Docker is crucial for anyone looking to work in DevOps or modern software development practices. Working with Docker will give you the skills to create, manage, and deploy containerized applications, which are essential for building scalable and reliable software in today\'s technology landscape. Modern software development practices often involve using containers to ensure consistency across different environments and to simplify the deployment process. Docker is a widely used platform for containerization, and understanding how to use it effectively is essential for modern DevOps practices. By learning Docker fundamentals, creating Dockerfiles, managing containers, and orchestrating with Docker Compose, you can streamline your application deployment process and improve the scalability and reliability of your applications. Containerization with Docker is a key skill for modern software development and DevOps practices. By mastering Docker, you can create, manage, and deploy containerized applications that are consistent across different environments, scalable, and efficient in resource utilization. Understanding how to use Docker effectively will enable you to streamline your application deployment process and improve the overall quality and reliability of your software. Docker is an essential tool for anyone looking to work in DevOps or modern software development practices, and learning how to use it effectively will open up new opportunities for building and deploying applications in today\'s technology landscape. Containerization with Docker is a key skill for modern software development and DevOps practices. By mastering Docker, you can create, manage, and deploy containerized applications that are consistent across different environments, scalable, and efficient in resource utilization. Understanding how to use Docker effectively will enable you to streamline your application deployment process and improve the overall quality and reliability of your software. Docker is an essential tool for anyone looking to work in DevOps or modern software development practices, and learning how to use it effectively will open up new opportunities for building and deploying applications in today\'s technology landscape. Containerization with Docker is a key skill for modern software development and DevOps practices. By mastering Docker, you can create, manage, and deploy containerized applications that are consistent across different environments, scalable, and efficient in resource utilization. Understanding how to use Docker effectively will enable you to streamline your application deployment process and improve the overall quality and reliability of your software. Docker is an essential tool for anyone looking to work in DevOps or modern software development practices, and learning how to use it effectively will open up new opportunities for building and deploying applications in today\'s technology landscape.'
      },
      {
        id: 6,
        title: 'Kubernetes Orchestration',
        duration: '5 hours',
        completed: false,
        description: 'Kubernetes is an open-source container orchestration platform for automating deployment, scaling, and management of containerized applications. This module covers Kubernetes architecture, pods, services, and deployments. Pods are the smallest deployable units in Kubernetes that can contain one or more containers. Services provide a stable IP address and DNS name for accessing pods, while deployments manage the desired state of your application and ensure that the specified number of replicas are running. Understanding Kubernetes is essential for managing complex containerized applications at scale and is a key skill for modern DevOps practices. Modern software development often involves deploying applications in containerized environments, and Kubernetes is the leading platform for orchestrating these environments. By learning Kubernetes architecture, pods, services, and deployments, you can effectively manage and scale your containerized applications in production environments. Kubernetes provides powerful features for automating deployment, scaling, and management of applications, making it an essential tool for anyone looking to work in DevOps or modern software development practices. Understanding Kubernetes will enable you to build and maintain robust, scalable applications that can handle the demands of today\'s technology landscape. ',
        description2: 'Cluster management involves managing a group of nodes that run containerized applications. Kubernetes architecture includes components such as the API server, etcd, controller manager, and kubelet. Pods are the smallest deployable units in Kubernetes that can contain one or more containers. Services provide a stable IP address and DNS name for accessing pods, while deployments manage the desired state of your application and ensure that the specified number of replicas are running. Understanding Kubernetes is essential for managing complex containerized applications at scale and is a key skill for modern DevOps practices. Modern software development often involves deploying applications in containerized environments, and Kubernetes is the leading platform for orchestrating these environments. By learning Kubernetes architecture, pods, services, and deployments, you can effectively manage and scale your containerized applications in production environments. Kubernetes provides powerful features for automating deployment, scaling, and management of applications, making it an essential tool for anyone looking to work in DevOps or modern software development practices. Understanding Kubernetes will enable you to build and maintain robust, scalable applications that can handle the demands of today\'s technology landscape. Kubernetes is an essential tool for managing complex containerized applications at scale. By mastering Kubernetes, you can automate the deployment, scaling, and management of your applications, ensuring that they are reliable and efficient in production environments. Understanding Kubernetes architecture, pods, services, and deployments will enable you to effectively manage your containerized applications and take advantage of the powerful features that Kubernetes offers for modern software development and DevOps practices. Kubernetes is an essential tool for managing complex containerized applications at scale. By mastering Kubernetes, you can automate the deployment, scaling, and management of your applications, ensuring that they are reliable and efficient in production environments. Understanding Kubernetes architecture, pods, services, and deployments will enable you to effectively manage your containerized applications and take advantage of the powerful features that Kubernetes offers for modern software development and DevOps practices. Kubernetes is an essential tool for managing complex containerized applications at scale. By mastering Kubernetes, you can automate the deployment, scaling, and management of your applications, ensuring that they are reliable and efficient in production environments. Understanding Kubernetes architecture, pods, services, and deployments will enable you to effectively manage your containerized applications and take advantage of the powerful features that Kubernetes offers for modern software development and DevOps practices. Kubernetes is an essential tool for managing complex containerized applications at scale. By mastering Kubernetes, you can automate the deployment, scaling, and management of your applications, ensuring that they are reliable and efficient in production environments. Understanding Kubernetes architecture, pods, services, and deployments will enable you to effectively manage your containerized applications and take advantage of the powerful features that Kubernetes offers for modern software development and DevOps practices.'
      },
      {
        id: 7,
        title: 'Monitoring and Logging',
        duration: '3 hours',
        completed: false,
        description: 'Monitoring and logging are essential for maintaining application health and troubleshooting issues. This module covers tools like Prometheus, Grafana, ELK stack, and best practices for observability. Prometheus is an open-source monitoring system that collects and stores metrics, while Grafana is a visualization tool that allows you to create dashboards for monitoring your applications. The ELK stack (Elasticsearch, Logstash, Kibana) is a popular solution for log aggregation and analysis. Best practices for observability include defining key performance indicators (KPIs), setting up alerts, and implementing structured logging. Effective monitoring and logging help teams identify and resolve issues quickly, ensuring high availability and performance of applications in production environments. Monitoring and logging are crucial for maintaining the health and performance of applications in production environments. By using tools like Prometheus, Grafana, and the ELK stack, teams can gain insights into application behavior, identify bottlenecks, and troubleshoot issues effectively. Best practices for observability include defining key performance indicators (KPIs) to measure application performance, setting up alerts to notify teams of potential issues, and implementing structured logging to facilitate log analysis. Effective monitoring and logging enable teams to proactively manage their applications, reduce downtime, and ensure a positive user experience. By mastering monitoring and logging tools and practices, you can enhance the reliability and performance of your applications in production environments. Monitoring and logging are crucial for maintaining the health and performance of applications in production environments. By using tools like Prometheus, Grafana, and the ELK stack, teams can gain insights into application behavior, identify bottlenecks, and troubleshoot issues effectively. Best practices for observability include defining key performance indicators (KPIs) to measure application performance, setting up alerts to notify teams of potential issues, and implementing structured logging to facilitate log analysis. Effective monitoring and logging enable teams to proactively manage their applications, reduce downtime, and ensure a positive user experience. By mastering monitoring and logging tools and practices, you can enhance the reliability and performance of your applications in production environments. Monitoring and logging are crucial for maintaining the health and performance of applications in production environments. By using tools like Prometheus, Grafana, and the ELK stack, teams can gain insights into application behavior, identify bottlenecks, and troubleshoot issues effectively. Best practices for observability include defining key performance indicators (KPIs) to measure application performance, setting up alerts to notify teams of potential issues, and implementing structured logging to facilitate log analysis. Effective monitoring and logging enable teams to proactively manage their applications, reduce downtime, and ensure a positive user experience. By mastering monitoring and logging tools and practices, you can enhance the reliability and performance of your applications in production environments.',
        description2: 'Metrics collection and visualization are essential for understanding application performance and identifying issues. Prometheus collects metrics from your applications and infrastructure, while Grafana allows you to create dashboards to visualize these metrics. The ELK stack (Elasticsearch, Logstash, Kibana) is a powerful solution for log aggregation and analysis, enabling you to search and analyze logs from your applications. By implementing effective monitoring and logging practices, you can ensure that your applications are running smoothly in production environments and quickly address any issues that arise. Monitoring and logging are crucial for maintaining the health and performance of applications in production environments. By using tools like Prometheus, Grafana, and the ELK stack, teams can gain insights into application behavior, identify bottlenecks, and troubleshoot issues effectively. Best practices for observability include defining key performance indicators (KPIs) to measure application performance, setting up alerts to notify teams of potential issues, and implementing structured logging to facilitate log analysis. Effective monitoring and logging enable teams to proactively manage their applications, reduce downtime, and ensure a positive user experience. By mastering monitoring and logging tools and practices, you can enhance the reliability and performance of your applications in production environments. Monitoring and logging are crucial for maintaining the health and performance of applications in production environments. By using tools like Prometheus, Grafana, and the ELK stack, teams can gain insights into application behavior, identify bottlenecks, and troubleshoot issues effectively. Best practices for observability include defining key performance indicators (KPIs) to measure application performance, setting up alerts to notify teams of potential issues, and implementing structured logging to facilitate log analysis. Effective monitoring and logging enable teams to proactively manage their applications, reduce downtime, and ensure a positive user experience. By mastering monitoring and logging tools and practices, you can enhance the reliability and performance of your applications in production environments. Monitoring and logging are crucial for maintaining the health and performance of applications in production environments. By using tools like Prometheus, Grafana, and the ELK stack, teams can gain insights into application behavior, identify bottlenecks, and troubleshoot issues effectively. Best practices for observability include defining key performance indicators (KPIs) to measure application performance, setting up alerts to notify teams of potential issues, and implementing structured logging to facilitate log analysis. Effective monitoring and logging enable teams to proactively manage their applications, reduce downtime, and ensure a positive user experience. By mastering monitoring and logging tools and practices, you can enhance the reliability and performance of your applications in production environments.'
      },
      {
        id: 8,
        title: 'DevOps Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply DevOps concepts to build end-to-end projects. This module guides you through setting up complete CI/CD pipelines, containerizing applications, and deploying to production environments. CD pipelines include stages such as build, test, and deploy. Automate the software delivery process, ensuring that code changes are tested and deployed efficiently. Implementing CI/CD pipelines helps teams catch issues early, reduce manual errors, and accelerate the release of new features and updates to customers. DevOps projects provide hands-on experience with real-world scenarios, allowing you to apply the concepts and tools you have learned throughout the course. By working on DevOps projects, you can demonstrate your ability to design, implement, and manage efficient software delivery processes that meet the demands of modern software development practices. DevOps projects often involve collaboration between development and operations teams, and they require a strong understanding of automation, infrastructure management, and monitoring. By completing DevOps projects, you can build a portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. Building DevOps projects helps you gain hands-on experience and prepare for real-world scenarios. By working on projects that involve setting up CI/CD pipelines, containerizing applications, and deploying to production environments, you can demonstrate your ability to apply DevOps concepts and tools effectively. DevOps projects provide valuable experience in managing the software delivery process, collaborating with cross-functional teams, and ensuring that applications are delivered reliably and efficiently to customers. By completing DevOps projects, you can build a strong portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios.',
        description2: 'Projects that demonstrate practical DevOps skills, including automated testing, infrastructure provisioning, and application monitoring. Building DevOps projects helps you gain hands-on experience and prepare for real-world scenarios. By working on projects that involve setting up CI/CD pipelines, containerizing applications, and deploying to production environments, you can demonstrate your ability to apply DevOps concepts and tools effectively. DevOps projects provide valuable experience in managing the software delivery process, collaborating with cross-functional teams, and ensuring that applications are delivered reliably and efficiently to customers. By completing DevOps projects, you can build a strong portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. DevOps projects often involve collaboration between development and operations teams, and they require a strong understanding of automation, infrastructure management, and monitoring. By completing DevOps projects, you can build a portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. Building DevOps projects helps you gain hands-on experience and prepare for real-world scenarios. By working on projects that involve setting up CI/CD pipelines, containerizing applications, and deploying to production environments, you can demonstrate your ability to apply DevOps concepts and tools effectively. DevOps projects provide valuable experience in managing the software delivery process, collaborating with cross-functional teams, and ensuring that applications are delivered reliably and efficiently to customers. By completing DevOps projects, you can build a strong portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. DevOps projects often involve collaboration between development and operations teams, and they require a strong understanding of automation, infrastructure management, and monitoring. By completing DevOps projects, you can build a portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. Building DevOps projects helps you gain hands-on experience and prepare for real-world scenarios. By working on projects that involve setting up CI/CD pipelines, containerizing applications, and deploying to production environments, you can demonstrate your ability to apply DevOps concepts and tools effectively. DevOps projects provide valuable experience in managing the software delivery process, collaborating with cross-functional teams, and ensuring that applications are delivered reliably and efficiently to customers. By completing DevOps projects, you can build a strong portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. DevOps projects often involve collaboration between development and operations teams, and they require a strong understanding of automation, infrastructure management, and monitoring. By completing DevOps projects, you can build a portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. Building DevOps projects helps you gain hands-on experience and prepare for real-world scenarios. By working on projects that involve setting up CI/CD pipelines, containerizing applications, and deploying to production environments, you can demonstrate your ability to apply DevOps concepts and tools effectively. DevOps projects provide valuable experience in managing the software delivery process, collaborating with cross-functional teams, and ensuring that applications are delivered reliably and efficiently to customers. By completing DevOps projects, you can build a strong portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios. DevOps projects often involve collaboration between development and operations teams, and they require a strong understanding of automation, infrastructure management, and monitoring. By completing DevOps projects, you can build a portfolio that showcases your practical skills and experience in implementing DevOps practices in real-world scenarios.'
      }
    ],
    '14': [
      {
        id: 1,
        title: 'SQL and Database Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'SQL (Structured Query Language) is the standard language for managing relational databases. This module introduces SQL basics, database design principles, and data modeling concepts. You will learn about different database types, normalization, entity-relationship diagrams, and the importance of data integrity. Understanding database fundamentals is essential for effective data management. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL Commands include SELECT, INSERT, UPDATE, DELETE, and basic querying techniques. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL Commands include DDL , DML , DQL , DCL , TCL . Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL Commands include SELECT, INSERT, UPDATE, DELETE, and basic querying techniques. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. DDL (Data Definition Language) includes commands like CREATE, ALTER, and DROP for defining database structures. DML (Data Manipulation Language) includes commands like INSERT, UPDATE, and DELETE for managing data within tables. DQL (Data Query Language) primarily consists of the SELECT command for querying data. DCL (Data Control Language) includes commands like GRANT and REVOKE for controlling access to data. TCL (Transaction Control Language) includes commands like COMMIT and ROLLBACK for managing transactions. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL JOINS are used to combine rows from two or more tables based on a related column. Types of joins include INNER JOIN, LEFT JOIN, RIGHT JOIN, and FULL JOIN. Aggregate functions like COUNT, SUM, AVG, MIN, and MAX are used to perform calculations on data. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL Selection and Projection involve retrieving specific columns (projection) and filtering rows based on conditions (selection). By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications.',
        description2: 'Database types include relational databases (e.g., MySQL, PostgreSQL) and NoSQL databases (e.g., MongoDB, Cassandra). Normalization is the process of organizing data to minimize redundancy and improve data integrity. Entity-relationship diagrams are visual representations of database structures, showing entities, attributes, and relationships. Understanding database fundamentals is essential for effective data management. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. NoSQL databases are designed for large-scale data storage and flexible schemas. Relational databases use structured query language (SQL) for defining and manipulating data, while NoSQL databases use various data models such as document, key-value, graph, or column-family. Understanding the differences between relational and NoSQL databases is essential for choosing the right database solution for your applications. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. Denormalization is the process of intentionally introducing redundancy into a database design to improve read performance at the cost of write performance and data integrity. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications.'
      },
      {
        id: 2,
        title: 'SQL Basics',
        duration: '3 hours',
        completed: false,
        description: 'SQL (Structured Query Language) is the standard language for managing relational databases. This module covers basic SQL commands including SELECT, INSERT, UPDATE, DELETE, and basic querying techniques.',
        description2: 'You will learn how to retrieve data from databases using SELECT statements, filter results with WHERE clauses, and perform basic data manipulation with INSERT, UPDATE, and DELETE commands. Understanding SQL basics is essential for anyone working with databases, as it allows you to interact with and manage your data effectively. By mastering SQL basics, you can efficiently query databases to extract meaningful insights and perform necessary data operations to support your applications and analyses. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. '
      },
      {
        id: 3,
        title: 'Advanced SQL Queries',
        duration: '4 hours',
        completed: false,
        description: 'Advanced SQL includes complex queries, joins, subqueries, and aggregate functions. This module covers INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL JOIN, GROUP BY, HAVING, and window functions. SQL Aggregate functions include COUNT, SUM, AVG, MIN, and MAX, which allow you to perform calculations on your data. By mastering advanced SQL queries, you can perform complex data analysis and manipulation, which is essential for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. ',
        description2: 'Combine data from multiple tables using various types of joins, including INNER JOIN, LEFT JOIN, RIGHT JOIN, and FULL JOIN. Use GROUP BY and HAVING clauses to aggregate data and filter results based on aggregate conditions. Explore window functions for advanced analytics and reporting. By mastering advanced SQL queries, you can perform complex data analysis and manipulation, which is essential for developers, data analysts, and anyone working with data-driven applications. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. '
      },
      {
        id: 4,
        title: 'Database Design',
        duration: '3 hours',
        completed: false,
        description: 'Database design involves creating efficient and scalable database schemas. This module covers normalization, indexing, constraints, and performance optimization techniques. Performance optimization techniques include query optimization and database tuning. Primary key is a unique identifier for each record in a table, while foreign key establishes a relationship between two tables. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. Foreign key is a field in one table that uniquely identifies a row of another table, creating a relationship between the two tables. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. SQL is used to create, read, update, and delete data in relational databases. Database design principles include normalization, which helps reduce data redundancy and improve data integrity. Data modeling concepts involve creating entity-relationship diagrams to visualize the structure of a database and the relationships between different entities. By mastering SQL and database fundamentals, you can effectively manage and query databases, which is a crucial skill for developers, data analysts, and anyone working with data-driven applications. ',
        description2: 'Normal forms (1NF, 2NF, 3NF) help reduce data redundancy and improve data integrity. Indexing improves query performance by allowing faster data retrieval. Constraints ensure data accuracy and consistency. Performance optimization techniques include query optimization and database tuning. Primary key is a unique identifier for each record in a table, while foreign key establishes a relationship between two tables. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. Foreign key is a field in one table that uniquely identifies a row of another table, creating a relationship between the two tables. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance. By mastering database design principles, you can create efficient and scalable databases that support the needs of your applications and ensure data integrity. Understanding database design is essential for developers, data analysts, and anyone working with data-driven applications, as it allows you to structure your data effectively and optimize performance.'
      },
      {
        id: 5,
        title: 'MySQL Administration',
        duration: '4 hours',
        completed: false,
        description: 'MySQL is a popular open-source relational database management system. This module covers MySQL installation, configuration, user management, backup, and recovery. MySQL installation involves setting up the MySQL server on your system, configuring it for optimal performance, and securing it against unauthorized access. User management includes creating and managing database users, assigning appropriate permissions, and ensuring that only authorized users can access the database. Backup and recovery techniques are essential for protecting your data and ensuring that you can restore it in case of accidental deletion, corruption, or hardware failure. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively.',
        description2: 'MySQL server configuration includes setting up the server, managing users and permissions, and optimizing performance. Backup and recovery techniques ensure data safety and availability in case of failures. Understanding MySQL administration is essential for maintaining the health and performance of your databases. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. MySQL is widely used in web applications and is known for its reliability and ease of use. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively. Security best practices include implementing strong authentication, using encryption, and regularly updating the MySQL server to protect against vulnerabilities. Backup and recovery techniques involve creating regular backups of your databases and having a plan in place for restoring data in case of loss or corruption. By mastering MySQL administration, you can ensure that your databases are secure, performant, and available to support your applications effectively.'
      },
      {
        id: 6,
        title: 'PostgreSQL',
        duration: '4 hours',
        completed: false,
        description: 'PostgreSQL is a powerful open-source object-relational database system. This module covers PostgreSQL features, advanced data types, and extensions. PostgreSQL features include support for advanced data types, full-text search, and extensibility through custom functions and extensions. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. Robust and extensible features include support for advanced data types, full-text search, and the ability to create custom functions and extensions. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications.',
        description2: 'JSON support allows you to store and query JSON data directly in PostgreSQL. Advanced data types include arrays, hstore, and geometric types. Extensions like PostGIS add spatial capabilities for geographic data. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. full-text search allows you to perform complex searches on text data. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful features to build robust and scalable applications. PostgreSQL is known for its robustness and extensibility, making it a popular choice for developers and data analysts. By mastering PostgreSQL, you can leverage its powerful. '
      },
      {
        id: 7,
        title: 'NoSQL Databases',
        duration: '3 hours',
        completed: false,
        description: 'NoSQL databases are designed for large-scale data storage and flexible schemas. This module covers MongoDB, Cassandra, and Redis, including their use cases and query languages. MongoDB is a document-oriented NoSQL database, Cassandra is a wide-column store, and Redis is an in-memory key-value store. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics.',
        description2: 'Document stores is a type of NoSQL database that stores data in JSON-like documents. Key-value stores are simple databases that store data as key-value pairs. Column-family databases organize data into columns and rows, allowing for efficient storage and retrieval. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. key-value stores is a type of NoSQL database that stores data as key-value pairs. Column-family databases organize data into columns and rows, allowing for efficient storage and retrieval. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. And column-family databases organize data into columns and rows, allowing for efficient storage and retrieval. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics. By mastering NoSQL databases, you can handle unstructured data and build scalable applications that require high performance and flexibility. NoSQL databases are ideal for big data applications and real-time analytics.'
      },
      {
        id: 8,
        title: 'Database Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply database concepts to build complete database-driven applications. This module guides you through database design, implementation, and optimization for real-world projects.',
        description2: 'You will work on projects that involve creating databases, writing complex queries, and implementing data access layers. Building database projects demonstrates practical skills in database management.'
      }
    ],
    '15': [
      {
        id: 1,
        title: 'Business Analysis Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Business analysis involves identifying business needs and determining solutions to business problems. This module introduces the role of a business analyst, key concepts, and the business analysis process. Business analysts act as a bridge between stakeholders and technical teams, ensuring that business requirements are properly understood and translated into actionable solutions. Understanding business analysis fundamentals is essential for bridging the gap between business and IT. The role of a business analyst includes eliciting requirements, analyzing data, documenting processes, and facilitating communication between stakeholders. By mastering business analysis fundamentals, you can effectively identify business needs and propose solutions that drive organizational success. Business analysis involves identifying business needs and determining solutions to business problems. This module introduces the role of a business analyst, key concepts, and the business analysis process. Business analysts act as a bridge between stakeholders and technical teams, ensuring that business requirements are properly understood and translated into actionable solutions. Understanding business analysis fundamentals is essential for bridging the gap between business and IT. The role of a business analyst includes eliciting requirements, analyzing data, documenting processes, and facilitating communication between stakeholders. By mastering business analysis fundamentals, you can effectively identify business needs and propose solutions that drive organizational success. Key skills for business analysts include critical thinking, problem-solving, communication, and analytical skills. Business analysis frameworks include BABOK (Business Analysis Body of Knowledge), Agile business analysis, and Lean business analysis. By mastering business analysis fundamentals, you can effectively identify business needs and propose solutions that drive organizational success. Business analysis involves identifying business needs and determining solutions to business problems. This module introduces the role of a business analyst, key concepts, and the business analysis process. Business analysts act as a bridge between stakeholders and technical teams, ensuring that business requirements are properly understood and translated into actionable solutions. Understanding business analysis fundamentals is essential for bridging the gap between business and IT. The role of a business analyst includes eliciting requirements, analyzing data, documenting processes, and facilitating communication between stakeholders.',
        description2: 'Stakeholder analysis involves identifying and understanding the needs, expectations, and influence of project stakeholders. Requirements elicitation techniques include interviews, workshops, surveys, document analysis, and observation. Solution assessment involves evaluating proposed solutions to ensure they meet business needs and deliver value. Understanding business analysis fundamentals is essential for bridging the gap between business and IT. Business analysts must understand organizational context, business processes, and technology capabilities to propose effective solutions. By mastering business analysis fundamentals, you can effectively identify business needs and propose solutions that drive organizational success. Stakeholder analysis involves identifying and understanding the needs, expectations, and influence of project stakeholders. Requirements elicitation techniques include interviews, workshops, surveys, document analysis, and observation. Solution assessment involves evaluating proposed solutions to ensure they meet business needs and deliver value. Understanding business analysis fundamentals is essential for bridging the gap between business and IT. Business analysts must understand organizational context, business processes, and technology capabilities to propose effective solutions. By mastering business analysis fundamentals, you can effectively identify business needs and propose solutions that drive organizational success. Business analysis competencies include strategic thinking, investigative skills, modeling, and influence. By mastering business analysis fundamentals, you can effectively identify business needs and propose solutions that drive organizational success.'
      },
      {
        id: 2,
        title: 'Requirements Gathering',
        duration: '3 hours',
        completed: false,
        description: 'Requirements gathering is the process of collecting and documenting business requirements. This module covers various techniques including interviews, workshops, surveys, and observation. Effective requirements gathering ensures that all stakeholder needs are captured and documented accurately. Understanding requirements gathering techniques is essential for delivering solutions that meet business expectations. Requirements can be functional (what the system should do) or non-functional (how the system should perform). By mastering requirements gathering, you can ensure that solutions align with business objectives and user needs. Requirements gathering is the process of collecting and documenting business requirements. This module covers various techniques including interviews, workshops, surveys, and observation. Effective requirements gathering ensures that all stakeholder needs are captured and documented accurately. Understanding requirements gathering techniques is essential for delivering solutions that meet business expectations. Requirements can be functional (what the system should do) or non-functional (how the system should perform). By mastering requirements gathering, you can ensure that solutions align with business objectives and user needs. Interview techniques include open-ended questions, probing questions, and active listening. Workshop facilitation involves bringing stakeholders together to collaboratively define requirements. Surveys help gather requirements from large groups of stakeholders. Observation involves watching users perform their tasks to understand their needs. By mastering requirements gathering, you can ensure that solutions align with business objectives and user needs. Requirements gathering is the process of collecting and documenting business requirements. This module covers various techniques including interviews, workshops, surveys, and observation. Effective requirements gathering ensures that all stakeholder needs are captured and documented accurately.',
        description2: 'Stakeholder identification involves determining who has an interest in or will be affected by the project. Conducting effective interviews requires preparation, active listening, and follow-up. Workshop techniques include brainstorming, prioritization exercises, and consensus building. Document requirements clearly and comprehensively to avoid misunderstandings. Good requirements gathering ensures that solutions meet business needs and deliver value to stakeholders. Requirements validation ensures that gathered requirements are complete, accurate, and aligned with business goals. By mastering requirements gathering, you can ensure that solutions align with business objectives and user needs. Stakeholder identification involves determining who has an interest in or will be affected by the project. Conducting effective interviews requires preparation, active listening, and follow-up. Workshop techniques include brainstorming, prioritization exercises, and consensus building. Document requirements clearly and comprehensively to avoid misunderstandings. Good requirements gathering ensures that solutions meet business needs and deliver value to stakeholders. Requirements validation ensures that gathered requirements are complete, accurate, and aligned with business goals. By mastering requirements gathering, you can ensure that solutions align with business objectives and user needs. Requirements traceability ensures that each requirement can be traced back to its source and forward to its implementation.'
      },
      {
        id: 3,
        title: 'Requirements Documentation',
        duration: '3 hours',
        completed: false,
        description: 'Requirements documentation involves creating clear and comprehensive requirement specifications. This module covers use cases, user stories, functional requirements, and non-functional requirements. Proper documentation ensures that all stakeholders have a clear understanding of project requirements and can reference them throughout the project lifecycle. Use cases describe how users interact with a system to achieve specific goals. User stories capture requirements from an end-user perspective in a simple, concise format. Functional requirements specify what the system must do, while non-functional requirements specify how the system should perform. By mastering requirements documentation, you can create specifications that guide development and ensure stakeholder alignment. Requirements documentation involves creating clear and comprehensive requirement specifications. This module covers use cases, user stories, functional requirements, and non-functional requirements. Proper documentation ensures that all stakeholders have a clear understanding of project requirements and can reference them throughout the project lifecycle. Use cases describe how users interact with a system to achieve specific goals. User stories capture requirements from an end-user perspective in a simple, concise format. Functional requirements specify what the system must do, while non-functional requirements specify how the system should perform. By mastering requirements documentation, you can create specifications that guide development and ensure stakeholder alignment. Documentation standards include IEEE, IIBA, and organizational templates. Clear documentation reduces ambiguity and supports project success.',
        description2: 'Use case diagrams visualize interactions between users and systems. User story format follows the pattern: "As a [role], I want [feature], so that [benefit]." Functional requirements document specific behaviors and functions the system must provide. Non-functional requirements include performance, security, usability, and reliability criteria. Different documentation formats serve different audiences and purposes - choose the appropriate format for your context. Proper documentation ensures that all stakeholders have a clear understanding of project requirements. Acceptance criteria define the conditions that must be met for requirements to be considered complete. By mastering requirements documentation, you can create specifications that guide development and ensure stakeholder alignment. Use case diagrams visualize interactions between users and systems. User story format follows the pattern: "As a [role], I want [feature], so that [benefit]." Functional requirements document specific behaviors and functions the system must provide. Non-functional requirements include performance, security, usability, and reliability criteria. Different documentation formats serve different audiences and purposes - choose the appropriate format for your context. Proper documentation ensures that all stakeholders have a clear understanding of project requirements. Requirements specifications should be clear, concise, complete, consistent, and verifiable.'
      },
      {
        id: 4,
        title: 'Data Analysis for Business',
        duration: '4 hours',
        completed: false,
        description: 'Data analysis involves examining data to draw conclusions and support decision-making. This module covers data collection, cleaning, analysis techniques, and visualization. Business analysts use data analysis to identify trends, patterns, and insights that inform business decisions. Data collection involves gathering relevant data from various sources. Data cleaning ensures data quality by removing errors and inconsistencies. Analysis techniques include statistical analysis, trend analysis, and comparative analysis. Data visualization presents data in graphical formats that are easy to understand. By mastering data analysis for business, you can provide valuable insights that drive strategic decisions and improve business performance. Data analysis involves examining data to draw conclusions and support decision-making. This module covers data collection, cleaning, analysis techniques, and visualization. Business analysts use data analysis to identify trends, patterns, and insights that inform business decisions. Data collection involves gathering relevant data from various sources. Data cleaning ensures data quality by removing errors and inconsistencies. Analysis techniques include statistical analysis, trend analysis, and comparative analysis. Data visualization presents data in graphical formats that are easy to understand. By mastering data analysis for business, you can provide valuable insights that drive strategic decisions and improve business performance. Statistical methods include descriptive statistics, inferential statistics, and predictive analytics. Data visualization tools include charts, graphs, dashboards, and reports.',
        description2: 'Statistical analysis helps identify patterns and relationships in data. Trend identification reveals changes over time and supports forecasting. Creating meaningful reports involves presenting data in a clear, concise, and actionable format. Data analysis tools include Excel, SQL, Tableau, and Power BI. Data analysis skills help business analysts provide valuable insights to stakeholders and support evidence-based decision-making. Root cause analysis helps identify underlying causes of problems. Gap analysis compares current state to desired state to identify areas for improvement. By mastering data analysis for business, you can provide valuable insights that drive strategic decisions and improve business performance. Statistical analysis helps identify patterns and relationships in data. Trend identification reveals changes over time and supports forecasting. Creating meaningful reports involves presenting data in a clear, concise, and actionable format. Data analysis tools include Excel, SQL, Tableau, and Power BI. Data analysis skills help business analysts provide valuable insights to stakeholders and support evidence-based decision-making. Data-driven decision making improves business outcomes and reduces risk.'
      },
      {
        id: 5,
        title: 'Process Modeling',
        duration: '3 hours',
        completed: false,
        description: 'Process modeling involves creating visual representations of business processes. This module covers BPMN (Business Process Model and Notation) and process improvement techniques. Process models help stakeholders understand how work flows through an organization. BPMN provides a standardized notation for documenting business processes. Process modeling supports process analysis, optimization, and automation. By creating process models, business analysts can identify inefficiencies, bottlenecks, and opportunities for improvement. Process improvement techniques include Lean, Six Sigma, and business process reengineering. By mastering process modeling, you can help organizations optimize their operations and improve efficiency. Process modeling involves creating visual representations of business processes. This module covers BPMN (Business Process Model and Notation) and process improvement techniques. Process models help stakeholders understand how work flows through an organization. BPMN provides a standardized notation for documenting business processes. Process modeling supports process analysis, optimization, and automation. By creating process models, business analysts can identify inefficiencies, bottlenecks, and opportunities for improvement. Process improvement techniques include Lean, Six Sigma, and business process reengineering. By mastering process modeling, you can help organizations optimize their operations and improve efficiency. Process mapping creates visual representations of workflows and helps identify improvement opportunities.',
        description2: 'Mapping current processes provides a baseline for improvement initiatives. Identifying inefficiencies reveals waste, delays, and redundant activities. Designing improved processes involves streamlining workflows, eliminating waste, and enhancing value delivery. Process modeling helps organizations optimize their operations and achieve better business outcomes. Value stream mapping identifies value-adding and non-value-adding activities. Process simulation tests proposed changes before implementation. By mastering process modeling, you can help organizations optimize their operations and improve efficiency. Mapping current processes provides a baseline for improvement initiatives. Identifying inefficiencies reveals waste, delays, and redundant activities. Designing improved processes involves streamlining workflows, eliminating waste, and enhancing value delivery. Process modeling helps organizations optimize their operations and achieve better business outcomes. Process documentation ensures that processes are understood and consistently followed. Continuous improvement involves regularly reviewing and optimizing processes.'
      },
      {
        id: 6,
        title: 'Stakeholder Management',
        duration: '2 hours',
        completed: false,
        description: 'Stakeholder management involves identifying and managing relationships with project stakeholders. This module covers stakeholder analysis, communication planning, and conflict resolution. Effective stakeholder management ensures that stakeholder needs are understood and addressed throughout the project. Stakeholder analysis identifies stakeholders, their interests, influence, and impact on the project. Communication planning ensures that stakeholders receive appropriate information at the right time. Conflict resolution addresses disagreements and ensures that projects progress smoothly. By mastering stakeholder management, you can build positive relationships, manage expectations, and ensure project success. Stakeholder management involves identifying and managing relationships with project stakeholders. This module covers stakeholder analysis, communication planning, and conflict resolution. Effective stakeholder management ensures that stakeholder needs are understood and addressed throughout the project. Stakeholder analysis identifies stakeholders, their interests, influence, and impact on the project. Communication planning ensures that stakeholders receive appropriate information at the right time. Conflict resolution addresses disagreements and ensures that projects progress smoothly. By mastering stakeholder management, you can build positive relationships, manage expectations, and ensure project success. Stakeholder engagement strategies vary based on stakeholder power and interest levels.',
        description2: 'Identifying stakeholder needs ensures that solutions address their concerns and deliver value. Managing expectations involves setting realistic goals and communicating progress regularly. Facilitating effective communication ensures that information flows smoothly between stakeholders. Good stakeholder management is crucial for project success and helps prevent misunderstandings, delays, and conflicts. Stakeholder influence mapping helps prioritize engagement efforts. Relationship building creates trust and collaboration. By mastering stakeholder management, you can build positive relationships, manage expectations, and ensure project success. Identifying stakeholder needs ensures that solutions address their concerns and deliver value. Managing expectations involves setting realistic goals and communicating progress regularly. Facilitating effective communication ensures that information flows smoothly between stakeholders. Good stakeholder management is crucial for project success and helps prevent misunderstandings, delays, and conflicts. Change management helps stakeholders adapt to new processes and systems.'
      },
      {
        id: 7,
        title: 'Agile Business Analysis',
        duration: '3 hours',
        completed: false,
        description: 'Agile business analysis involves applying agile principles to business analysis practices. This module covers agile methodologies, user stories, and iterative requirements development. Agile approaches emphasize collaboration, flexibility, and continuous improvement. In agile environments, business analysts work closely with development teams and stakeholders to refine requirements iteratively. User stories capture requirements in a format that supports agile development. Iterative requirements development allows for flexibility and adaptation as understanding evolves. By mastering agile business analysis, you can support faster delivery, respond to change effectively, and deliver value incrementally. Agile business analysis involves applying agile principles to business analysis practices. This module covers agile methodologies, user stories, and iterative requirements development. Agile approaches emphasize collaboration, flexibility, and continuous improvement. In agile environments, business analysts work closely with development teams and stakeholders to refine requirements iteratively. User stories capture requirements in a format that supports agile development. Iterative requirements development allows for flexibility and adaptation as understanding evolves. By mastering agile business analysis, you can support faster delivery, respond to change effectively, and deliver value incrementally. Scrum and Kanban are popular agile frameworks that business analysts work within.',
        description2: 'Working in agile environments requires adaptability, collaboration, and continuous communication. Refining requirements iteratively allows teams to incorporate feedback and adjust to changing needs. Collaborating with development teams ensures that requirements are understood and implemented correctly. Agile business analysis supports faster delivery and adaptability in dynamic environments. Product backlog management involves prioritizing and refining user stories. Sprint planning ensures that the team commits to deliverable work. By mastering agile business analysis, you can support faster delivery, respond to change effectively, and deliver value incrementally. Working in agile environments requires adaptability, collaboration, and continuous communication. Refining requirements iteratively allows teams to incorporate feedback and adjust to changing needs. Collaborating with development teams ensures that requirements are understood and implemented correctly. Agile business analysis supports faster delivery and adaptability in dynamic environments. Retrospectives help teams continuously improve their processes and practices.'
      },
      {
        id: 8,
        title: 'Business Analysis Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply business analysis concepts to real-world projects. This module guides you through complete business analysis projects from requirements gathering to solution implementation. Practical projects help you develop and demonstrate business analysis skills in realistic scenarios. Projects involve stakeholder interviews, requirements documentation, process modeling, data analysis, and solution recommendations. By building business analysis projects, you gain hands-on experience and create portfolio pieces that showcase your capabilities. Project work reinforces learning and prepares you for professional business analysis roles. Apply business analysis concepts to real-world projects. This module guides you through complete business analysis projects from requirements gathering to solution implementation. Practical projects help you develop and demonstrate business analysis skills in realistic scenarios. Projects involve stakeholder interviews, requirements documentation, process modeling, data analysis, and solution recommendations. By building business analysis projects, you gain hands-on experience and create portfolio pieces that showcase your capabilities. Project work reinforces learning and prepares you for professional business analysis roles. Case studies provide real-world context for applying business analysis techniques.',
        description2: 'Working on projects that involve stakeholder interviews develops your elicitation and communication skills. Requirements documentation projects build your ability to create clear, comprehensive specifications. Solution recommendations projects demonstrate your analytical and problem-solving capabilities. Building business analysis projects demonstrates practical skills in the field and prepares you for professional roles. Portfolio development showcases your business analysis competencies to potential employers. Capstone projects integrate multiple business analysis techniques and deliverables. By building business analysis projects, you gain hands-on experience and create portfolio pieces that showcase your capabilities. Working on projects that involve stakeholder interviews develops your elicitation and communication skills. Requirements documentation projects build your ability to create clear, comprehensive specifications. Solution recommendations projects demonstrate your analytical and problem-solving capabilities. Building business analysis projects demonstrates practical skills in the field and prepares you for professional roles. Real-world application of business analysis principles solidifies your understanding and builds confidence.'
      }
    ],
    '16': [
      {
        id: 1,
        title: 'Node.js Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Node.js is a JavaScript runtime built on Chrome\'s V8 JavaScript engine. This module introduces Node.js basics, installation, and core concepts like event-driven programming and non-blocking I/O. Node.js allows developers to use JavaScript for server-side programming, enabling full-stack JavaScript development. Understanding Node.js fundamentals is essential for building scalable backend applications. Node.js uses an event-driven, non-blocking I/O model that makes it lightweight and efficient for data-intensive real-time applications. By mastering Node.js fundamentals, you can build fast, scalable network applications. Node.js is a JavaScript runtime built on Chrome\'s V8 JavaScript engine. This module introduces Node.js basics, installation, and core concepts like event-driven programming and non-blocking I/O. Node.js allows developers to use JavaScript for server-side programming, enabling full-stack JavaScript development. Understanding Node.js fundamentals is essential for building scalable backend applications. Node.js uses an event-driven, non-blocking I/O model that makes it lightweight and efficient for data-intensive real-time applications. By mastering Node.js fundamentals, you can build fast, scalable network applications. The event loop is the core of Node.js architecture, enabling asynchronous programming. npm (Node Package Manager) is the world\'s largest software registry and package manager for JavaScript. By mastering Node.js fundamentals, you can build fast, scalable network applications. Node.js is a JavaScript runtime built on Chrome\'s V8 JavaScript engine. This module introduces Node.js basics, installation, and core concepts like event-driven programming and non-blocking I/O.',
        description2: 'Node.js architecture consists of the V8 engine, libuv library, and various core modules. npm (Node Package Manager) allows you to install and manage third-party packages and dependencies. Basic file operations in Node.js include reading, writing, and manipulating files using the fs module. Understanding Node.js fundamentals is essential for building scalable backend applications. The module system in Node.js uses CommonJS format, allowing you to organize code into reusable modules. Asynchronous programming patterns include callbacks, promises, and async/await. By mastering Node.js fundamentals, you can build fast, scalable network applications. Node.js architecture consists of the V8 engine, libuv library, and various core modules. npm (Node Package Manager) allows you to install and manage third-party packages and dependencies. Basic file operations in Node.js include reading, writing, and manipulating files using the fs module. Understanding Node.js fundamentals is essential for building scalable backend applications. The global object provides access to global variables and functions. Buffer class handles binary data efficiently. By mastering Node.js fundamentals, you can build fast, scalable network applications. Streams enable efficient handling of large amounts of data.'
      },
      {
        id: 2,
        title: 'Express.js Framework',
        duration: '3 hours',
        completed: false,
        description: 'Express.js is a minimal and flexible Node.js web application framework. This module covers Express basics, routing, middleware, and building RESTful APIs. Express.js provides a robust set of features for web and mobile applications, making backend development faster and more efficient. Understanding Express.js is essential for building modern web applications. Routing in Express allows you to define how your application responds to client requests at specific endpoints. Middleware functions have access to the request and response objects and can execute code, modify these objects, and end the request-response cycle. By mastering Express.js, you can build powerful and scalable web applications quickly. Express.js is a minimal and flexible Node.js web application framework. This module covers Express basics, routing, middleware, and building RESTful APIs. Express.js provides a robust set of features for web and mobile applications, making backend development faster and more efficient. Understanding Express.js is essential for building modern web applications. Routing in Express allows you to define how your application responds to client requests at specific endpoints. Middleware functions have access to the request and response objects and can execute code, modify these objects, and end the request-response cycle. By mastering Express.js, you can build powerful and scalable web applications quickly. Express Router enables modular route handling and organization.',
        description2: 'Setting up Express applications involves installing Express, creating an application instance, and configuring basic settings. Handling HTTP requests includes processing GET, POST, PUT, DELETE, and other HTTP methods. Implementing middleware for authentication ensures that only authorized users can access protected routes. Error handling middleware catches and processes errors that occur during request processing. Express.js simplifies backend development with its robust features and extensive ecosystem. Template engines like EJS and Pug enable dynamic HTML generation. Static file serving allows you to serve images, CSS, and JavaScript files. By mastering Express.js, you can build powerful and scalable web applications quickly. Setting up Express applications involves installing Express, creating an application instance, and configuring basic settings. Handling HTTP requests includes processing GET, POST, PUT, DELETE, and other HTTP methods. Implementing middleware for authentication ensures that only authorized users can access protected routes. Error handling middleware catches and processes errors that occur during request processing. Express.js simplifies backend development with its robust features and extensive ecosystem. Cookie parsing and session management enable stateful web applications.'
      },
      {
        id: 3,
        title: 'RESTful API Development',
        duration: '4 hours',
        completed: false,
        description: 'RESTful APIs follow REST principles for designing networked applications. This module covers HTTP methods, status codes, API design best practices, and testing APIs. REST (Representational State Transfer) is an architectural style that uses standard HTTP methods for communication. Understanding RESTful API development is essential for building modern web services. HTTP methods include GET (retrieve data), POST (create data), PUT (update data), DELETE (remove data), and PATCH (partial update). Status codes indicate the result of HTTP requests, such as 200 (success), 404 (not found), and 500 (server error). By mastering RESTful API development, you can create scalable and maintainable web services. RESTful APIs follow REST principles for designing networked applications. This module covers HTTP methods, status codes, API design best practices, and testing APIs. REST (Representational State Transfer) is an architectural style that uses standard HTTP methods for communication. Understanding RESTful API development is essential for building modern web services. HTTP methods include GET (retrieve data), POST (create data), PUT (update data), DELETE (remove data), and PATCH (partial update). Status codes indicate the result of HTTP requests, such as 200 (success), 404 (not found), and 500 (server error). By mastering RESTful API development, you can create scalable and maintainable web services. API versioning ensures backward compatibility when making changes.',
        description2: 'Designing RESTful APIs involves creating intuitive endpoints, using proper HTTP methods, and following naming conventions. Implementing different content types includes handling JSON, XML, and other data formats. Ensuring API security involves implementing authentication, authorization, input validation, and rate limiting. RESTful APIs enable communication between frontend and backend systems, supporting web and mobile applications. API documentation using tools like Swagger/OpenAPI helps developers understand and consume your APIs. HATEOAS (Hypermedia as the Engine of Application State) enables discoverable APIs. By mastering RESTful API development, you can create scalable and maintainable web services. Designing RESTful APIs involves creating intuitive endpoints, using proper HTTP methods, and following naming conventions. Implementing different content types includes handling JSON, XML, and other data formats. Ensuring API security involves implementing authentication, authorization, input validation, and rate limiting. RESTful APIs enable communication between frontend and backend systems, supporting web and mobile applications. Pagination and filtering improve API performance for large datasets.'
      },
      {
        id: 4,
        title: 'Database Integration',
        duration: '4 hours',
        completed: false,
        description: 'Database integration involves connecting Node.js applications to databases. This module covers working with MongoDB, PostgreSQL, and implementing data access layers. Databases store and manage application data persistently. Understanding database integration is essential for building data-driven applications. MongoDB is a NoSQL document database that stores data in flexible, JSON-like documents. PostgreSQL is a powerful relational database that uses SQL for data management. Data access layers abstract database operations and provide a clean interface for application code. By mastering database integration, you can build robust applications that efficiently manage and query data. Database integration involves connecting Node.js applications to databases. This module covers working with MongoDB, PostgreSQL, and implementing data access layers. Databases store and manage application data persistently. Understanding database integration is essential for building data-driven applications. MongoDB is a NoSQL document database that stores data in flexible, JSON-like documents. PostgreSQL is a powerful relational database that uses SQL for data management. Data access layers abstract database operations and provide a clean interface for application code. By mastering database integration, you can build robust applications that efficiently manage and query data. ORM (Object-Relational Mapping) libraries like Sequelize simplify database interactions.',
        description2: 'Database drivers provide the interface between Node.js and database systems. Connection pooling manages multiple database connections efficiently, improving performance. Performing CRUD operations includes creating, reading, updating, and deleting data in databases. Proper database integration ensures efficient data management in applications. Database migrations manage schema changes over time. Query optimization improves database performance. By mastering database integration, you can build robust applications that efficiently manage and query data. Database drivers provide the interface between Node.js and database systems. Connection pooling manages multiple database connections efficiently, improving performance. Performing CRUD operations includes creating, reading, updating, and deleting data in databases. Proper database integration ensures efficient data management in applications. Transaction management ensures data consistency and integrity. Database indexing speeds up query performance.'
      },
      {
        id: 5,
        title: 'Authentication & Authorization',
        duration: '3 hours',
        completed: false,
        description: 'Authentication verifies user identity, while authorization determines user permissions. This module covers JWT (JSON Web Tokens), Passport.js, and implementing secure authentication flows. Authentication is crucial for protecting user accounts and ensuring that only authorized users can access protected resources. JWT provides a compact and self-contained way to securely transmit information between parties. Passport.js is a popular authentication middleware for Node.js that supports various authentication strategies. By mastering authentication and authorization, you can build secure applications that protect user data and resources. Authentication verifies user identity, while authorization determines user permissions. This module covers JWT (JSON Web Tokens), Passport.js, and implementing secure authentication flows. Authentication is crucial for protecting user accounts and ensuring that only authorized users can access protected resources. JWT provides a compact and self-contained way to securely transmit information between parties. Passport.js is a popular authentication middleware for Node.js that supports various authentication strategies. By mastering authentication and authorization, you can build secure applications that protect user data and resources. OAuth 2.0 enables secure third-party authentication.',
        description2: 'Different authentication strategies include local authentication (username/password), OAuth, JWT, and session-based authentication. Session management involves creating, maintaining, and destroying user sessions. Protecting API endpoints ensures that only authenticated and authorized users can access sensitive data and operations. Secure authentication is crucial for protecting user data and application resources. Password hashing using bcrypt protects user passwords. Role-based access control (RBAC) manages user permissions. By mastering authentication and authorization, you can build secure applications that protect user data and resources. Different authentication strategies include local authentication (username/password), OAuth, JWT, and session-based authentication. Session management involves creating, maintaining, and destroying user sessions. Protecting API endpoints ensures that only authenticated and authorized users can access sensitive data and operations. Secure authentication is crucial for protecting user data and application resources. Two-factor authentication adds an extra layer of security.'
      },
      {
        id: 6,
        title: 'Middleware & Security',
        duration: '3 hours',
        completed: false,
        description: 'Middleware functions have access to request and response objects. This module covers custom middleware, security best practices, CORS, and input validation. Middleware is a core concept in Express.js that enables modular and reusable code. Security best practices protect applications from common vulnerabilities like SQL injection, XSS, and CSRF attacks. CORS (Cross-Origin Resource Sharing) allows or restricts resources on a web server based on the origin of the request. Input validation ensures that user input is safe and meets expected formats. By mastering middleware and security, you can build robust and secure web applications. Middleware functions have access to request and response objects. This module covers custom middleware, security best practices, CORS, and input validation. Middleware is a core concept in Express.js that enables modular and reusable code. Security best practices protect applications from common vulnerabilities like SQL injection, XSS, and CSRF attacks. CORS (Cross-Origin Resource Sharing) allows or restricts resources on a web server based on the origin of the request. Input validation ensures that user input is safe and meets expected formats. By mastering middleware and security, you can build robust and secure web applications. Helmet.js adds security headers to protect against common attacks.',
        description2: 'Implementing logging middleware helps track application behavior and diagnose issues. Rate limiting prevents abuse by limiting the number of requests from a single source. Data sanitization removes or escapes potentially dangerous characters from user input. Proper middleware and security measures protect applications from common vulnerabilities and ensure reliable operation. HTTPS encryption protects data in transit. Environment variables secure sensitive configuration data. By mastering middleware and security, you can build robust and secure web applications. Implementing logging middleware helps track application behavior and diagnose issues. Rate limiting prevents abuse by limiting the number of requests from a single source. Data sanitization removes or escapes potentially dangerous characters from user input. Proper middleware and security measures protect applications from common vulnerabilities and ensure reliable operation. Content Security Policy (CSP) prevents XSS attacks.'
      },
      {
        id: 7,
        title: 'Testing & Debugging',
        duration: '3 hours',
        completed: false,
        description: 'Testing ensures code quality and prevents bugs. This module covers unit testing with Jest, integration testing, and debugging techniques for Node.js applications. Testing is an essential part of software development that helps identify and fix bugs early. Unit testing tests individual functions or components in isolation. Integration testing tests how different parts of the application work together. Debugging techniques help identify and fix issues in code. By mastering testing and debugging, you can build reliable and maintainable applications. Testing ensures code quality and prevents bugs. This module covers unit testing with Jest, integration testing, and debugging techniques for Node.js applications. Testing is an essential part of software development that helps identify and fix bugs early. Unit testing tests individual functions or components in isolation. Integration testing tests how different parts of the application work together. Debugging techniques help identify and fix issues in code. By mastering testing and debugging, you can build reliable and maintainable applications. Test-driven development (TDD) writes tests before implementation code.',
        description2: 'Test-driven development involves writing tests before implementing functionality, ensuring that code meets requirements. Mocking allows you to simulate dependencies and test components in isolation. Using debugging tools like Node.js debugger, Chrome DevTools, and logging helps identify and resolve issues efficiently. Effective testing and debugging improve application reliability and maintainability. Code coverage measures how much of your code is tested. Continuous integration runs tests automatically on code changes. By mastering testing and debugging, you can build reliable and maintainable applications. Test-driven development involves writing tests before implementing functionality, ensuring that code meets requirements. Mocking allows you to simulate dependencies and test components in isolation. Using debugging tools like Node.js debugger, Chrome DevTools, and logging helps identify and resolve issues efficiently. Effective testing and debugging improve application reliability and maintainability. End-to-end testing validates complete application workflows.'
      },
      {
        id: 8,
        title: 'Deployment & Production',
        duration: '3 hours',
        completed: false,
        description: 'Deployment involves making applications available in production environments. This module covers deployment strategies, environment configuration, and monitoring production applications. Deploying to production requires careful planning to ensure applications run reliably and securely. Deployment strategies include blue-green deployment, canary deployment, and rolling deployment. Environment configuration manages different settings for development, staging, and production environments. Monitoring helps track application performance and identify issues. By mastering deployment and production practices, you can ensure applications run smoothly and reliably in production. Deployment involves making applications available in production environments. This module covers deployment strategies, environment configuration, and monitoring production applications. Deploying to production requires careful planning to ensure applications run reliably and securely. Deployment strategies include blue-green deployment, canary deployment, and rolling deployment. Environment configuration manages different settings for development, staging, and production environments. Monitoring helps track application performance and identify issues. By mastering deployment and production practices, you can ensure applications run smoothly and reliably in production. Containerization with Docker ensures consistent environments.',
        description2: 'Containerization with Docker packages applications with all dependencies, ensuring consistent behavior across environments. Cloud deployment platforms like AWS, Azure, and Heroku provide scalable infrastructure for hosting applications. Performance optimization includes caching, load balancing, and database optimization. Proper deployment practices ensure applications run smoothly in production. Process managers like PM2 keep applications running and enable zero-downtime restarts. Logging and monitoring tools track application health and performance. By mastering deployment and production practices, you can ensure applications run smoothly and reliably in production. Containerization with Docker packages applications with all dependencies, ensuring consistent behavior across environments. Cloud deployment platforms like AWS, Azure, and Heroku provide scalable infrastructure for hosting applications. Performance optimization includes caching, load balancing, and database optimization. Proper deployment practices ensure applications run smoothly in production. SSL/TLS certificates secure production applications.'
      }
    ],
    '17': [
      {
        id: 1,
        title: 'Flutter Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Flutter is Google\'s UI toolkit for building natively compiled applications. This module introduces Flutter basics, Dart language, and the widget-based architecture. Flutter enables developers to build beautiful, natively compiled applications for mobile, web, and desktop from a single codebase. Understanding Flutter fundamentals is essential for building cross-platform mobile applications. Flutter uses a widget-based architecture where everything is a widget. Widgets describe how the UI should look given their current configuration and state. Hot reload allows developers to see changes instantly without losing application state. By mastering Flutter fundamentals, you can build high-performance cross-platform applications efficiently. Flutter is Google\'s UI toolkit for building natively compiled applications. This module introduces Flutter basics, Dart language, and the widget-based architecture. Flutter enables developers to build beautiful, natively compiled applications for mobile, web, and desktop from a single codebase. Understanding Flutter fundamentals is essential for building cross-platform mobile applications. Flutter uses a widget-based architecture where everything is a widget. Widgets describe how the UI should look given their current configuration and state. Hot reload allows developers to see changes instantly without losing application state. By mastering Flutter fundamentals, you can build high-performance cross-platform applications efficiently. Material Design and Cupertino widgets provide platform-specific UI components.',
        description2: 'Flutter\'s architecture consists of the Framework (written in Dart), the Engine (written in C++), and the Embedder (platform-specific). Hot reload enables fast development by allowing you to see changes immediately without restarting the application. Basic widget concepts include understanding the widget tree, widget composition, and the difference between stateless and stateful widgets. Understanding Flutter fundamentals is essential for building cross-platform mobile applications. The build method describes how widgets should render based on their current configuration. Widget lifecycle methods control widget creation, updates, and disposal. By mastering Flutter fundamentals, you can build high-performance cross-platform applications efficiently. Flutter\'s architecture consists of the Framework (written in Dart), the Engine (written in C++), and the Embedder (platform-specific). Hot reload enables fast development by allowing you to see changes immediately without restarting the application. Basic widget concepts include understanding the widget tree, widget composition, and the difference between stateless and stateful widgets. Understanding Flutter fundamentals is essential for building cross-platform mobile applications. Scaffold widget provides basic app structure.'
      },
      {
        id: 2,
        title: 'Dart Programming',
        duration: '3 hours',
        completed: false,
        description: 'Dart is the programming language used for Flutter development. This module covers Dart syntax, object-oriented programming, and asynchronous programming with futures and streams. Dart is a client-optimized language for developing fast apps on any platform. Understanding Dart is crucial for effective Flutter development. Dart syntax is similar to other C-style languages, making it easy to learn if you know JavaScript, Java, or C#. Object-oriented programming in Dart includes classes, inheritance, interfaces, and mixins. Asynchronous programming with futures and streams enables handling operations that take time, like network requests. By mastering Dart, you can write efficient and maintainable Flutter applications. Dart is the programming language used for Flutter development. This module covers Dart syntax, object-oriented programming, and asynchronous programming with futures and streams. Dart is a client-optimized language for developing fast apps on any platform. Understanding Dart is crucial for effective Flutter development. Dart syntax is similar to other C-style languages, making it easy to learn if you know JavaScript, Java, or C#. Object-oriented programming in Dart includes classes, inheritance, interfaces, and mixins. Asynchronous programming with futures and streams enables handling operations that take time, like network requests. By mastering Dart, you can write efficient and maintainable Flutter applications. Null safety prevents null reference errors.',
        description2: 'Dart\'s type system includes static typing with type inference, generics, and nullable and non-nullable types. Collections in Dart include List, Set, and Map with powerful methods for data manipulation. Error handling uses try-catch blocks and custom exceptions. Mastering Dart is crucial for effective Flutter development. Async/await syntax simplifies asynchronous code. Extension methods add functionality to existing classes. By mastering Dart, you can write efficient and maintainable Flutter applications. Dart\'s type system includes static typing with type inference, generics, and nullable and non-nullable types. Collections in Dart include List, Set, and Map with powerful methods for data manipulation. Error handling uses try-catch blocks and custom exceptions. Mastering Dart is crucial for effective Flutter development. Isolates enable concurrent programming. Cascade notation simplifies object initialization.'
      },
      {
        id: 3,
        title: 'Flutter Widgets',
        duration: '4 hours',
        completed: false,
        description: 'Widgets are the building blocks of Flutter UIs. This module covers basic widgets, layout widgets, and creating custom widgets. Everything in Flutter is a widget, from structural elements like buttons and text to layout elements like rows and columns. Understanding widgets enables you to create complex and responsive user interfaces. Basic widgets include Text, Image, Icon, Button, and Container. Layout widgets include Row, Column, Stack, and GridView for arranging other widgets. Custom widgets allow you to create reusable UI components tailored to your needs. By mastering Flutter widgets, you can build beautiful and functional user interfaces. Widgets are the building blocks of Flutter UIs. This module covers basic widgets, layout widgets, and creating custom widgets. Everything in Flutter is a widget, from structural elements like buttons and text to layout elements like rows and columns. Understanding widgets enables you to create complex and responsive user interfaces. Basic widgets include Text, Image, Icon, Button, and Container. Layout widgets include Row, Column, Stack, and GridView for arranging other widgets. Custom widgets allow you to create reusable UI components tailored to your needs. By mastering Flutter widgets, you can build beautiful and functional user interfaces. Widget composition enables building complex UIs from simple widgets.',
        description2: 'Stateless widgets are immutable and rebuild when their configuration changes. Stateful widgets maintain mutable state that can change over time. Widget composition involves combining simple widgets to create complex UI components. Understanding widgets enables you to create complex and responsive user interfaces. The widget tree represents the hierarchy of widgets in your application. BuildContext provides access to widget location in the tree. By mastering Flutter widgets, you can build beautiful and functional user interfaces. Stateless widgets are immutable and rebuild when their configuration changes. Stateful widgets maintain mutable state that can change over time. Widget composition involves combining simple widgets to create complex UI components. Understanding widgets enables you to create complex and responsive user interfaces. Inherited widgets share data down the widget tree. Keys help Flutter identify which widgets have changed.'
      },
      {
        id: 4,
        title: 'State Management',
        duration: '4 hours',
        completed: false,
        description: 'State management handles data that can change over time. This module covers Provider, Bloc, and Riverpod for managing application state. State management is crucial for building complex applications with dynamic data. Provider is a simple and flexible state management solution recommended by the Flutter team. Bloc (Business Logic Component) separates business logic from UI using streams. Riverpod is an improved version of Provider with better safety and testability. By mastering state management, you can build scalable and maintainable Flutter applications with predictable behavior. State management handles data that can change over time. This module covers Provider, Bloc, and Riverpod for managing application state. State management is crucial for building complex applications with dynamic data. Provider is a simple and flexible state management solution recommended by the Flutter team. Bloc (Business Logic Component) separates business logic from UI using streams. Riverpod is an improved version of Provider with better safety and testability. By mastering state management, you can build scalable and maintainable Flutter applications with predictable behavior. setState triggers widget rebuilds for local state.',
        description2: 'Different state management approaches serve different needs - choose based on application complexity and team preferences. When to use each approach depends on factors like application size, team experience, and specific requirements. Effective state management ensures predictable and maintainable application behavior. Scoped model provides state to specific parts of the widget tree. Redux implements unidirectional data flow. By mastering state management, you can build scalable and maintainable Flutter applications with predictable behavior. Different state management approaches serve different needs - choose based on application complexity and team preferences. When to use each approach depends on factors like application size, team experience, and specific requirements. Effective state management ensures predictable and maintainable application behavior. GetX provides state management with minimal boilerplate. MobX uses reactive programming principles.'
      },
      {
        id: 5,
        title: 'Navigation & Routing',
        duration: '3 hours',
        completed: false,
        description: 'Navigation manages movement between screens in Flutter apps. This module covers Navigator, named routes, and passing data between screens. Navigation is essential for creating multi-screen applications with smooth user flow. Navigator manages a stack of routes (screens) and provides methods to push and pop routes. Named routes define routes with string identifiers for easier navigation. Passing data between screens enables communication and data flow in your application. By mastering navigation and routing, you can create intuitive and well-structured applications. Navigation manages movement between screens in Flutter apps. This module covers Navigator, named routes, and passing data between screens. Navigation is essential for creating multi-screen applications with smooth user flow. Navigator manages a stack of routes (screens) and provides methods to push and pop routes. Named routes define routes with string identifiers for easier navigation. Passing data between screens enables communication and data flow in your application. By mastering navigation and routing, you can create intuitive and well-structured applications. Navigator 2.0 provides declarative routing.',
        description2: 'Different navigation patterns include push/pop navigation, tab navigation, drawer navigation, and bottom navigation. Implementing deep linking allows users to navigate to specific screens from URLs or notifications. Proper navigation enhances user experience and application flow. Route guards control access to specific screens. Nested navigation manages complex navigation hierarchies. By mastering navigation and routing, you can create intuitive and well-structured applications. Different navigation patterns include push/pop navigation, tab navigation, drawer navigation, and bottom navigation. Implementing deep linking allows users to navigate to specific screens from URLs or notifications. Proper navigation enhances user experience and application flow. Hero animations create smooth transitions between screens.'
      },
      {
        id: 6,
        title: 'Networking & APIs',
        duration: '3 hours',
        completed: false,
        description: 'Networking involves communicating with web services. This module covers HTTP requests, JSON parsing, and integrating with RESTful APIs. Most mobile applications need to communicate with backend servers to fetch and send data. The http package provides functions for making HTTP requests in Flutter. JSON parsing converts JSON data to Dart objects for easier manipulation. Error handling ensures graceful handling of network failures and invalid data. By mastering networking and APIs, you can build data-driven applications that interact with backend services. Networking involves communicating with web services. This module covers HTTP requests, JSON parsing, and integrating with RESTful APIs. Most mobile applications need to communicate with backend servers to fetch and send data. The http package provides functions for making HTTP requests in Flutter. JSON parsing converts JSON data to Dart objects for easier manipulation. Error handling ensures graceful handling of network failures and invalid data. By mastering networking and APIs, you can build data-driven applications that interact with backend services. Dio package provides advanced HTTP features.',
        description2: 'The http package provides simple methods for GET, POST, PUT, and DELETE requests. Error handling includes handling network errors, server errors, and data parsing errors. Implementing offline capabilities with caching ensures applications work without internet connectivity. Networking skills enable apps to interact with backend services and provide dynamic content. Interceptors modify requests and responses. Authentication headers secure API requests. By mastering networking and APIs, you can build data-driven applications that interact with backend services. The http package provides simple methods for GET, POST, PUT, and DELETE requests. Error handling includes handling network errors, server errors, and data parsing errors. Implementing offline capabilities with caching ensures applications work without internet connectivity. Networking skills enable apps to interact with backend services and provide dynamic content. Retry logic handles temporary network failures.'
      },
      {
        id: 7,
        title: 'Persistence & Storage',
        duration: '3 hours',
        completed: false,
        description: 'Persistence involves storing data locally on devices. This module covers SQLite, shared preferences, and file system operations. Local storage enables offline functionality and improves app performance by reducing network requests. SQLite is a lightweight database for storing structured data. Shared preferences store simple key-value pairs for app settings. File system operations enable reading and writing files. By mastering persistence and storage, you can build applications that work offline and provide fast user experiences. Persistence involves storing data locally on devices. This module covers SQLite, shared preferences, and file system operations. Local storage enables offline functionality and improves app performance by reducing network requests. SQLite is a lightweight database for storing structured data. Shared preferences store simple key-value pairs for app settings. File system operations enable reading and writing files. By mastering persistence and storage, you can build applications that work offline and provide fast user experiences. Hive provides fast NoSQL database.',
        description2: 'Different storage options serve different needs - use shared preferences for settings, SQLite for structured data, and file system for files. Implementing data caching reduces network requests and improves performance. Local persistence enables offline functionality and better user experience. Secure storage protects sensitive data. Database migrations manage schema changes. By mastering persistence and storage, you can build applications that work offline and provide fast user experiences. Different storage options serve different needs - use shared preferences for settings, SQLite for structured data, and file system for files. Implementing data caching reduces network requests and improves performance. Local persistence enables offline functionality and better user experience. Path provider locates standard file system locations.'
      },
      {
        id: 8,
        title: 'Flutter Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply Flutter concepts to build complete mobile applications. This module guides you through developing end-to-end projects with state management, networking, and deployment. Building real-world projects helps you apply what you\'ve learned and develop practical skills. Projects demonstrate UI design, API integration, state management, and deployment to app stores. By building Flutter projects, you create portfolio pieces that showcase your ability to create production-ready applications. Flutter Projects apply all concepts learned throughout the course in comprehensive applications. Apply Flutter concepts to build complete mobile applications. This module guides you through developing end-to-end projects with state management, networking, and deployment. Building real-world projects helps you apply what you\'ve learned and develop practical skills. Projects demonstrate UI design, API integration, state management, and deployment to app stores. By building Flutter projects, you create portfolio pieces that showcase your ability to create production-ready applications. Flutter Projects apply all concepts learned throughout the course in comprehensive applications. Testing ensures application quality.',
        description2: 'Working on projects that demonstrate practical Flutter skills including UI design, API integration, state management, and app store deployment. Building Flutter projects showcases your ability to create production-ready applications and provides portfolio pieces for job applications. Real-world project experience prepares you for professional Flutter development roles. Performance optimization improves user experience. Accessibility features make apps usable by everyone. By building Flutter projects, you create portfolio pieces that showcase your ability to create production-ready applications. Working on projects that demonstrate practical Flutter skills including UI design, API integration, state management, and app store deployment. Building Flutter projects showcases your ability to create production-ready applications and provides portfolio pieces for job applications. Real-world project experience prepares you for professional Flutter development roles. Code organization maintains project maintainability.'
      }
    ],
    '18': [
      {
        id: 1,
        title: 'AI Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Artificial Intelligence (AI) involves creating systems that can perform tasks that typically require human intelligence. This module introduces AI concepts, history, and current applications. AI has evolved from simple rule-based systems to complex neural networks and deep learning models. Understanding AI fundamentals provides a foundation for exploring advanced AI topics. Different types of AI include narrow AI (designed for specific tasks) and general AI (theoretical human-level intelligence). Machine learning is a subset of AI that enables systems to learn from data. Deep learning is a subset of machine learning using neural networks with multiple layers. By mastering AI fundamentals, you gain a comprehensive understanding of how AI works and its applications. Artificial Intelligence (AI) involves creating systems that can perform tasks that typically require human intelligence. This module introduces AI concepts, history, and current applications. AI has evolved from simple rule-based systems to complex neural networks and deep learning models. Understanding AI fundamentals provides a foundation for exploring advanced AI topics. Different types of AI include narrow AI (designed for specific tasks) and general AI (theoretical human-level intelligence). Machine learning is a subset of AI that enables systems to learn from data. Deep learning is a subset of machine learning using neural networks with multiple layers. By mastering AI fundamentals, you gain a comprehensive understanding of how AI works and its applications. Ethical considerations include bias, privacy, and transparency.',
        description2: 'AI history spans from early symbolic AI to modern deep learning approaches. Current applications include image recognition, natural language processing, autonomous vehicles, and recommendation systems. Ethical considerations in AI include bias, privacy, fairness, and transparency. Understanding AI fundamentals provides a foundation for exploring advanced AI topics and making informed decisions about AI implementation. AI technologies transform industries from healthcare to finance to transportation. Responsible AI development considers societal impacts. By mastering AI fundamentals, you gain a comprehensive understanding of how AI works and its applications. AI history spans from early symbolic AI to modern deep learning approaches. Current applications include image recognition, natural language processing, autonomous vehicles, and recommendation systems. Ethical considerations in AI include bias, privacy, fairness, and transparency. Understanding AI fundamentals provides a foundation for exploring advanced AI topics and making informed decisions about AI implementation. Expert systems use rule-based reasoning.'
      },
      {
        id: 2,
        title: 'Machine Learning Basics',
        duration: '3 hours',
        completed: false,
        description: 'Machine learning is a subset of AI that enables systems to learn from data. This module covers supervised, unsupervised, and reinforcement learning algorithms. Machine learning algorithms learn patterns from data without being explicitly programmed. Understanding machine learning basics is essential for building intelligent applications. Supervised learning uses labeled data to train models that can make predictions. Unsupervised learning finds patterns in unlabeled data. Reinforcement learning trains agents to make decisions through trial and error. By mastering machine learning basics, you can build predictive models and intelligent systems. Machine learning is a subset of AI that enables systems to learn from data. This module covers supervised, unsupervised, and reinforcement learning algorithms. Machine learning algorithms learn patterns from data without being explicitly programmed. Understanding machine learning basics is essential for building intelligent applications. Supervised learning uses labeled data to train models that can make predictions. Unsupervised learning finds patterns in unlabeled data. Reinforcement learning trains agents to make decisions through trial and error. By mastering machine learning basics, you can build predictive models and intelligent systems. Feature engineering transforms raw data into useful features.',
        description2: 'Linear regression predicts continuous values based on input features. Decision trees make predictions by learning decision rules from data. Clustering algorithms group similar data points together without labels. Q-learning is a reinforcement learning algorithm that learns optimal actions through rewards. Mastering machine learning basics is essential for building intelligent applications that can learn and adapt. Model evaluation metrics assess prediction accuracy. Cross-validation prevents overfitting. By mastering machine learning basics, you can build predictive models and intelligent systems. Linear regression predicts continuous values based on input features. Decision trees make predictions by learning decision rules from data. Clustering algorithms group similar data points together without labels. Q-learning is a reinforcement learning algorithm that learns optimal actions through rewards. Mastering machine learning basics is essential for building intelligent applications that can learn and adapt. Regularization prevents model overfitting.'
      },
      {
        id: 3,
        title: 'Deep Learning & Neural Networks',
        duration: '4 hours',
        completed: false,
        description: 'Deep learning is a subset of machine learning that uses neural networks with multiple layers. This module covers feedforward neural networks, convolutional neural networks (CNNs), and recurrent neural networks (RNNs). Deep learning has revolutionized AI by enabling breakthroughs in image recognition, natural language processing, and game playing. Understanding deep learning techniques is essential for tackling complex AI problems. Feedforward neural networks process information in one direction from input to output. CNNs are specialized for processing grid-like data such as images. RNNs are designed for sequential data such as text and time series. By mastering deep learning, you can build powerful AI models for various applications. Deep learning is a subset of machine learning that uses neural networks with multiple layers. This module covers feedforward neural networks, convolutional neural networks (CNNs), and recurrent neural networks (RNNs). Deep learning has revolutionized AI by enabling breakthroughs in image recognition, natural language processing, and game playing. Understanding deep learning techniques is essential for tackling complex AI problems. Feedforward neural networks process information in one direction from input to output. CNNs are specialized for processing grid-like data such as images. RNNs are designed for sequential data such as text and time series. By mastering deep learning, you can build powerful AI models for various applications. Transfer learning leverages pre-trained models.',
        description2: 'Backpropagation is the algorithm used to train neural networks by adjusting weights based on errors. Activation functions introduce non-linearity into neural networks, enabling them to learn complex patterns. Training deep learning models involves feeding data through the network, calculating loss, and updating weights. Deep learning techniques are powerful for tasks like image recognition, natural language processing, and speech recognition. GPU acceleration speeds up training. Batch normalization improves training stability. By mastering deep learning, you can build powerful AI models for various applications. Backpropagation is the algorithm used to train neural networks by adjusting weights based on errors. Activation functions introduce non-linearity into neural networks, enabling them to learn complex patterns. Training deep learning models involves feeding data through the network, calculating loss, and updating weights. Deep learning techniques are powerful for tasks like image recognition, natural language processing, and speech recognition. Dropout prevents overfitting in neural networks.'
      },
      {
        id: 4,
        title: 'AI Development Tools',
        duration: '3 hours',
        completed: false,
        description: 'AI development involves using tools and frameworks to build AI applications. This module covers TensorFlow, PyTorch, and scikit-learn for machine learning development. These frameworks provide high-level APIs and optimized implementations of AI algorithms. Understanding AI development tools is crucial for implementing AI solutions effectively. TensorFlow is an open-source platform for machine learning developed by Google. PyTorch is a flexible deep learning framework popular in research. Scikit-learn provides simple and efficient tools for data mining and analysis. By mastering AI development tools, you can build, train, and deploy AI models efficiently. AI development involves using tools and frameworks to build AI applications. This module covers TensorFlow, PyTorch, and scikit-learn for machine learning development. These frameworks provide high-level APIs and optimized implementations of AI algorithms. Understanding AI development tools is crucial for implementing AI solutions effectively. TensorFlow is an open-source platform for machine learning developed by Google. PyTorch is a flexible deep learning framework popular in research. Scikit-learn provides simple and efficient tools for data mining and analysis. By mastering AI development tools, you can build, train, and deploy AI models efficiently. Keras provides high-level neural network API.',
        description2: 'Setting up AI development environments involves installing Python, frameworks, and necessary dependencies. Building and training models includes data preprocessing, model architecture design, and training loops. Evaluating model performance uses metrics like accuracy, precision, recall, and F1 score. Familiarity with AI tools is crucial for implementing AI solutions effectively and efficiently. Model deployment makes AI models available for production use. MLOps practices manage ML lifecycle. By mastering AI development tools, you can build, train, and deploy AI models efficiently. Setting up AI development environments involves installing Python, frameworks, and necessary dependencies. Building and training models includes data preprocessing, model architecture design, and training loops. Evaluating model performance uses metrics like accuracy, precision, recall, and F1 score. Familiarity with AI tools is crucial for implementing AI solutions effectively and efficiently. Hyperparameter tuning optimizes model performance.'
      },
      {
        id: 5,
        title: 'AI Applications',
        duration: '4 hours',
        completed: false,
        description: 'AI has applications across various industries. This module explores AI use cases in healthcare, finance, retail, and more. AI applications are transforming how businesses operate and how people live. Understanding AI applications helps you identify opportunities for innovation in different sectors. Healthcare applications include disease diagnosis, drug discovery, and personalized medicine. Finance applications include fraud detection, algorithmic trading, and credit scoring. Retail applications include recommendation systems, inventory management, and customer service chatbots. By understanding AI applications, you can leverage AI to solve real-world problems and create value. AI has applications across various industries. This module explores AI use cases in healthcare, finance, retail, and more. AI applications are transforming how businesses operate and how people live. Understanding AI applications helps you identify opportunities for innovation in different sectors. Healthcare applications include disease diagnosis, drug discovery, and personalized medicine. Finance applications include fraud detection, algorithmic trading, and credit scoring. Retail applications include recommendation systems, inventory management, and customer service chatbots. By understanding AI applications, you can leverage AI to solve real-world problems and create value. Computer vision enables image and video analysis.',
        description2: 'Predictive analytics uses historical data to forecast future outcomes. Recommendation systems suggest products or content based on user preferences and behavior. Autonomous vehicles use AI for perception, decision-making, and control. Understanding AI applications helps you identify opportunities for innovation in different sectors and apply AI to solve industry-specific challenges. Natural language processing enables human-computer interaction. Sentiment analysis understands customer opinions. By understanding AI applications, you can leverage AI to solve real-world problems and create value. Predictive analytics uses historical data to forecast future outcomes. Recommendation systems suggest products or content based on user preferences and behavior. Autonomous vehicles use AI for perception, decision-making, and control. Understanding AI applications helps you identify opportunities for innovation in different sectors and apply AI to solve industry-specific challenges. Chatbots automate customer service.'
      },
      {
        id: 6,
        title: 'AI Ethics & Future Trends',
        duration: '3 hours',
        completed: false,
        description: 'AI ethics involves addressing moral implications of AI technology. This module covers bias, privacy, and the future of AI development. As AI becomes more prevalent, ethical considerations become increasingly important. Understanding AI ethics is essential for responsible AI development. Bias in AI can lead to unfair or discriminatory outcomes. Privacy concerns arise from AI systems collecting and analyzing personal data. Future trends include explainable AI, general AI, and AI regulation. By understanding AI ethics and future trends, you can develop AI responsibly and stay informed about the evolving AI landscape. AI ethics involves addressing moral implications of AI technology. This module covers bias, privacy, and the future of AI development. As AI becomes more prevalent, ethical considerations become increasingly important. Understanding AI ethics is essential for responsible AI development. Bias in AI can lead to unfair or discriminatory outcomes. Privacy concerns arise from AI systems collecting and analyzing personal data. Future trends include explainable AI, general AI, and AI regulation. By understanding AI ethics and future trends, you can develop AI responsibly and stay informed about the evolving AI landscape. Fairness ensures AI treats all groups equitably.',
        description2: 'Ethical considerations in AI development include addressing bias in training data and algorithms. Bias mitigation techniques include diverse training data and fairness metrics. Privacy protection involves securing user data and complying with regulations like GDPR. Explainable AI makes AI decisions transparent and interpretable. General AI represents theoretical human-level artificial intelligence. Understanding AI ethics and future trends is essential for responsible AI development and staying informed about the evolving landscape of AI technology. AI governance establishes policies and oversight. By understanding AI ethics and future trends, you can develop AI responsibly and stay informed about the evolving AI landscape. Ethical considerations in AI development include addressing bias in training data and algorithms. Bias mitigation techniques include diverse training data and fairness metrics. Privacy protection involves securing user data and complying with regulations like GDPR. Explainable AI makes AI decisions transparent and interpretable. General AI represents theoretical human-level artificial intelligence. Understanding AI ethics and future trends is essential for responsible AI development and staying informed about the evolving landscape of AI technology. Accountability determines responsibility for AI decisions.'
      },
      {
        id: 7,
        title: 'AI Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply AI concepts to build end-to-end AI applications. This module guides you through developing projects that utilize machine learning and deep learning techniques. Building real-world AI projects helps you gain practical experience and demonstrate your skills. Projects include image classification, natural language processing, and predictive analytics. By building AI projects, you apply what you\'ve learned and create portfolio pieces that showcase your AI capabilities. AI projects integrate data collection, model training, evaluation, and deployment. Apply AI concepts to build end-to-end AI applications. This module guides you through developing projects that utilize machine learning and deep learning techniques. Building real-world AI projects helps you gain practical experience and demonstrate your skills. Projects include image classification, natural language processing, and predictive analytics. By building AI projects, you apply what you\'ve learned and create portfolio pieces that showcase your AI capabilities. AI projects integrate data collection, model training, evaluation, and deployment. Image classification identifies objects in images.',
        description2: 'Image classification projects involve training models to recognize and categorize images. Natural language processing projects include sentiment analysis, text generation, and chatbots. Predictive analytics projects forecast outcomes based on historical data. Building AI projects demonstrates practical skills and helps you gain experience in implementing AI solutions in real-world scenarios. End-to-end projects cover the complete ML pipeline. Portfolio projects showcase your capabilities to employers. By building AI projects, you apply what you\'ve learned and create portfolio pieces that showcase your AI capabilities. Image classification projects involve training models to recognize and categorize images. Natural language processing projects include sentiment analysis, text generation, and chatbots. Predictive analytics projects forecast outcomes based on historical data. Building AI projects demonstrates practical skills and helps you gain experience in implementing AI solutions in real-world scenarios. Model deployment makes projects production-ready.'
      },
      {
        id: 8,
        title: 'AI Importance',
        duration: '3 hours',
        completed: false,
        description: 'Understand the importance of AI technology and its impact on society. This module explores the transformative potential of AI and its implications for various industries. AI is one of the most significant technological developments of our time. Understanding the importance of AI helps you appreciate its applications and potential. AI has the potential to revolutionize industries by automating tasks, improving efficiency, and enabling new capabilities. Healthcare benefits from AI through better diagnosis and treatment. Finance uses AI for risk assessment and fraud detection. Transportation is being transformed by autonomous vehicles. By understanding the importance of AI, you recognize its transformative impact on society and economy. Understand the importance of AI technology and its impact on society. This module explores the transformative potential of AI and its implications for various industries. AI is one of the most significant technological developments of our time. Understanding the importance of AI helps you appreciate its applications and potential. AI has the potential to revolutionize industries by automating tasks, improving efficiency, and enabling new capabilities. Healthcare benefits from AI through better diagnosis and treatment. Finance uses AI for risk assessment and fraud detection. Transportation is being transformed by autonomous vehicles. By understanding the importance of AI, you recognize its transformative impact on society and economy. AI drives innovation and competitive advantage.',
        description2: 'AI technology is important because it has the potential to revolutionize industries, improve efficiency, and enhance decision-making. Benefits of AI include automating repetitive tasks, providing insights from data, and enabling capabilities that were previously impossible. AI applications span healthcare, finance, transportation, education, entertainment, and more. Recognizing the transformative potential of AI is essential for anyone looking to work in or invest in this rapidly growing field. AI creates new job opportunities while transforming existing roles. Economic impact of AI is measured in trillions of dollars. By understanding the importance of AI, you recognize its transformative impact on society and economy. AI technology is important because it has the potential to revolutionize industries, improve efficiency, and enhance decision-making. Benefits of AI include automating repetitive tasks, providing insights from data, and enabling capabilities that were previously impossible. AI applications span healthcare, finance, transportation, education, entertainment, and more. Recognizing the transformative potential of AI is essential for anyone looking to work in or invest in this rapidly growing field. AI democratization makes AI accessible to everyone.'
      }
    ],
    '19': [
      {
        id: 1,
        title: 'Photography Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Photography is the art and science of capturing light to create images. This module introduces photography basics, including camera settings, composition, and lighting techniques. Photography combines technical skills with artistic vision to create compelling visual stories. Understanding photography fundamentals is essential for taking great photos and developing your creative vision. Camera settings include aperture, shutter speed, and ISO, which together control exposure. Composition refers to how elements are arranged within the frame. Lighting is one of the most important aspects of photography. By mastering photography fundamentals, you can take control of your camera and create images that express your vision. Photography is the art and science of capturing light to create images. This module introduces photography basics, including camera settings, composition, and lighting techniques. Photography combines technical skills with artistic vision to create compelling visual stories. Understanding photography fundamentals is essential for taking great photos and developing your creative vision. Camera settings include aperture, shutter speed, and ISO, which together control exposure. Composition refers to how elements are arranged within the frame. Lighting is one of the most important aspects of photography. By mastering photography fundamentals, you can take control of your camera and create images that express your vision. Exposure triangle balances aperture, shutter speed, and ISO.',
        description2: 'Aperture controls depth of field and how much light enters the camera. Shutter speed determines how motion is captured - fast shutter speeds freeze action while slow speeds create motion blur. ISO controls sensor sensitivity - higher ISO allows shooting in low light but introduces noise. How to use these settings together to achieve different effects and creative results. Understanding photography fundamentals is essential for taking great photos and developing your creative vision as a photographer. White balance adjusts color temperature. Histogram helps evaluate exposure. By mastering photography fundamentals, you can take control of your camera and create images that express your vision. Aperture controls depth of field and how much light enters the camera. Shutter speed determines how motion is captured - fast shutter speeds freeze action while slow speeds create motion blur. ISO controls sensor sensitivity - higher ISO allows shooting in low light but introduces noise. How to use these settings together to achieve different effects and creative results. Understanding photography fundamentals is essential for taking great photos and developing your creative vision as a photographer. Focus modes determine how camera achieves sharp focus.'
      },
      {
        id: 2,
        title: 'Camera Techniques',
        duration: '3 hours',
        completed: false,
        description: 'Camera techniques involve mastering the use of your camera to capture the best possible images. This module covers focusing, exposure, and shooting modes. Understanding your camera\'s capabilities and how to use them effectively is crucial for great photography. Focusing techniques include manual focus, autofocus, and focus tracking. Exposure compensation allows you to adjust exposure when the camera\'s metering is not perfect. Shooting modes include aperture priority, shutter priority, and manual mode. By mastering camera techniques, you gain greater control over your photography and can capture the images you envision. Camera techniques involve mastering the use of your camera to capture the best possible images. This module covers focusing, exposure, and shooting modes. Understanding your camera\'s capabilities and how to use them effectively is crucial for great photography. Focusing techniques include manual focus, autofocus, and focus tracking. Exposure compensation allows you to adjust exposure when the camera\'s metering is not perfect. Shooting modes include aperture priority, shutter priority, and manual mode. By mastering camera techniques, you gain greater control over your photography and can capture the images you envision. Metering modes measure light in the scene.',
        description2: 'Using manual focus gives you complete control over what is sharp in your image. Exposure compensation adjusts the camera\'s suggested exposure up or down. Different shooting modes provide varying levels of control - aperture priority controls depth of field, shutter priority controls motion, and manual mode gives complete control. Mastering camera techniques allows you to have greater control over your photography and capture stunning images in any situation. Drive modes control how many photos are taken. Image stabilization reduces camera shake. By mastering camera techniques, you gain greater control over your photography and can capture the images you envision. Using manual focus gives you complete control over what is sharp in your image. Exposure compensation adjusts the camera\'s suggested exposure up or down. Different shooting modes provide varying levels of control - aperture priority controls depth of field, shutter priority controls motion, and manual mode gives complete control. Mastering camera techniques allows you to have greater control over your photography and capture stunning images in any situation. Bracketing captures multiple exposures.'
      },
      {
        id: 3,
        title: 'Composition & Lighting',
        duration: '4 hours',
        completed: false,
        description: 'Composition and lighting are key elements of photography that affect the visual impact of your images. This module covers composition rules, lighting setups, and how to use natural and artificial light. Good composition guides the viewer\'s eye and creates visual interest. Lighting shapes the mood and feel of an image. Understanding composition and lighting helps you create visually compelling photographs that tell a story. Rule of thirds divides the frame into nine parts and places subjects at intersections. Leading lines draw the viewer\'s eye through the image. Natural light includes golden hour, blue hour, and overcast light. Artificial light includes flash, continuous lights, and studio strobes. By mastering composition and lighting, you can create images with strong visual impact. Composition and lighting are key elements of photography that affect the visual impact of your images. This module covers composition rules, lighting setups, and how to use natural and artificial light. Good composition guides the viewer\'s eye and creates visual interest. Lighting shapes the mood and feel of an image. Understanding composition and lighting helps you create visually compelling photographs that tell a story. Rule of thirds divides the frame into nine parts and places subjects at intersections. Leading lines draw the viewer\'s eye through the image. Natural light includes golden hour, blue hour, and overcast light. Artificial light includes flash, continuous lights, and studio strobes. By mastering composition and lighting, you can create images with strong visual impact. Negative space emphasizes the subject.',
        description2: 'Rule of thirds creates balanced and interesting compositions. Leading lines guide the viewer\'s eye through the image toward the subject. Creating different lighting effects involves understanding light direction, quality, and color. Understanding composition and lighting helps you create visually compelling photographs that tell a story and evoke emotions in viewers. Patterns and symmetry create visual rhythm. Framing draws attention to the subject. By mastering composition and lighting, you can create images with strong visual impact. Rule of thirds creates balanced and interesting compositions. Leading lines guide the viewer\'s eye through the image toward the subject. Creating different lighting effects involves understanding light direction, quality, and color. Understanding composition and lighting helps you create visually compelling photographs that tell a story and evoke emotions in viewers. Color theory enhances visual harmony.'
      },
      {
        id: 4,
        title: 'Post-Processing & Editing',
        duration: '3 hours',
        completed: false,
        description: 'Post-processing involves editing your photos to enhance their appearance. This module covers photo editing software, basic adjustments, and creative editing techniques. Post-processing is an essential part of digital photography that allows you to refine your images. Photo editing software includes Adobe Lightroom and Photoshop. Basic adjustments include exposure, contrast, highlights, shadows, and saturation. Creative editing techniques include color grading, compositing, and retouching. By mastering post-processing, you can bring out the best in your photos and develop your unique visual style. Post-processing involves editing your photos to enhance their appearance. This module covers photo editing software, basic adjustments, and creative editing techniques. Post-processing is an essential part of digital photography that allows you to refine your images. Photo editing software includes Adobe Lightroom and Photoshop. Basic adjustments include exposure, contrast, highlights, shadows, and saturation. Creative editing techniques include color grading, compositing, and retouching. By mastering post-processing, you can bring out the best in your photos and develop your unique visual style. RAW format preserves maximum image data.',
        description2: 'Tools like Adobe Lightroom and Photoshop provide comprehensive editing capabilities. Adjusting exposure corrects brightness and brings out detail in shadows and highlights. Color correction and color grading set the mood and style of your images. Post-processing skills allow you to bring out the best in your photos and create your unique style that distinguishes your work. Layers enable non-destructive editing. Presets speed up workflow. By mastering post-processing, you can bring out the best in your photos and develop your unique visual style. Tools like Adobe Lightroom and Photoshop provide comprehensive editing capabilities. Adjusting exposure corrects brightness and brings out detail in shadows and highlights. Color correction and color grading set the mood and style of your images. Post-processing skills allow you to bring out the best in your photos and create your unique style that distinguishes your work. Masking applies adjustments selectively.'
      },
      {
        id: 5,
        title: 'Photography Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply photography concepts to real-world projects. This module guides you through developing photography projects that showcase your skills and creativity. Building a photography portfolio demonstrates your abilities and style. Projects include portrait photography, landscape photography, and street photography. By working on photography projects, you gain practical experience and develop your artistic voice. Photography projects help you apply technical skills in creative ways and build a body of work that represents your vision. Apply photography concepts to real-world projects. This module guides you through developing photography projects that showcase your skills and creativity. Building a photography portfolio demonstrates your abilities and style. Projects include portrait photography, landscape photography, and street photography. By working on photography projects, you gain practical experience and develop your artistic voice. Photography projects help you apply technical skills in creative ways and build a body of work that represents your vision. Portrait photography captures personality and emotion.',
        description2: 'Portrait photography involves working with people to capture their personality and emotion. Landscape photography captures the beauty of natural and urban environments. Street photography documents everyday life and human moments. Building photography projects helps you gain practical experience and develop your portfolio with diverse work that showcases your range and capabilities as a photographer. Product photography showcases items attractively. Event photography captures special moments. By working on photography projects, you gain practical experience and develop your artistic voice. Portrait photography involves working with people to capture their personality and emotion. Landscape photography captures the beauty of natural and urban environments. Street photography documents everyday life and human moments. Building photography projects helps you gain practical experience and develop your portfolio with diverse work that showcases your range and capabilities as a photographer. Documentary photography tells stories.'
      }
    ],
    '20': [
      {
        id: 1,
        title: 'Content Writing Fundamentals',
        duration: '2 hours',
        completed: false,
        description: 'Content writing involves creating written material for digital platforms. This module introduces content writing basics, including different types of content and writing techniques. Content writing is essential for digital marketing, communication, and engagement. Understanding content writing fundamentals is essential for producing engaging and effective written content. Different types of content include blog posts, articles, social media posts, website copy, and email newsletters. Writing techniques include understanding your audience, writing clear and concise copy, and using storytelling. By mastering content writing fundamentals, you can create content that resonates with your audience and achieves your communication goals. Content writing involves creating written material for digital platforms. This module introduces content writing basics, including different types of content and writing techniques. Content writing is essential for digital marketing, communication, and engagement. Understanding content writing fundamentals is essential for producing engaging and effective written content. Different types of content include blog posts, articles, social media posts, website copy, and email newsletters. Writing techniques include understanding your audience, writing clear and concise copy, and using storytelling. By mastering content writing fundamentals, you can create content that resonates with your audience and achieves your communication goals. Audience research identifies reader needs and preferences.',
        description2: 'Blog posts provide information, entertainment, or education to readers. Articles offer in-depth coverage of topics. Social media content engages followers with concise, shareable posts. SEO writing optimizes content for search engines while maintaining readability. Understanding content writing fundamentals is essential for producing engaging and effective written content that meets both reader and business needs. Tone and voice reflect brand personality. Headlines attract reader attention. By mastering content writing fundamentals, you can create content that resonates with your audience and achieves your communication goals. Blog posts provide information, entertainment, or education to readers. Articles offer in-depth coverage of topics. Social media content engages followers with concise, shareable posts. SEO writing optimizes content for search engines while maintaining readability. Understanding content writing fundamentals is essential for producing engaging and effective written content that meets both reader and business needs. Call-to-action prompts desired reader behavior.'
      },
      {
        id: 2,
        title: 'Writing for the Web',
        duration: '3 hours',
        completed: false,
        description: 'Writing for the web requires a different approach than traditional writing. This module covers web writing techniques, including scannable content, headlines, and calls to action. Web readers scan rather than read word-for-word, so web content must be easily scannable. Understanding web writing techniques helps you create content that captures readers\' attention and keeps them engaged. Scannable content uses short paragraphs, subheadings, bullet points, and white space. Headlines should be clear, compelling, and informative. Calls to action encourage readers to take specific actions. By mastering web writing techniques, you create content that resonates with online audiences and achieves your goals. Writing for the web requires a different approach than traditional writing. This module covers web writing techniques, including scannable content, headlines, and calls to action. Web readers scan rather than read word-for-word, so web content must be easily scannable. Understanding web writing techniques helps you create content that captures readers\' attention and keeps them engaged. Scannable content uses short paragraphs, subheadings, bullet points, and white space. Headlines should be clear, compelling, and informative. Calls to action encourage readers to take specific actions. By mastering web writing techniques, you create content that resonates with online audiences and achieves your goals. Formatting improves readability.',
        description2: 'Writing concise and engaging content that captures readers\' attention in a crowded digital landscape. Mastering web writing techniques helps you create content that resonates with online audiences and achieves communication and marketing objectives. Web content should provide value quickly and be easy to consume. Links provide additional resources and improve SEO. Mobile optimization ensures content works on all devices. By mastering web writing techniques, you create content that resonates with online audiences and achieves your goals. Writing concise and engaging content that captures readers\' attention in a crowded digital landscape. Mastering web writing techniques helps you create content that resonates with online audiences and achieves communication and marketing objectives. Web content should provide value quickly and be easy to consume. Meta descriptions summarize page content for search results.'
      },
      {
        id: 3,
        title: 'SEO Content Writing',
        duration: '4 hours',
        completed: false,
        description: 'SEO content writing involves optimizing your content for search engines. This module covers keyword research, on-page SEO, and creating content that ranks well in search results. SEO (Search Engine Optimization) helps your content be discovered by people searching for information. Understanding SEO content writing is crucial for increasing visibility and driving traffic to your website. Keyword research identifies terms people search for related to your topic. On-page SEO includes optimizing titles, meta descriptions, headers, and content. Creating valuable content that attracts organic traffic requires balancing SEO optimization with user value. By mastering SEO content writing, you can create content that ranks well and attracts your target audience. SEO content writing involves optimizing your content for search engines. This module covers keyword research, on-page SEO, and creating content that ranks well in search results. SEO (Search Engine Optimization) helps your content be discovered by people searching for information. Understanding SEO content writing is crucial for increasing visibility and driving traffic to your website. Keyword research identifies terms people search for related to your topic. On-page SEO includes optimizing titles, meta descriptions, headers, and content. Creating valuable content that attracts organic traffic requires balancing SEO optimization with user value. By mastering SEO content writing, you can create content that ranks well and attracts your target audience. Search intent determines what users want to find.',
        description2: 'Identifying relevant keywords involves understanding what your audience searches for. Optimizing your content structure includes using keywords naturally in titles, headings, and body text. Creating valuable content that attracts organic traffic means providing genuine value that answers user questions and solves problems. SEO content writing is crucial for increasing visibility and driving traffic to your website through search engines. Internal linking connects related content. Backlinks improve domain authority. By mastering SEO content writing, you can create content that ranks well and attracts your target audience. Identifying relevant keywords involves understanding what your audience searches for. Optimizing your content structure includes using keywords naturally in titles, headings, and body text. Creating valuable content that attracts organic traffic means providing genuine value that answers user questions and solves problems. SEO content writing is crucial for increasing visibility and driving traffic to your website through search engines. Featured snippets provide visibility in search results.'
      },
      {
        id: 4,
        title: 'Content Marketing Strategies',
        duration: '3 hours',
        completed: false,
        description: 'Content marketing involves creating and distributing valuable content to attract and engage a target audience. This module covers content marketing strategies, including audience research, content planning, and distribution channels. Content marketing builds relationships with audiences by providing value before asking for anything in return. Understanding content marketing strategies helps you reach your target audience and achieve your marketing goals. Audience research identifies who your target audience is and what they need. Content planning involves creating a content calendar and planning topics that resonate with your audience. Distribution channels include your website, social media, email, and third-party platforms. By mastering content marketing strategies, you can effectively reach and engage your target audience. Content marketing involves creating and distributing valuable content to attract and engage a target audience. This module covers content marketing strategies, including audience research, content planning, and distribution channels. Content marketing builds relationships with audiences by providing value before asking for anything in return. Understanding content marketing strategies helps you reach your target audience and achieve your marketing goals. Audience research identifies who your target audience is and what they need. Content planning involves creating a content calendar and planning topics that resonate with your audience. Distribution channels include your website, social media, email, and third-party platforms. By mastering content marketing strategies, you can effectively reach and engage your target audience. Buyer personas represent ideal customers.',
        description2: 'Developing a content marketing strategy involves defining goals, understanding your audience, and creating valuable content. Creating a content calendar helps plan and organize content creation and publication. Promoting your content effectively through various channels ensures it reaches your target audience. Understanding content marketing strategies helps you reach your target audience and achieve your marketing goals through valuable content that builds relationships and drives results. Analytics measure content performance. Repurposing extends content value. By mastering content marketing strategies, you can effectively reach and engage your target audience. Developing a content marketing strategy involves defining goals, understanding your audience, and creating valuable content. Creating a content calendar helps plan and organize content creation and publication. Promoting your content effectively through various channels ensures it reaches your target audience. Understanding content marketing strategies helps you reach your target audience and achieve your marketing goals through valuable content that builds relationships and drives results. Lead magnets capture audience information.'
      },
      {
        id: 5,
        title: 'Content Writing Projects',
        duration: '4 hours',
        completed: false,
        description: 'Apply content writing concepts to real-world projects. This module guides you through developing content writing projects that demonstrate your skills and creativity. Building a content writing portfolio showcases your abilities to potential clients or employers. Projects include blog posts, social media campaigns, and website content. By working on content writing projects, you gain practical experience and develop your portfolio with diverse samples that demonstrate your range. Content writing projects apply the skills learned throughout the course in practical scenarios. Apply content writing concepts to real-world projects. This module guides you through developing content writing projects that demonstrate your skills and creativity. Building a content writing portfolio showcases your abilities to potential clients or employers. Projects include blog posts, social media campaigns, and website content. By working on content writing projects, you gain practical experience and develop your portfolio with diverse samples that demonstrate your range. Content writing projects apply the skills learned throughout the course in practical scenarios. Case studies demonstrate measurable results.',
        description2: 'Blog post projects involve researching, writing, and optimizing articles on various topics. Social media campaign projects include creating cohesive content across multiple platforms. Website content projects involve writing copy that converts visitors into customers. Building content writing projects helps you gain practical experience and develop your portfolio with work samples that demonstrate your capabilities to potential clients or employers. Email campaigns nurture leads. White papers establish thought leadership. By working on content writing projects, you gain practical experience and develop your portfolio with diverse samples that demonstrate your range. Blog post projects involve researching, writing, and optimizing articles on various topics. Social media campaign projects include creating cohesive content across multiple platforms. Website content projects involve writing copy that converts visitors into customers. Building content writing projects helps you gain practical experience and develop your portfolio with work samples that demonstrate your capabilities to potential clients or employers. Portfolio diversity showcases versatility.'
      },
      {
        id: 6,
        title: 'Copywriting Techniques',
        duration: '3 hours',
        completed: false,
        description: 'Copywriting involves writing persuasive content that encourages readers to take action. This module covers copywriting techniques, including crafting compelling headlines, writing effective calls to action, and using storytelling in copy. Copywriting is focused on conversion and sales, distinguishing it from other forms of content writing. Understanding copywriting techniques is essential for creating content that drives results. Compelling headlines grab attention and make people want to read more. Effective calls to action clearly tell readers what to do next. Storytelling in copy creates emotional connections and makes messages memorable. By mastering copywriting techniques, you can create content that converts, engages, and resonates with your audience. Copywriting involves writing persuasive content that encourages readers to take action. This module covers copywriting techniques, including crafting compelling headlines, writing effective calls to action, and using storytelling in copy. Copywriting is focused on conversion and sales, distinguishing it from other forms of content writing. Understanding copywriting techniques is essential for creating content that drives results. Compelling headlines grab attention and make people want to read more. Effective calls to action clearly tell readers what to do next. Storytelling in copy creates emotional connections and makes messages memorable. By mastering copywriting techniques, you can create content that converts, engages, and resonates with your audience. AIDA model guides persuasive writing.',
        description2: 'Writing copy that converts requires understanding psychology, persuasion principles, and customer motivations. Copy that engages keeps readers interested and moving through your content. Copy that resonates creates emotional connections and builds trust. Mastering copywriting techniques is essential for creating content that drives results and achieves business objectives. Benefit-focused copy emphasizes value to customers. Social proof builds credibility. By mastering copywriting techniques, you can create content that converts, engages, and resonates with your audience. Writing copy that converts requires understanding psychology, persuasion principles, and customer motivations. Copy that engages keeps readers interested and moving through your content. Copy that resonates creates emotional connections and builds trust. Mastering copywriting techniques is essential for creating content that drives results and achieves business objectives. Urgency and scarcity motivate action.'
      },
      {
        id: 7,
        title: 'Content Writing for Social Media',
        duration: '3 hours',
        completed: false,
        description: 'Social media content writing involves creating engaging posts for various social media platforms. This module covers platform-specific writing techniques, audience engagement, and content scheduling. Each social media platform has unique characteristics and audience expectations. Understanding content writing for social media helps you build a strong online presence and connect with your audience. Platform-specific writing techniques include adapting tone, length, and format for each platform. Audience engagement involves encouraging interaction through questions, polls, and conversations. Content scheduling ensures consistent posting and optimal timing. By mastering social media content writing, you can effectively engage your audience and build your brand presence. Social media content writing involves creating engaging posts for various social media platforms. This module covers platform-specific writing techniques, audience engagement, and content scheduling. Each social media platform has unique characteristics and audience expectations. Understanding content writing for social media helps you build a strong online presence and connect with your audience. Platform-specific writing techniques include adapting tone, length, and format for each platform. Audience engagement involves encouraging interaction through questions, polls, and conversations. Content scheduling ensures consistent posting and optimal timing. By mastering social media content writing, you can effectively engage your audience and build your brand presence. Hashtags increase content discoverability.',
        description2: 'Writing content that resonates with social media audiences requires understanding platform culture and user behavior. Content that encourages interaction includes questions, polls, user-generated content campaigns, and contests. Promoting your brand effectively on social media builds awareness, engagement, and loyalty. Understanding content writing for social media helps you build a strong online presence and connect with your audience across multiple platforms. Visual content complements written posts. Community management builds relationships. By mastering social media content writing, you can effectively engage your audience and build your brand presence. Writing content that resonates with social media audiences requires understanding platform culture and user behavior. Content that encourages interaction includes questions, polls, user-generated content campaigns, and contests. Promoting your brand effectively on social media builds awareness, engagement, and loyalty. Understanding content writing for social media helps you build a strong online presence and connect with your audience across multiple platforms. Analytics inform content strategy.'
      },
      {
        id: 8,
        title: 'Content Writing Importance',
        duration: '3 hours',
        completed: false,
        description: 'Understand the importance of content writing in digital marketing and communication. This module explores the role of content writing in building brand awareness, engaging audiences, and driving business results. Content writing is the foundation of digital marketing and online communication. Understanding the importance of content writing helps you appreciate its applications and value. Content writing helps businesses communicate their message clearly and effectively. It builds brand awareness by increasing visibility and establishing thought leadership. Engaging content connects with audiences and builds relationships. By mastering content writing skills, you can create compelling content that resonates with your target audience and supports your overall marketing strategy. Understand the importance of content writing in digital marketing and communication. This module explores the role of content writing in building brand awareness, engaging audiences, and driving business results. Content writing is the foundation of digital marketing and online communication. Understanding the importance of content writing helps you appreciate its applications and value. Content writing helps businesses communicate their message clearly and effectively. It builds brand awareness by increasing visibility and establishing thought leadership. Engaging content connects with audiences and builds relationships. By mastering content writing skills, you can create compelling content that resonates with your target audience and supports your overall marketing strategy. Quality content builds trust.',
        description2: 'Content writing is important because it helps businesses communicate their message, connect with their audience, and achieve their marketing goals. Effective content writing can increase brand visibility, establish authority, and drive conversions. By mastering content writing skills, you can create compelling content that resonates with your target audience and supports your overall marketing strategy and business objectives. Content drives organic traffic through SEO. Thought leadership establishes expertise. By mastering content writing skills, you can create compelling content that resonates with your target audience and supports your overall marketing strategy. Content writing is important because it helps businesses communicate their message, connect with their audience, and achieve their marketing goals. Effective content writing can increase brand visibility, establish authority, and drive conversions. By mastering content writing skills, you can create compelling content that resonates with your target audience and supports your overall marketing strategy and business objectives. Content marketing costs less than traditional advertising.'
      },
      {
        id: 9,
        title: 'Final Content Writing Project',
        duration: '3 hours',
        completed: false,
        description: 'Apply all the content writing skills you have learned in this course to a comprehensive project. This final project will allow you to demonstrate your mastery of content writing principles and techniques. Creating a comprehensive final project consolidates your learning and showcases your abilities. This project includes planning, writing, and editing high-quality content for various audiences and platforms. By completing this final project, you create a valuable portfolio piece that demonstrates your readiness to work as a professional content writer. The final project integrates all skills learned throughout the course in one comprehensive deliverable. Apply all the content writing skills you have learned in this course to a comprehensive project. This final project will allow you to demonstrate your mastery of content writing principles and techniques. Creating a comprehensive final project consolidates your learning and showcases your abilities. This project includes planning, writing, and editing high-quality content for various audiences and platforms. By completing this final project, you create a valuable portfolio piece that demonstrates your readiness to work as a professional content writer. The final project integrates all skills learned throughout the course in one comprehensive deliverable. Project planning demonstrates strategic thinking.',
        description2: 'Creating a complete content writing project that showcases your ability to plan, write, and edit high-quality content for various audiences and platforms. This project will be a valuable addition to your portfolio and demonstrate your readiness to work as a professional content writer capable of delivering results. The comprehensive project covers research, strategy, creation, optimization, and measurement of content effectiveness. Portfolio presentation showcases professional capabilities. By completing this final project, you create a valuable portfolio piece that demonstrates your readiness to work as a professional content writer. Creating a complete content writing project that showcases your ability to plan, write, and edit high-quality content for various audiences and platforms. This project will be a valuable addition to your portfolio and demonstrate your readiness to work as a professional content writer capable of delivering results. The comprehensive project covers research, strategy, creation, optimization, and measurement of content effectiveness. Professional presentation impresses potential employers or clients.'
      }
    ]
  };

  // Key features for different courses
  allKeyFeatures: { [key: string]: string[] } = {
    '21': [
      'Uses tags to define web page elements',
      'Forms the basic structure of every website',
      'Works with CSS for styling and JavaScript for interactivity',
      'Supports text, images, links, lists, tables, and forms',
      'Easy to learn and essential for web development'
    ],
    '1': [
      'Build modern single-page applications',
      'Master TypeScript and component architecture',
      'Implement reactive forms and routing',
      'Work with RxJS and observables',
      'Deploy production-ready applications'
    ],
    '2': [
      'Build React applications with functional components',
      'Master hooks for state and side effects',
      'Implement routing with React Router',
      'Manage state with Context API and Redux',
      'Deploy production-ready applications'
    ],
    '3': [
      'Learn Full Stack JavaScript development',
      'Build RESTful APIs with Node.js and Express',
      'Work with MongoDB for data storage',
      'Implement authentication and security',
      'Deploy full stack applications to the cloud'
    ],
    '4': [
      'Master Python programming fundamentals',
      'Work with data structures and algorithms',
      'Build web applications with Flask and Django',
      'Explore data science libraries like Pandas and NumPy',
      'Apply Python in real-world projects'
    ],
    '5': [
      'Learn Java programming fundamentals',
      'Work with object-oriented programming concepts',
      'Build applications using Java frameworks like Spring Boot',
      'Explore Java\'s rich ecosystem of libraries and tools',
      'Apply Java in real-world projects'
    ],
    '6': [
      'Master digital marketing strategies',
      'Learn SEO, content marketing, and social media marketing',
      'Build email marketing campaigns',
      'Use Google Analytics for data-driven marketing',
      'Develop integrated campaign strategies'
    ],
    '7': [
      'Understand UI/UX design principles',
      'Master Figma for interface design',
      'Conduct user research and usability testing',
      'Create wireframes and prototypes',
      'Build and maintain design systems'
    ],
    '8': [
      'Learn machine learning fundamentals',
      'Master supervised and unsupervised learning algorithms',
      'Build neural networks and deep learning models',
      'Use TensorFlow for machine learning development',
      'Apply machine learning in real-world projects'
    ],
    '9': [
      'Understand cloud computing concepts',
      'Learn AWS, Azure, and Google Cloud fundamentals',
      'Implement cloud security best practices',
      'Design cloud architectures for scalability and reliability',
      'Apply DevOps practices in the cloud'
    ],
    '10': [
      'Learn mobile development concepts',
      'Master Kotlin for Android and Swift for iOS',
      'Build cross-platform apps with React Native and Flutter',
      'Deploy mobile applications to app stores',
      'Build end-to-end mobile projects'
    ],
    '11': [
      'Understand cybersecurity fundamentals',
      'Learn about common cyber threats and attack vectors',
      'Implement basic cybersecurity defense strategies',
      'Explore cybersecurity tools and best practices',
      'Apply cybersecurity principles in real-world scenarios'
    ],
    '12': [
      'Learn Blockchain fundamentals',
      'Understand decentralized applications (DApps)',
      'Master smart contract development with Solidity',
      'Explore blockchain platforms like Ethereum and Hyperledger',
      'Apply blockchain technology in real-world projects'
    ],
    '13': [
      'Understand DevOps principles and practices',
      'Learn about CI/CD pipelines and tools',
      'Implement infrastructure as code (IaC)',
      'Explore monitoring and logging solutions',
      'Apply DevOps practices in real-world projects'
    ],
    '14': [
      'Learn about SQL and Database Management',
      'Understand relational and non-relational databases',
      'Master SQL queries and database design',
      'Explore database administration and optimization',
      'Apply database management skills in real-world projects'
    ],
    '15': [
      'Understand Business Analysis fundamentals',
      'Learn requirements gathering and documentation',
      'Master stakeholder communication and management',
      'Explore business process modeling and improvement',
      'Apply business analysis skills in real-world projects'
    ],
    '16': [
      'Learn about Node.js Backend Development',
      'Master Express.js for building REST APIs',
      'Work with databases like MongoDB and PostgreSQL',
      'Implement authentication and authorization in Node.js apps',
      'Deploy Node.js applications to production environments'
    ],
    '17': [
      'Understand Flutter Mobile Development',
      'Master Dart programming language',
      'Build cross-platform mobile apps with Flutter',
      'Implement state management solutions in Flutter',
      'Deploy Flutter applications to app stores'
    ],
    '18': [
      'Learn about Artificial Intelligence fundamentals',
      'Understand AI techniques and algorithms',
      'Explore AI applications in various industries',
      'Master AI development tools and frameworks',
      'Apply AI concepts in real-world projects'
    ],
    '19': [
      'Understand Phtotography fundamentals',
      'Learn about camera settings and techniques',
      'Master composition and lighting principles',
      'Explore post-processing and editing tools',
      'Apply photography skills in real-world projects'
    ],
    '20': [
      'Learn about Content Writing fundamentals',
      'Understand different types of content writing',
      'Master writing techniques for web and social media',
      'Explore SEO best practices for content writing',
      'Apply content writing skills in real-world projects'
    ]
  };

  // Key features
  KeyFeatures: { [key: string]: string[] } = {
    // Your existing allKeyFeatures data
  };

  keyFeatures: string[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.courseId = this.route.snapshot.paramMap.get('id');

    if (this.courseId && this.allCourses[this.courseId]) {
      this.course = this.allCourses[this.courseId];
      this.modules = this.allModules[this.courseId] || [];
      this.keyFeatures = this.allKeyFeatures[this.courseId] || [];

      console.log('Loaded Course:', this.course.title);
    } else {
      console.error('Course not found, redirecting...');
      this.router.navigate(['/course']);
    }
  }
  selectModule(moduleId: number): void {
    // First, switch to Course Content tab
    this.currentTab = 'content';

    // Then toggle the module
    if (this.selectedModuleId === moduleId) {
      this.selectedModuleId = null;  // Close if same module
    } else {
      this.selectedModuleId = moduleId;  // Open new module
    }
  }

  // ✅ Check if module is expanded
  isModuleExpanded(moduleId: number): boolean {
    return this.selectedModuleId === moduleId;
  }

  setTab(tab: string): void {
    this.currentTab = tab;
  }

  goBack(): void {
    this.router.navigate(['/course']);
  }
}