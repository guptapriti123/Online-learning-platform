import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth-service';
import { CourseService } from '../services/course-service';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-profile.html',
  styleUrls: ['./user-profile.css']
})
export class UserProfile implements OnInit {
  user: any = {
    name: '',
    email: '',
    id: null,
    joinedDate: new Date()
  };

  editData = {
    name: '',
    email: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };

  showEditModal = false;
  successMsg = '';
  errorMsg = '';

  stats = {
    coursesCompleted: 0
  };

  constructor(
    private router: Router,
    private authService: AuthService,
    private courseService: CourseService
  ) {}

  ngOnInit() {
    this.loadUserData();
    this.loadStats();
  }

  loadUserData() {
    this.user.name = localStorage.getItem('userName') || 'User';
    this.user.email = localStorage.getItem('userEmail') || 'user@example.com';
    this.user.id = localStorage.getItem('userId') || null;
  }

  loadStats() {
    // Load total courses count
    this.courseService.getCourses().subscribe({
      next: (courses) => {
        this.stats.coursesCompleted = courses.length;
      },
      error: (error) => {
        console.error('Error loading stats:', error);
      }
    });
  }

  goToCourses() {
    this.router.navigate(['/course']);
  }

  goToHome() {
    this.router.navigate(['/home']);
  }
  editProfile() {
    this.editData.name = this.user.name;
    this.editData.email = this.user.email;
    this.editData.currentPassword = '';
    this.editData.newPassword = '';
    this.editData.confirmPassword = '';
    this.showEditModal = true;
    this.successMsg = '';
    this.errorMsg = '';
  }

  closeModal() {
    this.showEditModal = false;
    this.errorMsg = '';
    this.successMsg = '';
  }

  saveProfile() {
    this.errorMsg = '';
    this.successMsg = '';

    // Validation
    if (!this.editData.name || !this.editData.email) {
      this.errorMsg = 'Name and email are required';
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.editData.email)) {
      this.errorMsg = 'Please enter a valid email';
      return;
    }

    if (this.editData.newPassword) {
      if (!this.editData.currentPassword) {
        this.errorMsg = 'Current password is required to change password';
        return;
      }
      if (this.editData.newPassword !== this.editData.confirmPassword) {
        this.errorMsg = 'New passwords do not match';
        return;
      }
      if (this.editData.newPassword.length < 6) {
        this.errorMsg = 'Password must be at least 6 characters';
        return;
      }
    }

    // Prepare data for backend
    const updateData = {
      name: this.editData.name,
      email: this.editData.email,
      currentPassword: this.editData.currentPassword,
      newPassword: this.editData.newPassword
    };

    // Call backend API
    this.authService.updateProfile(updateData).subscribe({
      next: (response) => {
        if (response.status) {
          this.successMsg = 'Profile updated successfully!';
          
          // Update localStorage
          localStorage.setItem('userName', response.name);
          localStorage.setItem('userEmail', response.email);
          
          // Update local data
          this.user.name = response.name;
          this.user.email = response.email;

          // Close modal after 2 seconds
          setTimeout(() => {
            this.closeModal();
            window.location.reload();
          }, 2000);
        } else {
          this.errorMsg = response.message || 'Update failed';
        }
      },
      error: (err) => {
        console.error('Update error:', err);
        this.errorMsg = err.error?.message || 'Update failed. Please try again.';
      }
    });
  }
}