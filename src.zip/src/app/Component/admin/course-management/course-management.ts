import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService } from '../../services/course-service';
import { Course } from '../../model/course.model';

@Component({
  selector: 'app-course-management',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './course-management.html',
  styleUrl: './course-management.css',
})
export class CourseManagement implements OnInit {
  courses: Course[] = [];
  course: Course = {
    id: 0,
    title: '',
    description: '',
    instructor: '',
    duration: ''
  };
  isEdit = false;
  showModal = false;
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  constructor(private courseService: CourseService) {}

  ngOnInit() {
    this.loadCourses();
  }

  loadCourses() {
    this.courseService.getCourses().subscribe({
      next: (data: Course[]) => {
        this.courses = data;
        console.log('Courses loaded:', this.courses);
      },
      error: (error) => {
        console.error('Error loading courses:', error);
        this.showError('Failed to load courses');
      }
    });
  }

  goBack() {
    window.history.back();
  }

  openModal() {
    this.showModal = true;
    this.resetForm();
  }

  closeModal() {
    this.showModal = false;
    this.resetForm();
  }

  saveCourse() {
    // Validation
    if (!this.course.title || !this.course.description) {
      this.showError('Title and description are required');
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    if (this.isEdit) {
      // Update existing course
      this.courseService.updateCourse(this.course.id, this.course).subscribe({
        next: (response) => {
          console.log('Update response:', response);
          this.showSuccess('Course updated successfully!');
          this.closeModal();
          this.loadCourses();
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Update error:', error);
          this.showError(error.error?.message || 'Failed to update course');
          this.isLoading = false;
        }
      });
    } else {
      // Add new course
      console.log('Adding course:', this.course);
      this.courseService.addCourse(this.course).subscribe({
        next: (response) => {
          console.log('Add course response:', response);
          this.showSuccess('Course added successfully!');
          this.closeModal();
          this.loadCourses();
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Add error:', error);
          this.showError(error.error?.message || 'Failed to add course');
          this.isLoading = false;
        }
      });
    }
  }

  editCourse(course: Course) {
    this.course = { ...course };
    this.isEdit = true;
    this.showModal = true;
  }

  deleteCourse(id: number) {
    if (!confirm('Are you sure you want to delete this course?')) {
      return;
    }

    this.courseService.deleteCourse(id).subscribe({
      next: (response) => {
        console.log('Delete response:', response);
        this.showSuccess('Course deleted successfully!');
        this.loadCourses();
      },
      error: (error) => {
        console.error('Delete error:', error);
        this.showError(error.error?.message || 'Failed to delete course');
      }
    });
  }

  resetForm() {
    this.course = {
      id: 0,
      title: '',
      description: '',
      instructor: '',
      duration: ''
    };
    this.isEdit = false;
    this.errorMessage = '';
  }

  showError(message: string) {
    this.errorMessage = message;
    setTimeout(() => {
      this.errorMessage = '';
    }, 5000);
  }

  showSuccess(message: string) {
    this.successMessage = message;
    setTimeout(() => {
      this.successMessage = '';
    }, 3000);
  }
}