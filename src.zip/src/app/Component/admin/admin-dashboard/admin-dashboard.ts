import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterModule, Router } from '@angular/router';
import { CourseService } from '../../services/course-service';
import { TutorService } from '../../services/tutor-service';  // ADD
import { UserService } from '../../services/user-service';    // ADD

interface DashboardStats {
  totalCourses: number;
  totalStudents: number;
  activeTutors: number;
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterLink],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css'],
})
export class AdminDashboard implements OnInit {
  stats: DashboardStats = {
    totalCourses: 0,
    totalStudents: 0,
    activeTutors: 0
  };

  isLoading: boolean = true;
  userName: string = '';
  userEmail: string = '';

  constructor(
    private courseService: CourseService,
    private tutorService: TutorService,    // ADD
    private userService: UserService,      // ADD
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadUserInfo();
    this.loadDashboardData();
  }

  loadUserInfo(): void {
    const name = localStorage.getItem('userName');
    const email = localStorage.getItem('userEmail');

    this.userName = name || 'Admin';
    this.userEmail = email || 'admin@gmail.com';
  }

  loadDashboardData(): void {
    this.isLoading = true;
    let loadedCount = 0;

    // Load courses
    this.courseService.getCourses().subscribe({
      next: (courses) => {
        this.stats.totalCourses = courses.length;
        loadedCount++;
        if (loadedCount === 3) this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading courses:', error);
        loadedCount++;
        if (loadedCount === 3) this.isLoading = false;
      }
    });

    // Load tutors
    this.tutorService.getTutors().subscribe({
      next: (tutors) => {
        this.stats.activeTutors = tutors.length;
        loadedCount++;
        if (loadedCount === 3) this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading tutors:', error);
        loadedCount++;
        if (loadedCount === 3) this.isLoading = false;
      }
    });

    // Load user count
    this.userService.getUserCount().subscribe({
      next: (response) => {
        if (response.status) {
          this.stats.totalStudents = response.count;
        }
        loadedCount++;
        if (loadedCount === 3) this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading user count:', error);
        loadedCount++;
        if (loadedCount === 3) this.isLoading = false;
      }
    });
  }

  goToCourseManagement(): void {
    this.router.navigate(['/admin/courses']);
  }

  // Navigate to user management
  goToUserManagement(): void {
    this.router.navigate(['/admin/users']);
  }

  // Navigate to tutor management
  goToTutorManagement(): void {
    this.router.navigate(['/admin/tutors']);
  }

  goToHome(): void {
    this.router.navigate(['/home']);
  }

  gotocourse(): void {
    this.router.navigate(['/course']);
  }
}