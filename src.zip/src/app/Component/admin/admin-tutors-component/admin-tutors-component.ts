import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TutorService } from '../../services/tutor-service';
import { Tutor } from '../../model/tutor-model';

@Component({
  selector: 'app-admin-tutors',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-tutors-component.html',  // ✅ CORRECT
  styleUrls: ['./admin-tutors-component.css']     // ✅ CORRECT
})
export class AdminTutorsComponent implements OnInit {
  tutors: Tutor[] = [];
  isLoading: boolean = true;
  showModal: boolean = false;
  isEditMode: boolean = false;

  currentTutor: Tutor = {
    name: '',
    expertise: '',
    image: '',
    description: ''
  };

  constructor(private tutorService: TutorService) {}

  ngOnInit(): void {
    this.loadTutors();
  }

  loadTutors(): void {
    this.tutorService.getTutors().subscribe({
      next: (tutors) => {
        this.tutors = tutors;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading tutors:', error);
        this.isLoading = false;
      }
    });
  }

  openAddModal(): void {
    this.isEditMode = false;
    this.currentTutor = {
      name: '',
      expertise: '',
      image: '',
      description: ''
    };
    this.showModal = true;
  }

  openEditModal(tutor: Tutor): void {
    this.isEditMode = true;
    this.currentTutor = { ...tutor };
    this.showModal = true;
  }

  goToDashboard(): void {
    // Implement navigation logic to go back to the admin dashboard
    window.location.href = '/admin';
  }

  closeModal(): void {
    this.showModal = false;
  }

  saveTutor(): void {
    if (this.isEditMode) {
      this.tutorService.updateTutor(this.currentTutor.id!, this.currentTutor).subscribe({
        next: (response) => {
          alert('Tutor updated successfully!');
          this.closeModal();
        },
        error: (error) => {
          console.error('Error updating tutor:', error);
          alert('Failed to update tutor');
        }
      });
    } else {
      this.tutorService.addTutor(this.currentTutor).subscribe({
        next: (response) => {
          alert('Tutor added successfully!');
          this.closeModal();
        },
        error: (error) => {
          console.error('Error adding tutor:', error);
          alert('Failed to add tutor');
        }
      });
    }
  }

  deleteTutor(id: number): void {
    if (confirm('Are you sure you want to delete this tutor?')) {
      this.tutorService.deleteTutor(id).subscribe({
        next: (response) => {
          alert('Tutor deleted successfully!');
        },
        error: (error) => {
          console.error('Error deleting tutor:', error);
          alert('Failed to delete tutor');
        }
      });
    }
  }
}