import { RouterModule, Routes } from '@angular/router';
import { Login } from './Component/auth/login/login';
import { AdminDashboard } from './Component/admin/admin-dashboard/admin-dashboard';
import { CourseList } from './Component/user/course-list/course-list';
import { Exportcomponent } from './Component/exportcomponent/exportcomponent';
import { Register } from './Component/auth/register/register';
import { CourseDetail } from './Component/user/course-detail/course-detail';
import { Contact } from './Component/contact/contact';
import { Home } from './Component/home/home';
import { authGuard } from './Component/guards/auth-guard';
import { UserProfile } from './Component/user-profile/user-profile';
import { AdminGuard } from './Component/guards/admin-guard';
import { CourseManagement } from './Component/admin/course-management/course-management';
import { AdminTutorsComponent } from './Component/admin/admin-tutors-component/admin-tutors-component';
import { AdminUsersComponent } from './Component/admin/admin-users-component/admin-users-component';
import { CourseContent } from './Component/user/course-content/course-content';

export const routes: Routes = [

  { path: '', redirectTo: 'home', pathMatch: 'full' },

  { path: 'home', component:Home },

  { path: 'course', component: CourseList ,canActivate: [authGuard]},

  { path: 'course-detail/:id', component: CourseDetail },

  { path: 'startedcourses/:id', component: CourseContent },

  { path: 'profile', component: UserProfile, canActivate: [authGuard] },

  { path: 'admin/users', component: AdminUsersComponent },
  
  { path: 'admin/tutors', component: AdminTutorsComponent },

  { path: 'tutors', component: Exportcomponent },

  { path: 'contact', component: Contact },

  { path: 'login', component: Login },

  { path: 'register', component: Register },

  { path: 'admin', component: AdminDashboard, canActivate: [AdminGuard] },

  { path: 'admin/courses', component: CourseManagement },
  
  { path: '', redirectTo: '/admin/dashboard', pathMatch: 'full' },

  { path: '**', redirectTo: 'login' }
];